const API_BASE = (import.meta.env.VITE_API_BASE_URL || '/api').replace(/\/$/, '');
export function getToken(){ return sessionStorage.getItem('jm_access_token'); }
export function setSession(data){ sessionStorage.setItem('jm_access_token', data.accessToken); sessionStorage.setItem('jm_user', JSON.stringify(data.user)); }
export function clearSession(){ sessionStorage.removeItem('jm_access_token'); sessionStorage.removeItem('jm_user'); }
export function getSessionUser(){ try { return JSON.parse(sessionStorage.getItem('jm_user') || 'null'); } catch { return null; } }
export async function api(path, options={}) {
  const headers = { 'Content-Type':'application/json', ...(options.headers || {}) };
  const token = getToken(); if(token) headers.Authorization = `Bearer ${token}`;
  const response = await fetch(`${API_BASE}${path}`, { ...options, headers });
  const data = await response.json().catch(()=>({}));
  if(!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
  return data;
}
