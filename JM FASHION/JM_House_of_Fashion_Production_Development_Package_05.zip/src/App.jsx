import React, { useMemo, useState, useEffect } from 'react';
import Login from './Login.jsx';
import { api, clearSession, getSessionUser, getToken } from './api.js';
import {
  LayoutDashboard, ShoppingBag, Package, Users, ClipboardList, Wallet,
  BarChart3, Settings, Search, Bell, Plus, ArrowUpRight, ArrowDownRight,
  MoreHorizontal, Eye, Heart, ShoppingCart, Menu, X, Store, Monitor,
  ShieldCheck, Smartphone, Banknote, Truck, CalendarDays, ChevronDown,
  SlidersHorizontal, Sparkles, CircleHelp, LogOut, Check, Clock3, Image,
  ReceiptText, BadgePercent, ChartNoAxesCombined, ScanBarcode
} from 'lucide-react';

const products = [
  { id: 1, name: 'Satin Evening Dress', category: 'Nguo za kike', price: 85000, stock: 12, tag: 'New arrival', image: 'https://images.unsplash.com/photo-1566206091558-7f218b696731?w=900&q=85' },
  { id: 2, name: 'Classic Mini Handbag', category: 'Pochi za kike', price: 65000, stock: 8, tag: 'Bestseller', image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=900&q=85' },
  { id: 3, name: 'Elegant Everyday Set', category: 'Nguo za kike', price: 72000, stock: 15, tag: 'Popular', image: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?w=900&q=85' },
  { id: 4, name: 'Rose Gold Watch', category: 'Saa za kike', price: 95000, stock: 5, tag: 'Limited', image: 'https://images.unsplash.com/photo-1524592094714-0f0654e20314?w=900&q=85' },
  { id: 5, name: 'Modern Sunglasses', category: 'Miwani ya kike', price: 35000, stock: 21, tag: 'Trending', image: 'https://images.unsplash.com/photo-1511499767150-a48a237f0083?w=900&q=85' },
  { id: 6, name: 'Chic Shoulder Bag', category: 'Pochi za kike', price: 78000, stock: 9, tag: 'New arrival', image: 'https://images.unsplash.com/photo-159087 턀?'.replace(' 턀?','') }
];
products[5].image = 'https://images.unsplash.com/photo-1590874103328-eac38a683ce7?w=900&q=85';

const money = n => new Intl.NumberFormat('en-TZ', { style: 'currency', currency: 'TZS', maximumFractionDigits: 0 }).format(n).replace('TZS', 'TSh');

function Logo({ small = false }) {
  return <div className="brand-lockup">
    <div className="brand-mark">JM</div>
    {!small && <div><div className="brand-name">JM HOUSE</div><div className="brand-sub">OF FASHION</div></div>}
  </div>;
}

function Sidebar({ mode, setMode, page, setPage, mobileOpen, close }) {
  const adminItems = [
    ['Overview', LayoutDashboard], ['Products', Package], ['Inventory', ClipboardList],
    ['Sales & POS', ScanBarcode], ['Customer Orders', ShoppingBag], ['Suppliers', Truck],
    ['Agency Services', Wallet], ['Reports', BarChart3], ['Customers & Team', Users], ['Settings', Settings]
  ];
  return <aside className={`sidebar ${mobileOpen ? 'open' : ''}`}>
    <div className="sidebar-top"><Logo /><button className="icon-btn close-sidebar" onClick={close}><X size={18}/></button></div>
    <div className="workspace-label">WORKSPACE</div>
    <div className="mode-switch">
      <button className={mode === 'admin' ? 'selected' : ''} onClick={() => {setMode('admin'); setPage('Overview'); close();}}><LayoutDashboard size={16}/> Owner</button>
      <button className={mode === 'shop' ? 'selected' : ''} onClick={() => {setMode('shop'); setPage('Shop'); close();}}><ShoppingBag size={16}/> Storefront</button>
      <button className={mode === 'tv' ? 'selected' : ''} onClick={() => {setMode('tv'); setPage('Display'); close();}}><Monitor size={16}/> TV Display</button>
    </div>
    <div className="workspace-label">{mode === 'admin' ? 'MANAGEMENT' : mode === 'shop' ? 'DISCOVER' : 'DISPLAY'}</div>
    <nav className="nav-list">
      {(mode === 'admin' ? adminItems : mode === 'shop' ? [['Shop', ShoppingBag], ['My Orders', ClipboardList]] : [['Display', Monitor]]).map(([label, Icon]) =>
        <button key={label} className={`nav-item ${page === label ? 'active' : ''}`} onClick={() => {setPage(label); close();}}>
          <Icon size={18}/><span>{label}</span>{label === 'Customer Orders' && <i className="nav-count">4</i>}
        </button>
      )}
    </nav>
    <div className="sidebar-bottom">
      <div className="help-card"><div className="help-icon"><CircleHelp size={17}/></div><b>Need a hand?</b><p>Get help setting up your boutique.</p><button onClick={() => alert('Support contact will be configured during deployment.')}>Contact support <ArrowUpRight size={13}/></button></div>
      <div className="profile-row"><div className="avatar">JM</div><div className="profile-copy"><b>Store Owner</b><span>Administrator</span></div><MoreHorizontal size={19} className="muted"/></div>
    </div>
  </aside>;
}

function Header({ page, setMobileOpen, mode, user, onLogout }) {
  return <header className="topbar">
    <button className="icon-btn mobile-menu" onClick={() => setMobileOpen(true)}><Menu size={20}/></button>
    <div className="breadcrumb"><span>{mode === 'admin' ? 'Workspace' : mode === 'shop' ? 'JM Boutique' : 'Public display'}</span><b>/</b><strong>{page}</strong></div>
    <div className="top-actions">
      <div className="date-pill"><CalendarDays size={15}/> Friday, 20 November 2026</div>
      <button className="icon-btn notification"><Bell size={18}/><i/></button>
      <button className="top-avatar logout-avatar" title="Sign out" onClick={onLogout}>{(user?.name || 'JM').slice(0,2).toUpperCase()}</button>
    </div>
  </header>;
}

function StatCard({ title, value, change, positive, icon: Icon, note }) {
  return <div className="stat-card">
    <div className="stat-top"><span>{title}</span><div className="stat-icon"><Icon size={18}/></div></div>
    <div className="stat-value">{value}</div>
    <div className="stat-bottom"><span className={positive ? 'trend up' : 'trend down'}>{positive ? <ArrowUpRight size={14}/> : <ArrowDownRight size={14}/>} {change}</span><span className="stat-note">{note}</span></div>
  </div>;
}

function SalesChart() {
  const bars = [38,52,45,68,56,75,62,83,69,92,73,88];
  return <div className="chart-wrap">
    <div className="chart-y"><span>1.2m</span><span>900k</span><span>600k</span><span>300k</span><span>0</span></div>
    <div className="chart-main">
      <div className="chart-grid"><i/><i/><i/><i/><i/></div>
      <div className="bars">{bars.map((h,i)=><div className="bar-column" key={i}><div className={`bar ${i===9?'highlight':''}`} style={{height:`${h}%`}}/></div>)}</div>
      <div className="chart-x"><span>01 Nov</span><span>05 Nov</span><span>10 Nov</span><span>15 Nov</span><span>20 Nov</span></div>
    </div>
  </div>;
}

function Dashboard() {
  return <div className="page-content">
    <div className="welcome-row"><div><div className="eyebrow"><Sparkles size={14}/> YOUR BUSINESS AT A GLANCE</div><h1>Good afternoon, <em>Welcome back.</em></h1><p>Here’s what’s happening at JM House of Fashion today.</p></div><button className="primary-btn"><Plus size={17}/> New transaction</button></div>
    <div className="stats-grid">
      <StatCard title="Today's sales" value="TSh 485,000" change="+12.8%" positive note="vs yesterday" icon={Banknote}/>
      <StatCard title="Orders received" value="24" change="+8.2%" positive note="vs yesterday" icon={ShoppingBag}/>
      <StatCard title="Products in stock" value="1,284" change="18 low stock" positive={false} note="needs attention" icon={Package}/>
      <StatCard title="Estimated gross profit" value="TSh 192,500" change="+6.4%" positive note="this month" icon={ChartNoAxesCombined}/>
    </div>
    <div className="dashboard-grid">
      <section className="panel sales-panel">
        <div className="panel-heading"><div><h3>Sales performance</h3><p>Track your boutique revenue over time</p></div><select defaultValue="7"><option value="7">Last 20 days</option><option>This month</option><option>This year</option></select></div>
        <div className="chart-legend"><span><i className="legend-dot"/></span> Sales revenue <b>TSh 8,450,000</b><small className="positive-text">+14.6%</small></div>
        <SalesChart/>
      </section>
      <section className="panel activity-panel">
        <div className="panel-heading"><div><h3>Recent activity</h3><p>Latest store updates</p></div><button className="text-btn">View all</button></div>
        <div className="activity-list">
          <Activity icon={ShoppingBag} title="New order received" detail="Order #JMF-1048 · Online" time="8 min ago" tone="rose"/>
          <Activity icon={Banknote} title="POS sale completed" detail="TSh 125,000 · Cash" time="32 min ago" tone="gold"/>
          <Activity icon={Package} title="Stock updated" detail="12 items · New arrivals" time="1 hr ago" tone="sage"/>
          <Activity icon={Users} title="New customer registered" detail="Customer account created" time="2 hrs ago" tone="lilac"/>
        </div>
      </section>
    </div>
    <section className="panel products-panel">
      <div className="panel-heading"><div><h3>Popular products</h3><p>Your most viewed boutique pieces</p></div><button className="text-btn">View inventory <ArrowUpRight size={14}/></button></div>
      <div className="popular-grid">{products.slice(0,4).map(p=><div className="popular-item" key={p.id}><img src={p.image} alt={p.name}/><div><b>{p.name}</b><span>{p.category}</span><strong>{money(p.price)}</strong></div><span className="sold-tag">{p.stock} in stock</span></div>)}</div>
    </section>
  </div>;
}
function Activity({icon:Icon,title,detail,time,tone}) {
  return <div className="activity-item"><div className={`activity-icon ${tone}`}><Icon size={16}/></div><div className="activity-copy"><b>{title}</b><span>{detail}</span></div><time>{time}</time></div>;
}

function ProductsPage({ addToCart, mode }) {
  const [filter,setFilter] = useState('All items');
  const [query,setQuery] = useState('');
  const categories = ['All items','Nguo za kike','Pochi za kike','Saa za kike','Miwani ya kike'];
  const filtered = useMemo(() => products.filter(p => (filter==='All items'||p.category===filter) && p.name.toLowerCase().includes(query.toLowerCase())),[filter,query]);
  return <div className="page-content">
    <div className="welcome-row"><div><div className="eyebrow"><Sparkles size={14}/> THE BOUTIQUE COLLECTION</div><h1>Discover your <em>style.</em></h1><p>Thoughtfully selected pieces to make every moment feel special.</p></div><div className="secure-note"><ShieldCheck size={16}/> Official JM Boutique collection</div></div>
    <div className="shop-toolbar"><div className="search-box"><Search size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search products..."/></div><button className="filter-btn"><SlidersHorizontal size={16}/> Filters</button></div>
    <div className="category-chips">{categories.map(c=><button key={c} className={filter===c?'chosen':''} onClick={()=>setFilter(c)}>{c}</button>)}</div>
    <div className="product-grid">{filtered.map(p=><article className="product-card" key={p.id}><div className="product-photo"><img src={p.image} alt={p.name}/><span className="product-tag">{p.tag}</span><button className="wishlist"><Heart size={17}/></button></div><div className="product-info"><span>{p.category}</span><h3>{p.name}</h3><div className="product-price-row"><b>{money(p.price)}</b><button onClick={()=>addToCart(p)} aria-label="Add to cart"><Plus size={17}/></button></div></div></article>)}</div>
  </div>;
}

function SimplePage({page}) {
  const descriptions = {
    Products:'Manage your fashion catalogue, product images, pricing and variations.',
    Inventory:'Monitor stock levels, product movements and stock adjustments.',
    'Sales & POS':'Record in-store sales and issue customer receipts.',
    'Customer Orders':'Review online orders, confirm payments and manage fulfilment.',
    Suppliers:'Manage wholesale suppliers, purchase invoices and outstanding balances.',
    'Agency Services':'Manage mobile money and bank agency transactions and reconciliation.',
    Reports:'Review daily, weekly, monthly and annual business performance.',
    'Customers & Team':'Manage customer records, employee accounts and access permissions.',
    Settings:'Configure your boutique, payment channels, security and application preferences.',
    'My Orders':'Review your purchases and order delivery status.',
    Display:'Public product slideshow for your in-store Smart TV.'
  };
  return <div className="page-content"><div className="welcome-row"><div><div className="eyebrow"><Sparkles size={14}/> JM HOUSE OF FASHION</div><h1>{page}</h1><p>{descriptions[page] || 'Manage your boutique operations from one place.'}</p></div></div><div className="coming-panel"><div className="coming-icon"><Sparkles size={25}/></div><h2>{page} workspace</h2><p>This module is included in the project architecture. Its database-backed workflows will be implemented in the next development phase.</p><span className="status-pill"><Clock3 size={13}/> Module scaffold created</span></div></div>;
}

function TVDisplay() {
  return <div className="tv-screen"><div className="tv-head"><Logo/><span>THE NEW COLLECTION</span><span>SHINYANGA · TANZANIA</span></div><div className="tv-hero"><div><div className="eyebrow">JM HOUSE OF FASHION PRESENTS</div><h1>Style is a way<br/>to <em>express yourself.</em></h1><p>Discover pieces made to celebrate your individuality.</p><div className="tv-cta">EXPLORE OUR COLLECTION</div></div><img src={products[0].image} alt="Fashion collection"/></div><div className="tv-products">{products.slice(1,5).map(p=><div key={p.id}><img src={p.image} alt={p.name}/><b>{p.name}</b><span>{money(p.price)}</span></div>)}</div><div className="tv-foot">JM HOUSE OF FASHION <span>MOLEKA STREET, SHINYANGA</span><span>WELCOME IN</span></div></div>;
}

export default function App() {
  const [user,setUser] = useState(getSessionUser());
  const [authChecked,setAuthChecked] = useState(!getToken());
  useEffect(()=>{ if(!getToken()) return; api('/auth/me').then(({user:u})=>setUser({id:u.id,name:u.display_name,role:u.role,businessId:u.business_id})).catch(()=>{clearSession();setUser(null);}).finally(()=>setAuthChecked(true)); },[]);
  const [mode,setMode] = useState('admin');
  const [page,setPage] = useState('Overview');
  const [mobileOpen,setMobileOpen] = useState(false);
  const [cart,setCart] = useState([]);
  const addToCart = p => setCart(old => [...old,p]);
  const close = () => setMobileOpen(false);
  if (!authChecked) return <main className="login-screen"><div className="login-loading">Securing your workspace…</div></main>;
  if (!user) return <Login onLogin={setUser}/>;
  if (mode === 'tv') return <TVDisplay/>;
  return <div className="app-shell">
    <Sidebar mode={mode} setMode={setMode} page={page} setPage={setPage} mobileOpen={mobileOpen} close={close}/>
    {mobileOpen && <div className="scrim" onClick={close}/>}
    <main className="main-area">
      <Header page={page} setMobileOpen={setMobileOpen} mode={mode} user={user} onLogout={()=>{clearSession();setUser(null);setMode('admin');setPage('Overview');}}/>
      {mode === 'admin' ? page === 'Overview' ? <Dashboard/> : <SimplePage page={page}/> : page === 'Shop' ? <ProductsPage addToCart={addToCart} mode={mode}/> : <SimplePage page={page}/>}
    </main>
    {mode === 'shop' && <button className="cart-fab"><ShoppingCart size={19}/><span>{cart.length}</span></button>}
  </div>;
}
