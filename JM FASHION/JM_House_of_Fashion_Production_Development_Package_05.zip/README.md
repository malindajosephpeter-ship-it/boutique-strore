# JM House of Fashion — Development Starter

A premium UI foundation and initial PostgreSQL schema for the JM House of Fashion ecosystem.

## Current contents

- Responsive React/Vite frontend shell.
- Owner dashboard overview.
- Customer storefront catalogue with category filters and cart-count interaction.
- Smart TV public display mode.
- Initial PostgreSQL schema for products, variants, inventory, suppliers, purchases, customers, orders, payments, expenses, agency services and audit logs.
- Feminine premium brand palette: Royal Berry, Blush Rose, Champagne Gold and Soft Ivory.

## Run locally

Requirements: Node.js 20+ and npm.

```bash
npm install
npm run dev
```

Open the local URL printed by Vite.

Create a production build:

```bash
npm run build
```

## Important implementation status

This is the first development scaffold, not yet a deployed production system.

The dashboard currently uses demonstration data. The module pages are structural placeholders. The product catalogue uses remote demonstration photography. No real payment gateway, authentication provider, PostgreSQL connection, employee account system, or cloud synchronization is active yet.

Do not use this scaffold to process real customer payments or store confidential business data.

## Next engineering milestones

1. Provision managed PostgreSQL and backend hosting.
2. Implement authentication, session management, roles and server-side authorization.
3. Apply database migrations and implement row-level security policies.
4. Build API services and connect the interfaces to the shared database.
5. Implement inventory-safe purchasing, POS, online ordering and payment verification.
6. Implement mobile money and bank agency ledger/reconciliation.
7. Implement reports, audit logs, backups and monitoring.
8. Package Flutter applications and prepare store submissions.
9. Run security, integration and acceptance tests.

## Deployment architecture

Use Netlify for the web frontend. Host PostgreSQL and the secure API on a managed service compatible with the application. Keep all database credentials and privileged API keys server-side.


## Development increment 2: API foundation

Added a separate Express API service with:
- Helmet security headers, CORS allow-list, JSON size limit and rate limiting.
- JWT-based authentication middleware and role checks.
- Login and current-user endpoints.
- Public published-product catalogue endpoint.
- Protected product creation endpoint.
- Transactional order creation with row locking and stock checks.
- Audit logging for created orders.
- PostgreSQL authentication/security migration.

### Run the API

```bash
cd server
cp .env.example .env
# Configure DATABASE_URL, JWT_SECRET and CORS_ORIGINS
npm install
npm run dev
```

The API is not production-ready until the managed database is provisioned, migrations are applied, owner bootstrap is implemented, RLS/database privileges are configured and security tests pass.

## Development increment 3: purchasing, stock ledger and finance

Added:
- Supplier directory API (list, create, update).
- Purchase order API with supplier and variant ownership validation.
- Transactional purchase receiving: stock balances are increased and every received line is recorded in `stock_movements`; duplicate receiving is blocked.
- Physical POS sales decrease stock and create negative stock-ledger entries; online orders reserve stock pending fulfilment.
- Expense entry and listing with category, date and payment method.
- Monthly/year-to-date summary and monthly sales trend reporting endpoints.
- Public read-only Smart TV product feed that returns only published product details (no cost prices, stock quantities, customer data or internal records).
- Migration `003_inventory_finance.sql` for the stock movement ledger and supporting indexes/fields.

Apply migrations in order with `cd server && npm run migrate`. The runner applies `001_initial_schema.sql` through `004_customer_fulfilment.sql` exactly once using the `schema_migrations` ledger.

### New API endpoints
- `GET/POST/PATCH /api/suppliers`
- `GET/POST /api/purchases`
- `POST /api/purchases/:id/receive`
- `GET/POST /api/expenses`
- `GET /api/reports/summary?period=month|year`
- `GET /api/reports/sales-trend?year=2026`
- `GET /api/display/products?businessId=<business UUID>` (public, published products only)

These are API foundations and still require database provisioning, an initial owner bootstrap, role/identity reconciliation, integration tests, payment-provider integrations and deployment before live business use.

## Development increment 4 — customer checkout and fulfilment

Added:
- Guest online checkout with customer contact/delivery details, stock reservation, payment intent and one-time order tracking token.
- Customer order tracking by order number + 64-character tracking token. Store the token securely; it cannot be recovered from the database.
- Staff account creation/deactivation for owner/manager roles. Public employee signup is intentionally disabled.
- Staff order queue, controlled order-state transitions, payment verification, stock release on cancellation, and stock deduction on completed fulfilment.
- Ordered SQL migration runner and one-time owner bootstrap scripts.

### First-time setup (backend)
1. Create a private PostgreSQL database and configure `DATABASE_URL`, `DATABASE_SSL`, `JWT_SECRET` (at least 32 random characters), and `CORS_ORIGINS`.
2. From `server/`, run `npm install` then `npm run migrate`.
3. Set the `INITIAL_OWNER_*` values temporarily and run `npm run bootstrap:owner` once. Remove the bootstrap values immediately afterwards.
4. Start with `npm start` and verify `/api/health`.

Do not expose database credentials or the JWT secret in the browser/mobile app. The checkout endpoint is a foundation: connect a verified payment provider and its signed webhook before accepting prepaid mobile-money or bank payments. Never mark a payment verified based only on a customer-submitted reference. Add provider-specific reconciliation and idempotency before production payments.

### Important production status
This repository remains a development implementation, not a production-certified or deployed store. No cloud database, storage bucket, payment merchant credentials, Apple/Google developer accounts, TLS domain, backups, monitoring, or live provider webhooks have been provisioned from this workspace. Before public launch, complete integration, security review, load testing, backup/restore testing, privacy/terms pages, and device testing. Guest checkout currently accepts delivery details but does not yet calculate delivery fees or dispatch logistics.


### Additional inventory endpoints
- `GET /api/inventory` (authorized inventory view)
- `GET /api/inventory/movements` (stock movement ledger)
- `POST /api/inventory/adjust` (authorized reason-coded stock adjustment; cannot reduce below reserved stock)


## Development increment 05 — secure app shell and PWA

- Added an owner/staff sign-in screen connected to `POST /api/auth/login` and session validation via `GET /api/auth/me`.
- Access tokens are held in `sessionStorage` and cleared on sign-out; this is a pragmatic SPA baseline, not a substitute for a production BFF with Secure, HttpOnly, SameSite cookies.
- Added a PWA manifest and service worker for static app-shell caching. API requests are deliberately never cached; offline transaction submission is not enabled until an idempotent sync queue is implemented and tested.
- Added migration `005_production_hardening.sql` with query indexes and operational constraints. Review it against the target PostgreSQL version and run it only after migrations 001–004.

### Frontend environment
Copy `.env.example` to `.env` in the frontend root and set `VITE_API_BASE_URL` to the public API base (for example `https://api.example.com/api`). Never put database credentials or private payment-provider keys in `VITE_*` variables.

### Current release status
This is a development increment. The owner sign-in UI requires a provisioned database, completed migrations and one-time owner bootstrap. PWA installation requires HTTPS and valid hosting headers. No live payment gateway, production cloud database, domain, mobile store listing, or deployment is configured by this source package.
- Protected API requests now re-check the staff account and current role against PostgreSQL on every request, so a disabled employee loses access immediately rather than when the JWT expires.
