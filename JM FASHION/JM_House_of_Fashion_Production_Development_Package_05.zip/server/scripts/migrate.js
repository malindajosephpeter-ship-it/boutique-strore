import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';
import pg from 'pg';
dotenv.config();
if(!process.env.DATABASE_URL) throw new Error('DATABASE_URL is required');
const {Pool}=pg;const pool=new Pool({connectionString:process.env.DATABASE_URL,ssl:process.env.DATABASE_SSL==='true'?{rejectUnauthorized:true}:undefined});
const here=path.dirname(fileURLToPath(import.meta.url));
try{
 await pool.query(`CREATE TABLE IF NOT EXISTS schema_migrations(version text PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now())`);
 const files=(await fs.readdir(path.join(here,'../migrations'))).filter(x=>x.endsWith('.sql')).sort();
 for(const file of files){const exists=await pool.query('SELECT 1 FROM schema_migrations WHERE version=$1',[file]);if(exists.rowCount){console.log(`skip ${file}`);continue;}const sql=await fs.readFile(path.join(here,'../migrations',file),'utf8');const c=await pool.connect();try{await c.query('BEGIN');await c.query(sql);await c.query('INSERT INTO schema_migrations(version) VALUES($1)',[file]);await c.query('COMMIT');console.log(`applied ${file}`);}catch(e){await c.query('ROLLBACK');throw e;}finally{c.release();}}
}finally{await pool.end();}
