import { Router } from 'express';
import { z } from 'zod';
import { pool } from '../db.js';
import { requireAuth, allowRoles } from '../middleware/auth.js';

const router = Router();
const productSchema = z.object({
  name: z.string().trim().min(2).max(160),
  categoryId: z.string().uuid().nullable().optional(),
  description: z.string().max(4000).optional(),
  sellingPrice: z.number().nonnegative(),
  sku: z.string().max(80).optional(),
  isPublished: z.boolean().optional()
});

router.get('/', async (req, res, next) => {
  try {
    const businessId = req.query.businessId;
    if (!businessId) return res.status(400).json({ error: 'businessId is required' });
    const result = await pool.query(
      `SELECT p.id, p.name, p.description, p.selling_price, p.is_published,
              c.name AS category,
              COALESCE((SELECT json_agg(json_build_object('storageKey', pi.storage_key, 'alt', pi.alt_text)
                ORDER BY pi.sort_order) FROM product_images pi WHERE pi.product_id = p.id), '[]') AS images
       FROM products p LEFT JOIN categories c ON c.id = p.category_id
       WHERE p.business_id = $1 AND p.is_published = true
       ORDER BY p.created_at DESC`,
      [businessId]
    );
    res.json({ products: result.rows });
  } catch (err) { next(err); }
});

router.post('/', requireAuth, allowRoles('owner','manager','stock_manager'), async (req, res, next) => {
  try {
    const parsed = productSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'Invalid product details', details: parsed.error.flatten() });
    const p = parsed.data;
    const result = await pool.query(
      `INSERT INTO products (business_id, category_id, sku, name, description, selling_price, is_published)
       VALUES ($1,$2,$3,$4,$5,$6,$7)
       RETURNING id, name, sku, selling_price, is_published`,
      [req.user.businessId, p.categoryId || null, p.sku || null, p.name, p.description || null, p.sellingPrice, p.isPublished || false]
    );
    res.status(201).json({ product: result.rows[0] });
  } catch (err) { next(err); }
});

export default router;
