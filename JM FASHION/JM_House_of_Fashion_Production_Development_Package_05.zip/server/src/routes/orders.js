import { Router } from 'express';
import { z } from 'zod';
import { pool } from '../db.js';
import { requireAuth, allowRoles } from '../middleware/auth.js';

const router = Router();
const orderSchema = z.object({
  channel: z.enum(['online','physical_pos']),
  customerId: z.string().uuid().nullable().optional(),
  lines: z.array(z.object({
    variantId: z.string().uuid(),
    quantity: z.number().int().positive().max(100),
    unitPrice: z.number().nonnegative()
  })).min(1).max(100)
});

router.post('/', requireAuth, async (req, res, next) => {
  const parsed = orderSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Invalid order', details: parsed.error.flatten() });

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const input = parsed.data;
    const role = req.user.role;
    if (input.channel === 'physical_pos' && !['owner','manager','sales_attendant'].includes(role)) {
      await client.query('ROLLBACK');
      return res.status(403).json({ error: 'POS access is restricted to authorized staff' });
    }

    let subtotal = 0;
    const prepared = [];
    for (const line of input.lines) {
      const item = await client.query(
        `SELECT pv.id, p.selling_price, p.business_id, ib.quantity_on_hand, ib.quantity_reserved
         FROM product_variants pv
         JOIN products p ON p.id = pv.product_id
         JOIN inventory_balances ib ON ib.variant_id = pv.id
         WHERE pv.id = $1 AND p.business_id = $2
         FOR UPDATE OF ib`,
        [line.variantId, req.user.businessId]
      );
      const row = item.rows[0];
      if (!row) throw Object.assign(new Error('A selected product variant is unavailable'), { status: 409 });
      const available = row.quantity_on_hand - row.quantity_reserved;
      if (available < line.quantity) throw Object.assign(new Error('Insufficient stock for one or more items'), { status: 409 });
      const price = Number(row.selling_price);
      subtotal += price * line.quantity;
      prepared.push({ ...line, price });
    }

    const orderStatus = input.channel === 'online' ? 'pending' : 'completed';
    const order = await client.query(
      `INSERT INTO sales_orders (business_id, customer_id, channel, status, subtotal, total)
       VALUES ($1,$2,$3,$4,$5,$5) RETURNING id, status, total, created_at`,
      [req.user.businessId, input.customerId || null, input.channel, orderStatus, subtotal]
    );

    for (const line of prepared) {
      await client.query(
        `INSERT INTO sales_order_lines (order_id, variant_id, quantity, unit_price)
         VALUES ($1,$2,$3,$4)`,
        [order.rows[0].id, line.variantId, line.quantity, line.price]
      );
      if (input.channel === 'physical_pos') {
        await client.query(
          `UPDATE inventory_balances SET quantity_on_hand = quantity_on_hand - $2, updated_at = now()
           WHERE variant_id = $1`,
          [line.variantId, line.quantity]
        );
        await client.query(
          `INSERT INTO stock_movements (business_id, variant_id, movement_type, quantity_delta, reference_type, reference_id, created_by)
           VALUES ($1,$2,'pos_sale',$3,'sales_order',$4,$5)`,
          [req.user.businessId, line.variantId, -line.quantity, order.rows[0].id, req.user.sub]
        );
      } else {
        await client.query(
          `UPDATE inventory_balances SET quantity_reserved = quantity_reserved + $2, updated_at = now()
           WHERE variant_id = $1`,
          [line.variantId, line.quantity]
        );
      }
    }

    await client.query(
      `INSERT INTO audit_logs (business_id, actor_user_id, action, entity_type, entity_id, metadata)
       VALUES ($1,$2,'order_created','sales_order',$3,jsonb_build_object('channel',$4,'total',$5))`,
      [req.user.businessId, req.user.sub, order.rows[0].id, input.channel, subtotal]
    );
    await client.query('COMMIT');
    res.status(201).json({ order: order.rows[0] });
  } catch (err) {
    await client.query('ROLLBACK');
    next(err);
  } finally {
    client.release();
  }
});

router.get('/', requireAuth, allowRoles('owner','manager','sales_attendant','accountant'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT id, channel, status, subtotal, discount, total, created_at
       FROM sales_orders WHERE business_id = $1 ORDER BY created_at DESC LIMIT 200`,
      [req.user.businessId]
    );
    res.json({ orders: result.rows });
  } catch (err) { next(err); }
});

export default router;
