import{Router}from'express';import{pool}from'../db.js';
const router=Router();
// Read-only public TV catalogue: never exposes costs, stock counts, customers or internal records.
router.get('/products',async(req,res,next)=>{try{const businessId=req.query.businessId;if(!businessId)return res.status(400).json({error:'businessId is required'});const r=await pool.query(`SELECT p.id,p.name,p.description,p.selling_price,c.name category,COALESCE((SELECT json_agg(json_build_object('storageKey',pi.storage_key,'alt',pi.alt_text) ORDER BY pi.sort_order) FROM product_images pi WHERE pi.product_id=p.id),'[]') images FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE p.business_id=$1 AND p.is_published=true ORDER BY p.updated_at DESC LIMIT 100`,[businessId]);res.json({displayMode:true,currency:'TZS',products:r.rows});}catch(e){next(e);}});
export default router;
