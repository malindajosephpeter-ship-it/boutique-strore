import { Router } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { z } from 'zod';
import { pool } from '../db.js';
import { requireAuth } from '../middleware/auth.js';

const router = Router();
const loginSchema = z.object({
  email: z.string().email().max(254),
  password: z.string().min(10).max(128)
});

router.post('/login', async (req, res, next) => {
  try {
    const parsed = loginSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'Enter a valid email and password.' });

    const { email, password } = parsed.data;
    const result = await pool.query(
      `SELECT u.id, u.business_id, u.display_name, u.role, u.password_hash, u.is_active
       FROM app_users u WHERE lower(u.email) = lower($1) LIMIT 1`,
      [email]
    );
    const user = result.rows[0];
    if (!user || !user.is_active || !(await bcrypt.compare(password, user.password_hash))) {
      return res.status(401).json({ error: 'Email or password is incorrect.' });
    }

    const token = jwt.sign({
      sub: user.id,
      businessId: user.business_id,
      role: user.role,
      name: user.display_name
    }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '8h' });

    await pool.query(
      `INSERT INTO security_events (business_id, user_id, event_type, details)
       VALUES ($1, $2, 'login_success', jsonb_build_object('channel','api'))`,
      [user.business_id, user.id]
    );

    res.json({
      accessToken: token,
      tokenType: 'Bearer',
      expiresIn: process.env.JWT_EXPIRES_IN || '8h',
      user: { id: user.id, name: user.display_name, role: user.role, businessId: user.business_id }
    });
  } catch (err) { next(err); }
});

router.get('/me', requireAuth, async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT id, display_name, role, business_id FROM app_users WHERE id = $1 AND is_active = true`,
      [req.user.sub]
    );
    if (!result.rows[0]) return res.status(401).json({ error: 'Account is inactive' });
    res.json({ user: result.rows[0] });
  } catch (err) { next(err); }
});

export default router;
