import { Router } from 'express';
import { randomBytes, createHash } from 'node:crypto';
import { z } from 'zod';
import { pool } from '../db.js';

const router = Router();
const schema = z.object({
  businessId: z.string().uuid(), customerName: z.string().min(2).max(120),
  phone: z.string().min(7).max(25), email: z.string().email().max(254).optional().or(z.literal('')),
  deliveryAddress: z.string().min(5).max(500), region: z.string().max(80).optional(),
  paymentMethod: z.enum(['cash_on_delivery','mobile_money','bank_transfer']), provider: z.string().max(80).optional(),
  lines: z.array(z.object({ variantId: z.string().uuid(), quantity: z.number().int().positive().max(20) })).min(1).max(30)
});
const hash = value => createHash('sha256').update(value).digest('hex');

// Guest checkout. Customer sees only the order reference and one-time tracking token.
router.post('/', async (req,res,next) => {
 const parsed=schema.safeParse(req.body); if(!parsed.success) return res.status(400).json({error:'Taarifa za oda hazijakamilika',details:parsed.error.flatten()});
 const d=parsed.data, client=await pool.connect();
 try {
  await client.query('BEGIN');
  const business=await client.query('SELECT id FROM businesses WHERE id=$1',[d.businessId]);
  if(!business.rowCount) throw Object.assign(new Error('Store not found'),{status:404});
  let customer=await client.query('SELECT id FROM customers WHERE business_id=$1 AND phone=$2 ORDER BY created_at LIMIT 1',[d.businessId,d.phone]);
  if(customer.rowCount) await client.query('UPDATE customers SET full_name=$2,email=COALESCE(NULLIF($3,\'\'),email) WHERE id=$1',[customer.rows[0].id,d.customerName,d.email||'']);
  else customer=await client.query('INSERT INTO customers(business_id,full_name,phone,email) VALUES($1,$2,$3,NULLIF($4,\'\')) RETURNING id',[d.businessId,d.customerName,d.phone,d.email||'']);
  let subtotal=0; const lines=[]; const aggregated=[...d.lines.reduce((m,l)=>m.set(l.variantId,(m.get(l.variantId)||0)+l.quantity),new Map())].map(([variantId,quantity])=>({variantId,quantity}));
  for(const l of aggregated){
   const q=await client.query(`SELECT pv.id,p.selling_price,p.name,p.business_id,COALESCE(ib.quantity_on_hand,0)-COALESCE(ib.quantity_reserved,0) available FROM product_variants pv JOIN products p ON p.id=pv.product_id LEFT JOIN inventory_balances ib ON ib.variant_id=pv.id WHERE pv.id=$1 AND p.business_id=$2 AND p.is_published=true FOR UPDATE OF pv`,[l.variantId,d.businessId]);
   const item=q.rows[0]; if(!item) throw Object.assign(new Error('Bidhaa haipatikani'),{status:409});
   if(Number(item.available)<l.quantity) throw Object.assign(new Error(`Stock haitoshi: ${item.name}`),{status:409});
   subtotal+=Number(item.selling_price)*l.quantity; lines.push({...l,price:Number(item.selling_price)});
  }
  const accessToken=randomBytes(32).toString('hex'); const orderNumber=`JMF-${Date.now().toString().slice(-8)}-${randomBytes(2).toString('hex').toUpperCase()}`;
  const order=await client.query(`INSERT INTO sales_orders(business_id,customer_id,channel,status,subtotal,total,order_number,customer_access_hash,customer_phone,customer_name) VALUES($1,$2,'online','pending_payment',$3,$3,$4,$5,$6,$7) RETURNING id,order_number,total,status,created_at`,[d.businessId,customer.rows[0].id,subtotal,orderNumber,hash(accessToken),d.phone,d.customerName]);
  for(const l of lines){ await client.query('INSERT INTO sales_order_lines(order_id,variant_id,quantity,unit_price) VALUES($1,$2,$3,$4)',[order.rows[0].id,l.variantId,l.quantity,l.price]); await client.query('UPDATE inventory_balances SET quantity_reserved=quantity_reserved+$2,updated_at=now() WHERE variant_id=$1',[l.variantId,l.quantity]); }
  await client.query('INSERT INTO customer_addresses(customer_id,label,address,region,is_default) VALUES($1,\'Delivery\',$2,$3,true)',[customer.rows[0].id,d.deliveryAddress,d.region||null]);
  await client.query('INSERT INTO payments(order_id,method,provider,amount,status,notes) VALUES($1,$2,$3,$4,\'pending\',$5)',[order.rows[0].id,d.paymentMethod,d.provider||null,subtotal,d.paymentMethod==='cash_on_delivery'?'Payment due on delivery':'Awaiting payment confirmation']);
  await client.query('INSERT INTO order_status_history(order_id,new_status,note) VALUES($1,\'pending_payment\',\'Customer placed order\')',[order.rows[0].id]);
  await client.query('COMMIT'); res.status(201).json({order:order.rows[0],trackingToken:accessToken,message:'Oda imepokelewa. Hifadhi namba ya oda na token ya ufuatiliaji.'});
 }catch(e){await client.query('ROLLBACK');next(e);}finally{client.release();}
});
router.post('/track',async(req,res,next)=>{try{const p=z.object({orderNumber:z.string().min(5).max(40),trackingToken:z.string().length(64)}).safeParse(req.body);if(!p.success)return res.status(400).json({error:'Invalid tracking details'});const r=await pool.query(`SELECT order_number,status,total,currency,created_at,updated_at,fulfilled_at FROM sales_orders WHERE order_number=$1 AND customer_access_hash=$2`,[p.data.orderNumber,hash(p.data.trackingToken)]);if(!r.rowCount)return res.status(404).json({error:'Oda haijapatikana'});const h=await pool.query('SELECT new_status,note,created_at FROM order_status_history WHERE order_id=(SELECT id FROM sales_orders WHERE order_number=$1) ORDER BY created_at',[p.data.orderNumber]);res.json({order:r.rows[0],history:h.rows});}catch(e){next(e);}});
export default router;
