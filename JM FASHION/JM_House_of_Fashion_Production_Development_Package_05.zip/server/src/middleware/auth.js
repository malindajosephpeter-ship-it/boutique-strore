import jwt from 'jsonwebtoken';
import { pool } from '../db.js';

// Re-check account state on every protected request so deactivated staff lose
// access immediately instead of retaining access until the JWT expires.
export async function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Authentication required' });
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET, { algorithms: ['HS256'] });
    const result = await pool.query(
      'SELECT id,business_id,display_name,role,is_active FROM app_users WHERE id=$1',
      [payload.sub]
    );
    const user = result.rows[0];
    if (!user || !user.is_active || user.business_id !== payload.businessId) {
      return res.status(401).json({ error: 'Account is inactive or session is no longer valid' });
    }
    req.user = { sub: user.id, businessId: user.business_id, name: user.display_name, role: user.role };
    return next();
  } catch (error) {
    if (error.name === 'JsonWebTokenError' || error.name === 'TokenExpiredError' || error.name === 'NotBeforeError') {
      return res.status(401).json({ error: 'Invalid or expired session' });
    }
    return next(error);
  }
}

export function allowRoles(...roles) {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ error: 'You do not have permission to perform this action' });
    }
    next();
  };
}
