-- Authentication tables and security event log.
-- The app_users table stores password hashes only. Passwords are never stored in plaintext.

CREATE TABLE IF NOT EXISTS app_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id uuid NOT NULL REFERENCES businesses(id),
  display_name text NOT NULL,
  email text NOT NULL UNIQUE,
  password_hash text NOT NULL,
  role text NOT NULL CHECK (role IN ('owner','manager','sales_attendant','stock_manager','accountant','agency_operator','customer')),
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS security_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id uuid NOT NULL REFERENCES businesses(id),
  user_id uuid REFERENCES app_users(id),
  event_type text NOT NULL,
  details jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_app_users_email ON app_users (lower(email));
CREATE INDEX IF NOT EXISTS idx_security_events_business_date ON security_events(business_id, created_at DESC);

-- Production deployment checklist:
-- 1. Restrict database network access to backend only.
-- 2. Use a separate migration/database owner role.
-- 3. Use a least-privilege runtime database role.
-- 4. Add and test RLS policies before exposing any direct client database access.
-- 5. Provision the first owner through a one-time trusted bootstrap script, not public signup.
