-- Stock movement ledger and purchase/expense/reporting support.
CREATE TABLE IF NOT EXISTS stock_movements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id uuid NOT NULL REFERENCES businesses(id),
  variant_id uuid NOT NULL REFERENCES product_variants(id),
  movement_type text NOT NULL CHECK (movement_type IN ('purchase_receipt','pos_sale','online_fulfilment','adjustment_in','adjustment_out','return')),
  quantity_delta integer NOT NULL CHECK (quantity_delta <> 0),
  reference_type text,
  reference_id uuid,
  notes text,
  created_by uuid REFERENCES user_profiles(id),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_stock_movements_business_date ON stock_movements(business_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_purchase_orders_business_date ON purchase_orders(business_id, purchase_date DESC);
CREATE INDEX IF NOT EXISTS idx_expenses_business_date ON expenses(business_id, expense_date DESC);

ALTER TABLE purchase_orders ADD COLUMN IF NOT EXISTS received_at timestamptz;
ALTER TABLE purchase_orders ADD COLUMN IF NOT EXISTS notes text;
ALTER TABLE expenses ADD COLUMN IF NOT EXISTS payment_method text DEFAULT 'cash';

-- Authentication uses app_users IDs. Keep actor IDs as UUIDs without tying them
-- to the legacy user_profiles table until identity migration is completed.
ALTER TABLE purchase_orders DROP CONSTRAINT IF EXISTS purchase_orders_created_by_fkey;
ALTER TABLE expenses DROP CONSTRAINT IF EXISTS expenses_created_by_fkey;
ALTER TABLE stock_movements DROP CONSTRAINT IF EXISTS stock_movements_created_by_fkey;
ALTER TABLE audit_logs DROP CONSTRAINT IF EXISTS audit_logs_actor_user_id_fkey;
