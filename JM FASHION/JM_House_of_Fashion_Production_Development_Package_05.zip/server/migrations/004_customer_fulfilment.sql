-- Customer checkout, order tracking, fulfilment and staff lifecycle.
CREATE EXTENSION IF NOT EXISTS pgcrypto;
ALTER TABLE sales_orders ADD COLUMN IF NOT EXISTS order_number text;
ALTER TABLE sales_orders ADD COLUMN IF NOT EXISTS customer_access_hash text;
ALTER TABLE sales_orders ADD COLUMN IF NOT EXISTS customer_phone text;
ALTER TABLE sales_orders ADD COLUMN IF NOT EXISTS customer_name text;
ALTER TABLE sales_orders ADD COLUMN IF NOT EXISTS fulfilled_at timestamptz;
ALTER TABLE sales_orders ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();
CREATE UNIQUE INDEX IF NOT EXISTS idx_sales_orders_order_number ON sales_orders(order_number) WHERE order_number IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_sales_orders_customer_phone ON sales_orders(business_id, customer_phone, created_at DESC);
ALTER TABLE payments ADD COLUMN IF NOT EXISTS verified_by uuid;
ALTER TABLE payments ADD COLUMN IF NOT EXISTS notes text;
CREATE INDEX IF NOT EXISTS idx_payments_order_status ON payments(order_id,status);
CREATE TABLE IF NOT EXISTS customer_addresses (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), customer_id uuid NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
 label text NOT NULL DEFAULT 'Home', address text NOT NULL, region text, district text, is_default boolean NOT NULL DEFAULT false,
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS order_status_history (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), order_id uuid NOT NULL REFERENCES sales_orders(id) ON DELETE CASCADE,
 old_status text, new_status text NOT NULL, note text, changed_by uuid, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_order_history_order ON order_status_history(order_id,created_at);
