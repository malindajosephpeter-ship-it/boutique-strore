-- Production hardening: align audit identities with app_users and add operational constraints.
-- Run only after migrations 001-004 have completed successfully.
ALTER TABLE audit_logs DROP CONSTRAINT IF EXISTS audit_logs_actor_user_id_fkey;
ALTER TABLE payments ADD COLUMN IF NOT EXISTS verified_by uuid;
CREATE INDEX IF NOT EXISTS idx_sales_orders_business_status_date ON sales_orders(business_id,status,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_products_business_updated ON products(business_id,updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_inventory_balances_updated ON inventory_balances(updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_customers_business_phone ON customers(business_id,phone);
CREATE INDEX IF NOT EXISTS idx_payments_created_status ON payments(status,created_at DESC);
ALTER TABLE sales_orders ADD CONSTRAINT sales_orders_total_nonnegative CHECK (total >= 0) NOT VALID;
ALTER TABLE purchase_orders ADD CONSTRAINT purchase_orders_amounts_nonnegative CHECK (subtotal >= 0 AND additional_costs >= 0 AND amount_paid >= 0) NOT VALID;
