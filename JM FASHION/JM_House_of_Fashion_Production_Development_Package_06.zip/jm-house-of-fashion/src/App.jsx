import React, { useMemo, useState, useEffect } from 'react';
import Login from './Login.jsx';
import { api, clearSession, getSessionUser, getToken } from './api.js';
import {
  LayoutDashboard, ShoppingBag, Package, Users, ClipboardList, Wallet,
  BarChart3, Settings, Search, Bell, Plus, ArrowUpRight, ArrowDownRight,
  MoreHorizontal, Eye, Heart, ShoppingCart, Menu, X, Store, Monitor,
  ShieldCheck, Smartphone, Banknote, Truck, CalendarDays, ChevronDown,
  SlidersHorizontal, Sparkles, CircleHelp, LogOut, Check, Clock3, Image,
  ReceiptText, BadgePercent, ChartNoAxesCombined, ScanBarcode
} from 'lucide-react';

const products = [
  { id: 1, name: 'Satin Evening Dress', category: 'Nguo za kike', price: 85000, stock: 12, tag: 'New arrival', image: 'https://images.unsplash.com/photo-1566206091558-7f218b696731?w=900&q=85' },
  { id: 2, name: 'Classic Mini Handbag', category: 'Pochi za kike', price: 65000, stock: 8, tag: 'Bestseller', image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=900&q=85' },
  { id: 3, name: 'Elegant Everyday Set', category: 'Nguo za kike', price: 72000, stock: 15, tag: 'Popular', image: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?w=900&q=85' },
  { id: 4, name: 'Rose Gold Watch', category: 'Saa za kike', price: 95000, stock: 5, tag: 'Limited', image: 'https://images.unsplash.com/photo-1524592094714-0f0654e20314?w=900&q=85' },
  { id: 5, name: 'Modern Sunglasses', category: 'Miwani ya kike', price: 35000, stock: 21, tag: 'Trending', image: 'https://images.unsplash.com/photo-1511499767150-a48a237f0083?w=900&q=85' },
  { id: 6, name: 'Chic Shoulder Bag', category: 'Pochi za kike', price: 78000, stock: 9, tag: 'New arrival', image: 'https://images.unsplash.com/photo-159087 턀?'.replace(' 턀?','') }
];
products[5].image = 'https://images.unsplash.com/photo-1590874103328-eac38a683ce7?w=900&q=85';

const money = n => new Intl.NumberFormat('en-TZ', { style: 'currency', currency: 'TZS', maximumFractionDigits: 0 }).format(n).replace('TZS', 'TSh');

function Logo({ small = false }) {
  return <div className="brand-lockup">
    <div className="brand-mark">JM</div>
    {!small && <div><div className="brand-name">JM HOUSE</div><div className="brand-sub">OF FASHION</div></div>}
  </div>;
}

function Sidebar({ mode, setMode, page, setPage, mobileOpen, close }) {
  const adminItems = [
    ['Overview', LayoutDashboard], ['Products', Package], ['Inventory', ClipboardList],
    ['Sales & POS', ScanBarcode], ['Customer Orders', ShoppingBag], ['Suppliers', Truck],
    ['Agency Services', Wallet], ['Reports', BarChart3], ['Customers & Team', Users], ['Settings', Settings]
  ];
  return <aside className={`sidebar ${mobileOpen ? 'open' : ''}`}>
    <div className="sidebar-top"><Logo /><button className="icon-btn close-sidebar" onClick={close}><X size={18}/></button></div>
    <div className="workspace-label">WORKSPACE</div>
    <div className="mode-switch">
      <button className={mode === 'admin' ? 'selected' : ''} onClick={() => {setMode('admin'); setPage('Overview'); close();}}><LayoutDashboard size={16}/> Owner</button>
      <button className={mode === 'shop' ? 'selected' : ''} onClick={() => {setMode('shop'); setPage('Shop'); close();}}><ShoppingBag size={16}/> Storefront</button>
      <button className={mode === 'tv' ? 'selected' : ''} onClick={() => {setMode('tv'); setPage('Display'); close();}}><Monitor size={16}/> TV Display</button>
    </div>
    <div className="workspace-label">{mode === 'admin' ? 'MANAGEMENT' : mode === 'shop' ? 'DISCOVER' : 'DISPLAY'}</div>
    <nav className="nav-list">
      {(mode === 'admin' ? adminItems : mode === 'shop' ? [['Shop', ShoppingBag], ['My Orders', ClipboardList]] : [['Display', Monitor]]).map(([label, Icon]) =>
        <button key={label} className={`nav-item ${page === label ? 'active' : ''}`} onClick={() => {setPage(label); close();}}>
          <Icon size={18}/><span>{label}</span>{label === 'Customer Orders' && <i className="nav-count">4</i>}
        </button>
      )}
    </nav>
    <div className="sidebar-bottom">
      <div className="help-card"><div className="help-icon"><CircleHelp size={17}/></div><b>Need a hand?</b><p>Get help setting up your boutique.</p><button onClick={() => alert('Support contact will be configured during deployment.')}>Contact support <ArrowUpRight size={13}/></button></div>
      <div className="profile-row"><div className="avatar">JM</div><div className="profile-copy"><b>Store Owner</b><span>Administrator</span></div><MoreHorizontal size={19} className="muted"/></div>
    </div>
  </aside>;
}

function Header({ page, setMobileOpen, mode, user, onLogout }) {
  return <header className="topbar">
    <button className="icon-btn mobile-menu" onClick={() => setMobileOpen(true)}><Menu size={20}/></button>
    <div className="breadcrumb"><span>{mode === 'admin' ? 'Workspace' : mode === 'shop' ? 'JM Boutique' : 'Public display'}</span><b>/</b><strong>{page}</strong></div>
    <div className="top-actions">
      <div className="date-pill"><CalendarDays size={15}/> {new Intl.DateTimeFormat('en-GB',{dateStyle:'medium'}).format(new Date())}</div>
      <button className="icon-btn notification"><Bell size={18}/><i/></button>
      <button className="top-avatar logout-avatar" title="Sign out" onClick={onLogout}>{(user?.name || 'JM').slice(0,2).toUpperCase()}</button>
    </div>
  </header>;
}

function StatCard({ title, value, change, positive, icon: Icon, note }) {
  return <div className="stat-card">
    <div className="stat-top"><span>{title}</span><div className="stat-icon"><Icon size={18}/></div></div>
    <div className="stat-value">{value}</div>
    <div className="stat-bottom"><span className={positive ? 'trend up' : 'trend down'}>{positive ? <ArrowUpRight size={14}/> : <ArrowDownRight size={14}/>} {change}</span><span className="stat-note">{note}</span></div>
  </div>;
}

function SalesChart() {
  const bars = [38,52,45,68,56,75,62,83,69,92,73,88];
  return <div className="chart-wrap">
    <div className="chart-y"><span>1.2m</span><span>900k</span><span>600k</span><span>300k</span><span>0</span></div>
    <div className="chart-main">
      <div className="chart-grid"><i/><i/><i/><i/><i/></div>
      <div className="bars">{bars.map((h,i)=><div className="bar-column" key={i}><div className={`bar ${i===9?'highlight':''}`} style={{height:`${h}%`}}/></div>)}</div>
      <div className="chart-x"><span>01 Nov</span><span>05 Nov</span><span>10 Nov</span><span>15 Nov</span><span>20 Nov</span></div>
    </div>
  </div>;
}

function Dashboard({user}) {
  const [summary,setSummary]=useState(null); const [reportError,setReportError]=useState('');
  useEffect(()=>{api('/reports/summary?period=month').then(setSummary).catch(e=>setReportError(e.message));},[]);
  const sales=Number(summary?.sales?.completed_sales||0), expenses=Number(summary?.expenses?.expense_total||0), stock=Number(summary?.stock?.units_in_stock||0);
  return <div className="page-content">
    <div className="welcome-row"><div><div className="eyebrow"><Sparkles size={14}/> YOUR BUSINESS AT A GLANCE</div><h1>Good afternoon, <em>{user?.name||'Welcome back.'}</em></h1><p>Here’s what’s happening at JM House of Fashion today.</p></div><button className="primary-btn"><Plus size={17}/> New transaction</button></div>
    <div className="stats-grid">
      <StatCard title="Completed sales · month" value={money(sales)} change="Database" positive note="verified completed orders" icon={Banknote}/>
      <StatCard title="Orders received · month" value={String(summary?.sales?.order_count??'—')} change="Database" positive note="all order statuses" icon={ShoppingBag}/>
      <StatCard title="Units in stock" value={stock.toLocaleString('en-TZ')} change="Live inventory" positive note="current on-hand units" icon={Package}/>
      <StatCard title="Sales less recorded expenses" value={money(sales-expenses)} change="Before other costs" positive={sales>=expenses} note="month to date" icon={ChartNoAxesCombined}/>
    </div>
    {reportError&&<div className="login-error">Dashboard data unavailable: {reportError}</div>}<div className="dashboard-grid">
      <section className="panel sales-panel">
        <div className="panel-heading"><div><h3>Sales performance</h3><p>Track your boutique revenue over time</p></div><select defaultValue="7"><option value="7">Last 20 days</option><option>This month</option><option>This year</option></select></div>
        <div className="chart-legend"><span><i className="legend-dot"/></span> Sales revenue <b>TSh 8,450,000</b><small className="positive-text">+14.6%</small></div>
        <SalesChart/>
      </section>
      <section className="panel activity-panel">
        <div className="panel-heading"><div><h3>Recent activity</h3><p>Latest store updates</p></div><button className="text-btn">View all</button></div>
        <div className="activity-list">
          <Activity icon={ShoppingBag} title="New order received" detail="Order #JMF-1048 · Online" time="8 min ago" tone="rose"/>
          <Activity icon={Banknote} title="POS sale completed" detail="TSh 125,000 · Cash" time="32 min ago" tone="gold"/>
          <Activity icon={Package} title="Stock updated" detail="12 items · New arrivals" time="1 hr ago" tone="sage"/>
          <Activity icon={Users} title="New customer registered" detail="Customer account created" time="2 hrs ago" tone="lilac"/>
        </div>
      </section>
    </div>
    <section className="panel products-panel">
      <div className="panel-heading"><div><h3>Popular products</h3><p>Your most viewed boutique pieces</p></div><button className="text-btn">View inventory <ArrowUpRight size={14}/></button></div>
      <div className="popular-grid">{products.slice(0,4).map(p=><div className="popular-item" key={p.id}><img src={p.image} alt={p.name}/><div><b>{p.name}</b><span>{p.category}</span><strong>{money(p.price)}</strong></div><span className="sold-tag">{p.stock} in stock</span></div>)}</div>
    </section>
  </div>;
}
function Activity({icon:Icon,title,detail,time,tone}) {
  return <div className="activity-item"><div className={`activity-icon ${tone}`}><Icon size={16}/></div><div className="activity-copy"><b>{title}</b><span>{detail}</span></div><time>{time}</time></div>;
}

function ProductsPage({ addToCart, mode, user }) {
  const [filter,setFilter] = useState('All items');
  const [query,setQuery] = useState('');
  const [items,setItems] = useState([]);
  const [loading,setLoading] = useState(true);
  const [error,setError] = useState('');
  const [notice,setNotice] = useState('');
  const [showForm,setShowForm] = useState(false);
  const [form,setForm] = useState({name:'',sku:'',description:'',sellingPrice:'',category:'',size:'',colour:'',openingStock:'0',isPublished:true});
  const categories = ['All items',...new Set(items.map(p=>p.category).filter(Boolean))];
  async function load(){setLoading(true);setError('');try{const data=mode==='admin'?await api('/products/manage'):await api(`/products?businessId=${encodeURIComponent(user?.businessId||import.meta.env.VITE_BUSINESS_ID||'')}`);setItems(data.products||[]);}catch(e){setError(e.message);}finally{setLoading(false);}}
  useEffect(()=>{load();},[mode,user?.businessId]);
  const filtered = useMemo(() => items.filter(p => (filter==='All items'||p.category===filter) && p.name.toLowerCase().includes(query.toLowerCase())),[items,filter,query]);
  async function saveProduct(e){e.preventDefault();setError('');setNotice('');try{let categoryId=null;if(form.category.trim()){const c=await api('/products/categories',{method:'POST',body:JSON.stringify({name:form.category.trim()})});categoryId=c.category.id;}await api('/products',{method:'POST',body:JSON.stringify({name:form.name,sku:form.sku||undefined,description:form.description,sellingPrice:Number(form.sellingPrice),categoryId,isPublished:form.isPublished,variants:[{size:form.size||undefined,colour:form.colour||undefined,openingStock:Number(form.openingStock)}]})});setNotice('Bidhaa imehifadhiwa kwenye database.');setShowForm(false);setForm({name:'',sku:'',description:'',sellingPrice:'',category:'',size:'',colour:'',openingStock:'0',isPublished:true});await load();}catch(e){setError(e.message);}}
  return <div className="page-content">
    <div className="welcome-row"><div><div className="eyebrow"><Sparkles size={14}/> {mode==='admin'?'CATALOGUE MANAGEMENT':'THE BOUTIQUE COLLECTION'}</div><h1>{mode==='admin'?<>Manage your <em>collection.</em></>:<>Discover your <em>style.</em></>}</h1><p>{mode==='admin'?'Add products, manage prices, variants and publication status.':'Thoughtfully selected pieces to make every moment feel special.'}</p></div>{mode==='admin'?<button className="primary-btn" onClick={()=>setShowForm(v=>!v)}><Plus size={17}/> Add product</button>:<div className="secure-note"><ShieldCheck size={16}/> Official JM Boutique collection</div>}</div>
    {error&&<div className="login-error" role="alert">{error}</div>}{notice&&<div className="status-pill"><Check size={13}/>{notice}</div>}
    {showForm&&mode==='admin'&&<section className="panel" style={{marginBottom:18}}><div className="panel-heading"><div><h3>New product</h3><p>Record a product and its first size/colour variant.</p></div><button className="text-btn" onClick={()=>setShowForm(false)}>Close</button></div><form className="product-form" onSubmit={saveProduct}><div className="form-grid"><label>Product name<input required value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/></label><label>SKU (optional)<input value={form.sku} onChange={e=>setForm({...form,sku:e.target.value})}/></label><label>Category<input required placeholder="e.g. Nguo za kike" value={form.category} onChange={e=>setForm({...form,category:e.target.value})}/></label><label>Selling price (TZS)<input required type="number" min="0" step="1" value={form.sellingPrice} onChange={e=>setForm({...form,sellingPrice:e.target.value})}/></label><label>Size<input placeholder="e.g. M, L, XL" value={form.size} onChange={e=>setForm({...form,size:e.target.value})}/></label><label>Colour<input placeholder="e.g. Black" value={form.colour} onChange={e=>setForm({...form,colour:e.target.value})}/></label><label>Opening stock<input type="number" min="0" value={form.openingStock} onChange={e=>setForm({...form,openingStock:e.target.value})}/></label><label>Description<input value={form.description} onChange={e=>setForm({...form,description:e.target.value})}/></label></div><label className="publish-check"><input type="checkbox" checked={form.isPublished} onChange={e=>setForm({...form,isPublished:e.target.checked})}/> Publish in customer storefront and TV display</label><button className="primary-btn" type="submit"><Check size={16}/> Save product</button></form></section>}
    <div className="shop-toolbar"><div className="search-box"><Search size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search products..."/></div><button className="filter-btn" onClick={load}><SlidersHorizontal size={16}/> Refresh</button></div>
    <div className="category-chips">{categories.map(c=><button key={c} className={filter===c?'chosen':''} onClick={()=>setFilter(c)}>{c}</button>)}</div>
    {loading?<div className="coming-panel"><div className="coming-icon"><Clock3/></div><h2>Loading catalogue</h2><p>Connecting to JM House of Fashion database…</p></div>:filtered.length===0?<div className="coming-panel"><div className="coming-icon"><Package/></div><h2>No products found</h2><p>{mode==='admin'?'Add your first real product to populate the catalogue.':'The store catalogue will appear here when products are published.'}</p></div>:<div className="product-grid">{filtered.map(p=><article className="product-card" key={p.id}><div className="product-photo">{p.images?.[0]?.storageKey?<img src={p.images[0].storageKey} alt={p.name}/>:<div className="product-placeholder"><Image size={30}/><span>Product image</span></div>}{mode==='admin'&&<span className="product-tag">{p.is_published?'Published':'Draft'}</span>}</div><div className="product-info"><span>{p.category||'Uncategorised'} {mode==='admin'&&` · ${p.stock??0} in stock`}</span><h3>{p.name}</h3><div className="product-price-row"><b>{money(Number(p.selling_price))}</b>{mode==='shop'&&<button disabled={!p.variants?.some(v=>v.available)} onClick={()=>addToCart({...p,variantId:p.variants?.find(v=>v.available)?.id})} aria-label="Add to cart"><Plus size={17}/></button>}</div></div></article>)}</div>}
  </div>;
}

function OrdersPage(){
  const [orders,setOrders]=useState([]),[loading,setLoading]=useState(true),[error,setError]=useState(''),[refs,setRefs]=useState({}),[busy,setBusy]=useState('');
  async function load(){setLoading(true);setError('');try{const d=await api('/fulfilment');setOrders(d.orders||[]);}catch(e){setError(e.message);}finally{setLoading(false);}}
  useEffect(()=>{load();},[]);
  async function updateStatus(order,status){setBusy(order.id);setError('');try{await api(`/fulfilment/${order.id}/status`,{method:'PATCH',body:JSON.stringify({status})});await load();}catch(e){setError(e.message);}finally{setBusy('');}}
  async function verify(order,payment){const reference=refs[payment.id]?.trim();if(!reference){setError('Weka payment reference kabla ya kuthibitisha malipo.');return;}setBusy(payment.id);try{await api(`/fulfilment/${order.id}/verify-payment`,{method:'POST',body:JSON.stringify({paymentId:payment.id,reference})});await load();}catch(e){setError(e.message);}finally{setBusy('');}}
  const nextStatus={pending_payment:['confirmed','cancelled'],pending:['confirmed','cancelled'],confirmed:['processing','cancelled'],processing:['ready_for_pickup','out_for_delivery','cancelled'],ready_for_pickup:['completed','cancelled'],out_for_delivery:['completed','cancelled']};
  return <div className="page-content"><div className="welcome-row"><div><div className="eyebrow"><ShoppingBag size={14}/> ONLINE SALES</div><h1>Customer <em>orders.</em></h1><p>Review orders, verify payments and manage fulfilment.</p></div><button className="primary-btn" onClick={load}><ArrowUpRight size={16}/> Refresh orders</button></div>{error&&<div className="login-error">{error}</div>}{loading?<div className="coming-panel"><Clock3/><h2>Loading orders</h2></div>:orders.length===0?<div className="coming-panel"><ShoppingBag/><h2>No online orders yet</h2><p>Customer orders will appear here after checkout.</p></div>:<div className="order-list">{orders.map(o=><section className="panel order-card" key={o.id}><div className="order-top"><div><b>{o.order_number||o.id.slice(0,8)}</b><span>{o.customer_name} · {o.customer_phone}</span><small>{new Date(o.created_at).toLocaleString()}</small></div><strong>{money(Number(o.total))}</strong></div><div className="order-lines">{o.lines?.map((l,i)=><div key={i}>{l.product} {l.size||''} {l.colour||''} × {l.quantity}</div>)}</div><div className="payment-list">{o.payments?.map(p=><div className="payment-row" key={p.id}><span>{p.method}{p.provider?` · ${p.provider}`:''} · {money(Number(p.amount))}</span><b>{p.status}</b>{p.status==='pending'&&<><input aria-label="Payment reference" placeholder="Payment reference" value={refs[p.id]||''} onChange={e=>setRefs({...refs,[p.id]:e.target.value})}/><button className="text-btn" disabled={busy===p.id} onClick={()=>verify(o,p)}>Verify</button></>}</div>)}</div><div className="order-actions"><span className="status-pill">{o.status.replaceAll('_',' ')}</span>{(nextStatus[o.status]||[]).map(st=><button key={st} className="filter-btn" disabled={!!busy} onClick={()=>updateStatus(o,st)}>{st.replaceAll('_',' ')}</button>)}</div></section>)}</div>}</div>;
}

function SimplePage({page}) {
  const descriptions = {
    Products:'Manage your fashion catalogue, product images, pricing and variations.',
    Inventory:'Monitor stock levels, product movements and stock adjustments.',
    'Sales & POS':'Record in-store sales and issue customer receipts.',
    'Customer Orders':'Review online orders, confirm payments and manage fulfilment.',
    Suppliers:'Manage wholesale suppliers, purchase invoices and outstanding balances.',
    'Agency Services':'Manage mobile money and bank agency transactions and reconciliation.',
    Reports:'Review daily, weekly, monthly and annual business performance.',
    'Customers & Team':'Manage customer records, employee accounts and access permissions.',
    Settings:'Configure your boutique, payment channels, security and application preferences.',
    'My Orders':'Review your purchases and order delivery status.',
    Display:'Public product slideshow for your in-store Smart TV.'
  };
  return <div className="page-content"><div className="welcome-row"><div><div className="eyebrow"><Sparkles size={14}/> JM HOUSE OF FASHION</div><h1>{page}</h1><p>{descriptions[page] || 'Manage your boutique operations from one place.'}</p></div></div><div className="coming-panel"><div className="coming-icon"><Sparkles size={25}/></div><h2>{page} workspace</h2><p>This module is included in the project architecture. Its database-backed workflows will be implemented in the next development phase.</p><span className="status-pill"><Clock3 size={13}/> Module scaffold created</span></div></div>;
}

function TVDisplay({businessId}) {
  const [items,setItems]=useState([]); const [error,setError]=useState('');
  useEffect(()=>{if(!businessId){setError('Configure VITE_BUSINESS_ID before opening public display.');return;}api(`/display/products?businessId=${encodeURIComponent(businessId)}`).then(d=>setItems(d.products||[])).catch(e=>setError(e.message));},[businessId]);
  const hero=items[0];
  return <div className="tv-screen"><div className="tv-head"><Logo/><span>THE NEW COLLECTION</span><span>SHINYANGA · TANZANIA</span></div><div className="tv-hero"><div><div className="eyebrow">JM HOUSE OF FASHION PRESENTS</div><h1>Style is a way<br/>to <em>express yourself.</em></h1><p>Discover pieces made to celebrate your individuality.</p><div className="tv-cta">EXPLORE OUR COLLECTION</div></div>{hero?.images?.[0]?.storageKey?<img src={hero.images[0].storageKey} alt={hero.name}/>:<div className="product-placeholder"><Image size={34}/><span>{error||'Publish products to show your collection'}</span></div>}</div><div className="tv-products">{items.slice(1,5).map(p=><div key={p.id}>{p.images?.[0]?.storageKey?<img src={p.images[0].storageKey} alt={p.name}/>:<div className="product-placeholder"><Image/></div>}<b>{p.name}</b><span>{money(Number(p.selling_price))}</span></div>)}</div><div className="tv-foot">JM HOUSE OF FASHION <span>MOLEKA STREET, SHINYANGA</span><span>WELCOME IN</span></div></div>;
}

function CheckoutDialog({cart,onClose,onSuccess}){
  const [form,setForm]=useState({customerName:'',phone:'',email:'',deliveryAddress:'',region:'Shinyanga',paymentMethod:'mobile_money',provider:'M-Pesa'});
  const [busy,setBusy]=useState(false),[error,setError]=useState(''),[result,setResult]=useState(null);
  const total=cart.reduce((n,p)=>n+Number(p.selling_price)*p.quantity,0);
  async function submit(e){e.preventDefault();setBusy(true);setError('');try{const businessId=import.meta.env.VITE_BUSINESS_ID;if(!businessId)throw new Error('Store checkout is not configured yet.');const d=await api('/checkout',{method:'POST',body:JSON.stringify({...form,businessId,lines:cart.map(p=>({variantId:p.variantId,quantity:p.quantity}))})});setResult(d);onSuccess();}catch(e){setError(e.message);}finally{setBusy(false);}}
  return <div className="checkout-backdrop"><section className="checkout-modal"><button className="checkout-close" onClick={onClose}>×</button>{result?<><div className="coming-icon"><Check/></div><h2>Oda limepokelewa</h2><p>Hifadhi taarifa hizi ili kufuatilia oda yako.</p><div className="tracking-details"><b>{result.order.order_number}</b><span>Tracking token</span><code>{result.trackingToken}</code></div><button className="primary-btn" onClick={onClose}>Maliza</button></>:<><div className="eyebrow">JM HOUSE OF FASHION · CHECKOUT</div><h2>Complete your <em>order.</em></h2><div className="checkout-total">Jumla ya oda <b>{money(total)}</b></div><form onSubmit={submit} className="checkout-form"><label>Jina kamili<input required value={form.customerName} onChange={e=>setForm({...form,customerName:e.target.value})}/></label><label>Namba ya simu<input required value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})} placeholder="07XXXXXXXX"/></label><label>Barua pepe (hiari)<input type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})}/></label><label>Anuani ya kufikishiwa<input required value={form.deliveryAddress} onChange={e=>setForm({...form,deliveryAddress:e.target.value})}/></label><label>Mkoa<input value={form.region} onChange={e=>setForm({...form,region:e.target.value})}/></label><label>Njia ya malipo<select value={form.paymentMethod} onChange={e=>setForm({...form,paymentMethod:e.target.value})}><option value="mobile_money">Mobile money</option><option value="bank_transfer">Bank transfer</option><option value="cash_on_delivery">Cash on delivery</option></select></label>{form.paymentMethod==='mobile_money'&&<label>Mtandao<select value={form.provider} onChange={e=>setForm({...form,provider:e.target.value})}><option>M-Pesa</option><option>Tigo Pesa</option><option>Airtel Money</option><option>HaloPesa</option></select></label>}{error&&<div className="login-error">{error}</div>}<button className="primary-btn login-submit" disabled={busy}>{busy?'Inatuma oda…':'Place order'}</button></form></>}</section></div>;
}

export default function App() {
  const [user,setUser] = useState(getSessionUser());
  const [authChecked,setAuthChecked] = useState(!getToken());
  useEffect(()=>{ if(!getToken()) return; api('/auth/me').then(({user:u})=>setUser({id:u.id,name:u.display_name,role:u.role,businessId:u.business_id})).catch(()=>{clearSession();setUser(null);}).finally(()=>setAuthChecked(true)); },[]);
  const publicView = new URLSearchParams(window.location.search).get('view');
  const [mode,setMode] = useState(publicView==='shop'?'shop':publicView==='tv'?'tv':'admin');
  const [page,setPage] = useState(publicView==='shop'?'Shop':publicView==='tv'?'Display':'Overview');
  const [mobileOpen,setMobileOpen] = useState(false);
  const [cart,setCart] = useState([]);
  const [checkoutOpen,setCheckoutOpen] = useState(false);
  const addToCart = p => {if(!p.variantId){alert('Bidhaa hii haina variant/stock inayopatikana kwa sasa.');return;}setCart(old=>{const i=old.findIndex(x=>x.variantId===p.variantId);if(i<0)return [...old,{...p,quantity:1}];return old.map((x,n)=>n===i?{...x,quantity:x.quantity+1}:x);});};
  const close = () => setMobileOpen(false);
  if (!authChecked) return <main className="login-screen"><div className="login-loading">Securing your workspace…</div></main>;
  if (!user && mode==='admin') return <Login onLogin={setUser}/>;
  if (mode === 'tv') return <TVDisplay businessId={user?.businessId||import.meta.env.VITE_BUSINESS_ID}/>;
  return <div className="app-shell">
    <Sidebar mode={mode} setMode={setMode} page={page} setPage={setPage} mobileOpen={mobileOpen} close={close}/>
    {mobileOpen && <div className="scrim" onClick={close}/>}
    <main className="main-area">
      <Header page={page} setMobileOpen={setMobileOpen} mode={mode} user={user} onLogout={()=>{clearSession();setUser(null);setMode('admin');setPage('Overview');}}/>
      {mode === 'admin' ? page === 'Overview' ? <Dashboard user={user}/> : page === 'Products' ? <ProductsPage addToCart={addToCart} mode={mode} user={user}/> : page === 'Customer Orders' ? <OrdersPage/> : <SimplePage page={page}/> : page === 'Shop' ? <ProductsPage addToCart={addToCart} mode={mode} user={user}/> : <SimplePage page={page}/>}
    </main>
    {mode === 'shop' && <button className="cart-fab" onClick={()=>setCheckoutOpen(true)}><ShoppingCart size={19}/><span>{cart.reduce((n,p)=>n+p.quantity,0)}</span></button>}
    {checkoutOpen&&<CheckoutDialog cart={cart} onClose={()=>setCheckoutOpen(false)} onSuccess={()=>setCart([])}/>}
  </div>;
}
