# JM House of Fashion — production release runbook

This runbook is a deployment procedure, not evidence that cloud services have already been provisioned.

## Release gates

A release is **NO-GO** until every required gate below is evidenced in the target environment.

- [ ] Production PostgreSQL is provisioned with private network access and automated backups/PITR.
- [ ] Backend secrets are stored in the hosting provider's secret manager; none are committed to Git.
- [ ] TLS is enabled for frontend and API; `CORS_ORIGINS` contains exact HTTPS origins only.
- [ ] `JWT_SECRET` is a cryptographically random secret of at least 32 characters.
- [ ] Migrations 001–010 have been applied and recorded in `schema_migrations`.
- [ ] A single owner account has been bootstrapped using a one-time secret; bootstrap variables have been removed.
- [ ] Cloudinary uploads have been tested with a real product and the API secret remains server-side.
- [ ] Owner, staff, storefront and TV access have been tested using separate accounts/browser profiles.
- [ ] Stock reservation, POS deduction, cancellation, return, refund and duplicate-submit flows pass against PostgreSQL.
- [ ] Mobile-money/bank payment is disabled until an approved provider integration and signed webhook are live.
- [ ] Agency float entries are reconciled against real provider statements; they are not described as live integrations.
- [ ] Privacy notice, terms, return policy, delivery charges/areas and contact details have been reviewed and completed.
- [ ] Backup restore has been tested; monitoring, alerting and incident contacts are configured.
- [ ] Security review, dependency audit, load test and browser/device acceptance tests pass.

## Environment variables

### Backend

- `NODE_ENV=production`
- `PORT` supplied by the host
- `DATABASE_URL` private PostgreSQL connection string
- `DATABASE_SSL=true` where required by the database host
- `JWT_SECRET` random secret (32+ characters)
- `JWT_EXPIRES_IN=8h` (review against operational policy)
- `CORS_ORIGINS=https://your-store-domain.example` exact origin list, comma-separated
- `TRUST_PROXY=true` only when the API is behind a trusted single reverse proxy/load balancer
- `CLOUDINARY_CLOUD_NAME`, `CLOUDINARY_API_KEY`, `CLOUDINARY_API_SECRET` server-side only

### Frontend build

- `VITE_API_BASE_URL=https://your-api-domain.example/api`
- `VITE_BUSINESS_ID` public business UUID (not a credential)

Never put `DATABASE_URL`, `JWT_SECRET`, Cloudinary API secret, payment API secrets or webhook secrets in `VITE_*` variables.

## Database and owner bootstrap

1. Create a database and a restricted runtime role. Keep migration credentials separate where possible.
2. Configure backend environment variables.
3. From `server/`, run `npm ci` (or `npm install` if no lockfile is committed) and `npm run migrate`.
4. Set `INITIAL_OWNER_NAME`, `INITIAL_OWNER_EMAIL`, and a unique `INITIAL_OWNER_PASSWORD` (14+ characters) temporarily.
5. Run `npm run bootstrap:owner` exactly once; remove all bootstrap variables immediately.
6. Verify the owner can sign in and that an unauthorized user cannot access protected endpoints.

## Health checks

- `GET /api/health/live` confirms the process is alive.
- `GET /api/health/ready` checks PostgreSQL readiness and returns HTTP 503 if unavailable.
- `GET /api/health` is a compatibility check for service and database availability.

## Deployment order

1. Deploy API and verify readiness before directing frontend traffic.
2. Deploy the static Vite frontend to Netlify with the two `VITE_*` build variables.
3. Verify CORS from the exact deployed origin.
4. Run smoke tests with test products/orders and test payment methods only.
5. Verify the customer storefront exposes published product information only.
6. Verify staff roles, employee deactivation, audit history and order tracking-token privacy.
7. Confirm logs contain request IDs but no passwords, tokens, payment secrets or full customer addresses.

## Payment provider release gate

No provider-specific mobile-money or bank API is currently wired into this project. For each provider, obtain merchant approval and credentials, implement signed callback verification, replay protection, provider transaction lookup, idempotency, refund handling and settlement reconciliation. Do not mark a payment verified from a customer-entered reference alone. Until that work is complete, use manual payment verification and clearly communicate it to customers.

## Backups and operations

- Enable automated encrypted daily backups and point-in-time recovery according to the selected database provider.
- Perform a restore drill before launch and at least quarterly thereafter.
- Alert on database unavailability, repeated login failures, elevated 5xx responses, storage upload failures and payment reconciliation differences.
- Define staff access review, employee offboarding, incident response and data-retention procedures.
- Use a separate test/staging database; never test destructive workflows on production records.

## Rollback

1. Stop new traffic or put the storefront into maintenance mode.
2. Roll back the frontend to the last known-good static deploy.
3. Roll back the API image to the last known-good version.
4. Do not automatically reverse schema migrations. Use a reviewed forward-fix or restore from a verified backup when data/schema rollback is required.
5. Reconcile orders, payments, stock and agency float before reopening sales.
