# JM House of Fashion — production readiness and deployment

## Implemented in this development increment
- Private product catalogue endpoint for authorised staff, public published-only catalogue, category creation, product creation with variants and opening stock, and product editing.
- Owner dashboard monthly figures now come from the reports API instead of fixed demo amounts.
- Product management screen reads/writes the API and records variant opening stock in the stock movement ledger.
- Customer storefront can be opened without staff login using `/?view=shop`.
- Smart TV display reads the public published-only display API using `/?view=tv`.
- Customer order management lists orders, payment references and status transitions; authorised staff can verify pending payment references.
- Netlify static build configuration, server Dockerfile, CI workflow, PWA icon and migration 006.

## Environment configuration
Frontend (Netlify build environment):
- `VITE_API_BASE_URL`: absolute HTTPS API base, ending in `/api` (example `https://api.your-domain.tld/api`).
- `VITE_BUSINESS_ID`: public UUID of the business row created by the one-time owner bootstrap. This is an identifier, not a secret.

Backend (private API host):
- `NODE_ENV=production`
- `PORT`
- `DATABASE_URL` (private PostgreSQL connection string)
- `DATABASE_SSL=true` where required by the provider
- `JWT_SECRET` (random secret, at least 32 characters; use a secret manager)
- `JWT_EXPIRES_IN=8h`
- `CORS_ORIGINS` (comma-separated exact HTTPS origins for the storefront and owner app)

## Deployment sequence
1. Provision managed PostgreSQL and a private backend host. Restrict database network access to the backend only.
2. Set backend secrets. Do not put `DATABASE_URL`, `JWT_SECRET`, or bootstrap credentials in frontend variables.
3. Run `cd server && npm install && npm run migrate` against the production database.
4. Set one-time `INITIAL_OWNER_NAME`, `INITIAL_OWNER_EMAIL`, and a unique `INITIAL_OWNER_PASSWORD` of at least 14 characters, then run `npm run bootstrap:owner` once. Remove these three variables immediately afterwards.
5. Retrieve the business UUID from the trusted database/admin console and set it as `VITE_BUSINESS_ID` in Netlify. Set `VITE_API_BASE_URL` to the deployed HTTPS API base and configure `CORS_ORIGINS` to the exact Netlify custom-domain origin(s).
6. Deploy the frontend with `npm install && npm run build`; deploy the backend using `server/Dockerfile` or `cd server && npm install --omit=dev && npm start`.
7. Verify `/api/health`, owner login, product create/publish, customer storefront, test checkout, payment verification, fulfilment, stock movement and reports using test records before accepting real transactions.
8. Configure managed database backups, point-in-time recovery, uptime alerts, log retention, domain TLS and a documented restore drill.

## Important production gates still outstanding
- A real PostgreSQL instance has not been provisioned or migrated from this workspace.
- Frontend dependency installation/build and browser end-to-end tests have not been run in this environment; package installation timed out. CI is configured to run these checks after push.
- Payment provider integrations (M-Pesa, Tigo Pesa, Airtel Money, HaloPesa and bank APIs) require merchant credentials, provider approval, callback URLs, signature verification and reconciliation testing. Current payment verification is manual by authorised staff; it is not a live payment gateway.
- Product image upload requires configured Cloudinary credentials and a production upload/attach verification test. Keep the Cloudinary API secret server-side only.
- POS sales, agency transactions, refunds/returns, customer accounts/notifications and comprehensive annual reporting require their remaining user workflows and tests.
- Android/iOS native packages, store developer accounts, privacy disclosures and store review submissions remain separate release tasks.
- Before public launch, add automated integration tests, restore testing, vulnerability scanning, rate-limit tuning, audit review and a security assessment. Confirm local tax/accounting requirements with a qualified Tanzanian professional.

## Customer and display privacy
Public endpoints return published catalogue information only. Never add cost price, stock balances, customer PII, staff records, internal notes or agency balances to public product/display payloads. All write operations must remain authenticated and role-checked on the server.


## Package 08 additions
- Returns are requested against completed/delivered orders and cannot exceed the quantity not already returned. Return approval is transactional; approved restock movements are recorded in the stock ledger.
- Refunds are recorded as pending manual actions. Marking a refund completed is an operator confirmation only; no mobile-money/bank provider is contacted by this feature.
- Staff notifications are available through `/api/notifications`; owner/manager/accountant audit history is available through `/api/audit`.
- POS API supports an `Idempotency-Key` header to avoid duplicate order creation on retry. Reuse the same key only for the same payload.
- Product image upload supports signed Cloudinary direct uploads. Configure `CLOUDINARY_CLOUD_NAME`, `CLOUDINARY_API_KEY`, and `CLOUDINARY_API_SECRET` on the server only. Never put the API secret in Vite/browser environment variables.
- Apply migration `009_cloud_media.sql` after `008_returns_notifications.sql`.
