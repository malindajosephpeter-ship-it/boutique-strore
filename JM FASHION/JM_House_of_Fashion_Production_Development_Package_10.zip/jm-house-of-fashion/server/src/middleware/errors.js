export function notFound(req, res) {
  res.status(404).json({ error: 'Route not found', requestId: req.requestId });
}

export function errorHandler(err, req, res, next) {
  if (res.headersSent) return next(err);
  const malformedJson = err instanceof SyntaxError && err.status === 400 && 'body' in err;
  const status = malformedJson ? 400 : (Number.isInteger(err.status) && err.status >= 400 && err.status < 600 ? err.status : 500);
  if (status >= 500) console.error(JSON.stringify({ level: 'error', requestId: req.requestId, message: err.message }));
  res.status(status).json({
    error: malformedJson ? 'Malformed JSON request body' : (status >= 500 && process.env.NODE_ENV === 'production' ? 'An unexpected error occurred' : err.message),
    requestId: req.requestId
  });
}
