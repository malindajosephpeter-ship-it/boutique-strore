import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import dotenv from 'dotenv';
import { randomUUID } from 'node:crypto';
import healthRouter from './routes/health.js';
import authRouter from './routes/auth.js';
import productsRouter from './routes/products.js';
import ordersRouter from './routes/orders.js';
import suppliersRouter from './routes/suppliers.js';
import purchasesRouter from './routes/purchases.js';
import expensesRouter from './routes/expenses.js';
import reportsRouter from './routes/reports.js';
import displayRouter from './routes/display.js';
import checkoutRouter from './routes/checkout.js';
import staffRouter from './routes/staff.js';
import customersRouter from './routes/customers.js';
import fulfilmentRouter from './routes/fulfilment.js';
import inventoryRouter from './routes/inventory.js';
import agencyRouter from './routes/agency.js';
import returnsRouter from './routes/returns.js';
import notificationsRouter from './routes/notifications.js';
import auditRouter from './routes/audit.js';
import mediaRouter from './routes/media.js';
import { notFound, errorHandler } from './middleware/errors.js';

dotenv.config();
if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) {
  throw new Error('JWT_SECRET must be configured with at least 32 characters.');
}
if (process.env.NODE_ENV === 'production') {
  if (!process.env.DATABASE_URL) throw new Error('DATABASE_URL is required in production.');
  if (!process.env.CORS_ORIGINS || !process.env.CORS_ORIGINS.trim()) throw new Error('CORS_ORIGINS must contain the exact production frontend origin(s).');
}

const app = express();
const origins = (process.env.CORS_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean);

app.disable('x-powered-by');
if (process.env.TRUST_PROXY === 'true') app.set('trust proxy', 1);
app.use((req, res, next) => {
  req.requestId = randomUUID();
  res.setHeader('X-Request-ID', req.requestId);
  next();
});
app.use(helmet());
app.use(cors({
  origin(origin, callback) {
    if (!origin || origins.includes(origin)) return callback(null, true);
    return callback(new Error('Origin not allowed by CORS'));
  },
  credentials: false
}));
app.use(express.json({ limit: '1mb' }));
app.use('/api/', rateLimit({ windowMs: 60_000, limit: 120, standardHeaders: 'draft-7', legacyHeaders: false }));
app.use('/api/auth/login', rateLimit({ windowMs: 15 * 60_000, limit: 10, standardHeaders: 'draft-7', legacyHeaders: false }));
app.use('/api/checkout', rateLimit({ windowMs: 15 * 60_000, limit: 20, standardHeaders: 'draft-7', legacyHeaders: false }));

app.use('/api/health', healthRouter);
app.use('/api/auth', authRouter);
app.use('/api/products', productsRouter);
app.use('/api/orders', ordersRouter);
app.use('/api/suppliers', suppliersRouter);
app.use('/api/purchases', purchasesRouter);
app.use('/api/expenses', expensesRouter);
app.use('/api/reports', reportsRouter);
app.use('/api/display', displayRouter);
app.use('/api/checkout', checkoutRouter);
app.use('/api/staff', staffRouter);
app.use('/api/customers', customersRouter);
app.use('/api/fulfilment', fulfilmentRouter);
app.use('/api/inventory', inventoryRouter);
app.use('/api/agency', agencyRouter);
app.use('/api/returns', returnsRouter);
app.use('/api/notifications', notificationsRouter);
app.use('/api/audit', auditRouter);
app.use('/api/media', mediaRouter);

app.use(notFound);
app.use(errorHandler);

const port = Number(process.env.PORT || 4000);
const server = app.listen(port, () => console.log(`JM House of Fashion API listening on ${port}`));
let shuttingDown = false;
async function shutdown(signal) {
  if (shuttingDown) return;
  shuttingDown = true;
  console.log(`Received ${signal}; shutting down gracefully.`);
  server.close(async () => {
    try { await (await import('./db.js')).pool.end(); }
    finally { process.exit(0); }
  });
  setTimeout(() => process.exit(1), 10000).unref();
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
