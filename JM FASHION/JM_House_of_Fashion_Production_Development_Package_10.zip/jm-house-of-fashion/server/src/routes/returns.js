import { Router } from 'express';
import { randomBytes } from 'node:crypto';
import { z } from 'zod';
import { pool } from '../db.js';
import { requireAuth, allowRoles } from '../middleware/auth.js';
import { calculateRefundAmount } from '../lib/finance.js';

const router = Router();
router.use(requireAuth);
const canRequest = allowRoles('owner','manager','accountant','sales_attendant');
const canResolve = allowRoles('owner','manager','accountant');

router.get('/', canResolve, async (req,res,next) => {
  try {
    const q = await pool.query(
      `SELECT r.id,r.return_number,r.reason,r.status,r.refund_amount,r.restock,r.created_at,
        o.order_number,o.channel,o.total,c.full_name AS customer_name
       FROM sales_returns r JOIN sales_orders o ON o.id=r.order_id
       LEFT JOIN customers c ON c.id=o.customer_id
       WHERE r.business_id=$1 ORDER BY r.created_at DESC LIMIT 200`, [req.user.businessId]);
    res.json({ returns:q.rows });
  } catch(e){ next(e); }
});

router.post('/', canRequest, async (req,res,next) => {
  const parsed = z.object({ orderId:z.string().uuid(), reason:z.string().trim().min(3).max(500), restock:z.boolean().default(true), lines:z.array(z.object({ orderLineId:z.string().uuid(), quantity:z.number().int().positive().max(100) })).min(1).max(50) }).safeParse(req.body);
  if(!parsed.success) return res.status(400).json({error:'Invalid return request',details:parsed.error.flatten()});
  const d=parsed.data, client=await pool.connect();
  try {
    await client.query('BEGIN');
    const order=await client.query("SELECT id,status,total FROM sales_orders WHERE id=$1 AND business_id=$2 FOR UPDATE",[d.orderId,req.user.businessId]);
    if(!order.rowCount) throw Object.assign(new Error('Order not found'),{status:404});
    if(!['completed','fulfilled','delivered'].includes(order.rows[0].status)) throw Object.assign(new Error('Only completed or delivered orders can be returned'),{status:409});
    const selected=[];
    for(const line of d.lines){
      const q=await client.query(`SELECT l.id,l.variant_id,l.quantity,l.unit_price,
        COALESCE((SELECT SUM(rl.quantity) FROM sales_return_lines rl JOIN sales_returns rr ON rr.id=rl.return_id WHERE rl.order_line_id=l.id AND rr.status IN ('requested','approved','refunded')),0)::int AS already_returned
        FROM sales_order_lines l WHERE l.id=$1 AND l.order_id=$2 FOR UPDATE`,[line.orderLineId,d.orderId]);
      if(!q.rowCount) throw Object.assign(new Error('Order line not found'),{status:404});
      const row=q.rows[0]; if(line.quantity>row.quantity-row.already_returned) throw Object.assign(new Error('Return quantity exceeds the unreturned quantity'),{status:409});
      selected.push({...line,variantId:row.variant_id,unitPrice:Number(row.unit_price)});
    }
    const refundAmount=calculateRefundAmount(selected.map(line=>({unitPrice:line.unitPrice,quantity:line.quantity})));
    const returnNumber=`JMR-${Date.now().toString().slice(-8)}-${randomBytes(2).toString('hex').toUpperCase()}`;
    const created=await client.query(`INSERT INTO sales_returns(business_id,order_id,return_number,reason,refund_amount,restock,requested_by)
      VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING id,return_number,status,refund_amount,created_at`,[req.user.businessId,d.orderId,returnNumber,d.reason,refundAmount,d.restock,req.user.sub]);
    for(const line of selected) await client.query('INSERT INTO sales_return_lines(return_id,order_line_id,variant_id,quantity,unit_price) VALUES($1,$2,$3,$4,$5)',[created.rows[0].id,line.orderLineId,line.variantId,line.quantity,line.unitPrice]);
    await client.query(`INSERT INTO staff_notifications(business_id,user_id,notification_type,title,body,entity_type,entity_id)
      SELECT business_id,id,'return_requested','Return requested',$2,'sales_return',$3 FROM app_users WHERE business_id=$1 AND is_active=true AND role IN ('owner','manager','accountant')`,[req.user.businessId,`Return ${returnNumber} requires review.`,created.rows[0].id]);
    await client.query(`INSERT INTO audit_logs(business_id,actor_user_id,action,entity_type,entity_id,metadata) VALUES($1,$2,'return_requested','sales_return',$3,$4)`,[req.user.businessId,req.user.sub,created.rows[0].id,JSON.stringify({orderId:d.orderId,refundAmount,restock:d.restock})]);
    await client.query('COMMIT'); res.status(201).json({return:created.rows[0]});
  } catch(e){await client.query('ROLLBACK');next(e);} finally{client.release();}
});

router.post('/:id/resolve', canResolve, async(req,res,next)=>{
  const parsed=z.object({decision:z.enum(['approve','reject']),refundMethod:z.enum(['cash','mobile_money','bank','card','manual']).default('manual'),note:z.string().trim().max(500).optional()}).safeParse(req.body);
  if(!parsed.success)return res.status(400).json({error:'Invalid return decision',details:parsed.error.flatten()});
  const c=await pool.connect();
  try{
    await c.query('BEGIN');
    const q=await c.query('SELECT * FROM sales_returns WHERE id=$1 AND business_id=$2 FOR UPDATE',[req.params.id,req.user.businessId]);
    if(!q.rowCount)throw Object.assign(new Error('Return not found'),{status:404});
    const r=q.rows[0]; if(r.status!=='requested')throw Object.assign(new Error('Return has already been resolved'),{status:409});
    if(parsed.data.decision==='reject'){
      await c.query("UPDATE sales_returns SET status='rejected',resolved_by=$2,resolved_at=now() WHERE id=$1",[r.id,req.user.sub]);
    }else{
      const lines=await c.query('SELECT variant_id,quantity FROM sales_return_lines WHERE return_id=$1',[r.id]);
      if(r.restock) for(const line of lines.rows){
        await c.query('UPDATE inventory_balances SET quantity_on_hand=quantity_on_hand+$2,updated_at=now() WHERE variant_id=$1',[line.variant_id,line.quantity]);
        await c.query(`INSERT INTO stock_movements(business_id,variant_id,movement_type,quantity_delta,reference_type,reference_id,created_by) VALUES($1,$2,'return',$3,'sales_return',$4,$5)`,[req.user.businessId,line.variant_id,line.quantity,r.id,req.user.sub]);
      }
      await c.query("UPDATE sales_returns SET status='approved',resolved_by=$2,resolved_at=now() WHERE id=$1",[r.id,req.user.sub]);
      if(Number(r.refund_amount)>0) await c.query(`INSERT INTO refunds(business_id,return_id,order_id,amount,method,status) VALUES($1,$2,$3,$4,$5,'pending')`,[req.user.businessId,r.id,r.order_id,r.refund_amount,parsed.data.refundMethod]);
    }
    await c.query(`INSERT INTO audit_logs(business_id,actor_user_id,action,entity_type,entity_id,metadata) VALUES($1,$2,'return_resolved','sales_return',$3,$4)`,[req.user.businessId,req.user.sub,r.id,JSON.stringify({decision:parsed.data.decision,note:parsed.data.note||null})]);
    await c.query('COMMIT');res.json({id:r.id,status:parsed.data.decision==='approve'?'approved':'rejected',refundAmount:r.refund_amount,refundStatus:parsed.data.decision==='approve'&&Number(r.refund_amount)>0?'pending_manual':'not_required'});
  }catch(e){await c.query('ROLLBACK');next(e);}finally{c.release();}
});

router.post('/:id/mark-refunded', canResolve, async(req,res,next)=>{
  const parsed=z.object({reference:z.string().trim().min(2).max(120).optional()}).safeParse(req.body);
  if(!parsed.success)return res.status(400).json({error:'Invalid refund reference'});
  const c=await pool.connect();
  try{
    await c.query('BEGIN');
    const q=await c.query(`SELECT f.id,f.return_id,f.amount,f.status FROM refunds f JOIN sales_returns r ON r.id=f.return_id WHERE f.return_id=$1 AND f.business_id=$2 FOR UPDATE OF f`,[req.params.id,req.user.businessId]);
    if(!q.rowCount)throw Object.assign(new Error('Refund record not found'),{status:404});
    if(q.rows[0].status!=='pending')throw Object.assign(new Error('Refund is not pending'),{status:409});
    await c.query("UPDATE refunds SET status='completed',reference=$2,processed_by=$3,processed_at=now() WHERE id=$1",[q.rows[0].id,parsed.data.reference||null,req.user.sub]);
    await c.query("UPDATE sales_returns SET status='refunded' WHERE id=$1",[req.params.id]);
    await c.query(`INSERT INTO audit_logs(business_id,actor_user_id,action,entity_type,entity_id,metadata) VALUES($1,$2,'refund_marked_completed','refund',$3,$4)`,[req.user.businessId,req.user.sub,q.rows[0].id,JSON.stringify({amount:q.rows[0].amount,reference:parsed.data.reference||null})]);
    await c.query('COMMIT');res.json({refundId:q.rows[0].id,status:'completed'});
  }catch(e){await c.query('ROLLBACK');next(e);}finally{c.release();}
});

export default router;
