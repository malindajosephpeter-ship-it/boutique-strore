import { Router } from 'express';
import { z } from 'zod';
import { pool } from '../db.js';
import { requireAuth } from '../middleware/auth.js';
const router=Router(); router.use(requireAuth);
router.get('/',async(req,res,next)=>{try{const limit=Math.min(Math.max(Number(req.query.limit)||50,1),100);const q=await pool.query('SELECT id,notification_type,title,body,entity_type,entity_id,read_at,created_at FROM staff_notifications WHERE user_id=$1 ORDER BY created_at DESC LIMIT $2',[req.user.sub,limit]);const unread=await pool.query('SELECT count(*)::int AS count FROM staff_notifications WHERE user_id=$1 AND read_at IS NULL',[req.user.sub]);res.json({notifications:q.rows,unreadCount:unread.rows[0].count});}catch(e){next(e);}});
router.patch('/:id/read',async(req,res,next)=>{try{const q=await pool.query('UPDATE staff_notifications SET read_at=COALESCE(read_at,now()) WHERE id=$1 AND user_id=$2 RETURNING id,read_at',[req.params.id,req.user.sub]);if(!q.rowCount)return res.status(404).json({error:'Notification not found'});res.json({notification:q.rows[0]});}catch(e){next(e);}});
router.post('/read-all',async(req,res,next)=>{try{const q=await pool.query('UPDATE staff_notifications SET read_at=now() WHERE user_id=$1 AND read_at IS NULL',[req.user.sub]);res.json({updated:q.rowCount});}catch(e){next(e);}});
export default router;
