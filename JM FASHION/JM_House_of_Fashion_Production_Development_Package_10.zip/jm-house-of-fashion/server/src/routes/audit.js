import { Router } from 'express';
import { pool } from '../db.js';
import { requireAuth, allowRoles } from '../middleware/auth.js';
const router=Router();router.use(requireAuth,allowRoles('owner','manager','accountant'));
router.get('/',async(req,res,next)=>{try{const limit=Math.min(Math.max(Number(req.query.limit)||100,1),300);const q=await pool.query(`SELECT a.id,a.action,a.entity_type,a.entity_id,a.metadata,a.created_at,u.display_name AS actor_name,u.role AS actor_role FROM audit_logs a LEFT JOIN app_users u ON u.id=a.actor_user_id WHERE a.business_id=$1 ORDER BY a.created_at DESC LIMIT $2`,[req.user.businessId,limit]);res.json({events:q.rows});}catch(e){next(e);}});
export default router;
