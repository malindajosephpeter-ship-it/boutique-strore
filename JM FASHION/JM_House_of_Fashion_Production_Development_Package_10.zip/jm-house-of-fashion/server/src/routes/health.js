import { Router } from 'express';
import { pool } from '../db.js';

const router = Router();
// Liveness does not depend on the database; orchestrators should not restart
// a healthy process merely because PostgreSQL is temporarily unavailable.
router.get('/live', (req, res) => res.json({ status: 'ok', service: 'jm-house-of-fashion-api' }));
// Readiness is used by deployment platforms before routing production traffic.
router.get('/ready', async (req, res) => {
  try {
    await pool.query('SELECT 1');
    res.json({ status: 'ready', database: 'connected' });
  } catch {
    res.status(503).json({ status: 'not_ready', database: 'unavailable' });
  }
});
router.get('/', async (req, res) => {
  try {
    await pool.query('SELECT 1');
    res.json({ status: 'ok', service: 'jm-house-of-fashion-api', database: 'connected' });
  } catch {
    res.status(503).json({ status: 'unavailable', service: 'jm-house-of-fashion-api' });
  }
});
export default router;
