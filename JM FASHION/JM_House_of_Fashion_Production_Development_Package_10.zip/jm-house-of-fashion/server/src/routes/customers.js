import { Router } from 'express';
import { pool } from '../db.js';
import { requireAuth, allowRoles } from '../middleware/auth.js';

const router = Router();
router.use(requireAuth, allowRoles('owner', 'manager', 'sales_attendant'));
router.get('/', async (req, res, next) => {
  try {
    const limit = Math.min(Math.max(Number(req.query.limit) || 100, 1), 300);
    const result = await pool.query(
      `SELECT c.id,c.full_name,c.phone,c.email,c.created_at,
        COUNT(DISTINCT o.id)::int AS order_count,
        COALESCE(SUM(o.total) FILTER (WHERE o.status='completed'),0)::numeric(14,2) AS completed_spend,
        MAX(o.created_at) AS last_order_at
       FROM customers c
       LEFT JOIN sales_orders o ON o.customer_id=c.id AND o.business_id=c.business_id
       WHERE c.business_id=$1
       GROUP BY c.id ORDER BY c.created_at DESC LIMIT $2`,
      [req.user.businessId, limit]
    );
    res.json({ customers: result.rows });
  } catch (error) { next(error); }
});
export default router;
