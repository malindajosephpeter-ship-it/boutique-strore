import { Router } from 'express';
import { createHash } from 'node:crypto';
import { z } from 'zod';
import { pool } from '../db.js';
import { requireAuth, allowRoles } from '../middleware/auth.js';

const router = Router();
const orderSchema = z.object({
  channel: z.enum(['online','physical_pos']),
  customerId: z.string().uuid().nullable().optional(),
  lines: z.array(z.object({
    variantId: z.string().uuid(),
    quantity: z.number().int().positive().max(100),
    unitPrice: z.number().nonnegative()
  })).min(1).max(100),
  payment: z.object({
    method: z.enum(['cash','mobile_money','bank','card']),
    provider: z.string().trim().max(80).optional(),
    reference: z.string().trim().max(120).optional(),
    amount: z.number().positive()
  }).optional()
});

router.post('/', requireAuth, async (req, res, next) => {
  const parsed = orderSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Invalid order', details: parsed.error.flatten() });

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const input = parsed.data;
    const idempotencyKey = String(req.headers['idempotency-key'] || '').trim();
    if (idempotencyKey) {
      if (idempotencyKey.length < 8 || idempotencyKey.length > 120) throw Object.assign(new Error('Idempotency-Key must contain 8 to 120 characters'), { status: 400 });
      await client.query('SELECT pg_advisory_xact_lock(hashtext($1),hashtext($2))', [req.user.businessId, idempotencyKey]);
      const payloadHash = createHash('sha256').update(JSON.stringify(input)).digest('hex');
      const previous = await client.query('SELECT id,status,total,created_at,idempotency_payload_hash FROM sales_orders WHERE business_id=$1 AND idempotency_key=$2', [req.user.businessId,idempotencyKey]);
      if (previous.rowCount) {
        if (previous.rows[0].idempotency_payload_hash !== payloadHash) throw Object.assign(new Error('This Idempotency-Key was already used with different order details'), { status: 409 });
        await client.query('COMMIT');
        return res.status(200).json({ order: previous.rows[0], replayed: true });
      }
    }

    const role = req.user.role;
    if (input.channel === 'physical_pos' && !['owner','manager','sales_attendant'].includes(role)) {
      await client.query('ROLLBACK');
      return res.status(403).json({ error: 'POS access is restricted to authorized staff' });
    }

    if (input.channel === 'physical_pos' && !input.payment) {
      throw Object.assign(new Error('POS checkout requires a recorded payment'), { status: 400 });
    }

    let subtotal = 0;
    const prepared = [];
    const aggregatedLines = [...input.lines.reduce((map, line) => {
      map.set(line.variantId, (map.get(line.variantId) || 0) + line.quantity);
      return map;
    }, new Map())].map(([variantId, quantity]) => ({ variantId, quantity }));
    for (const line of aggregatedLines) {
      const item = await client.query(
        `SELECT pv.id, p.selling_price, p.business_id, ib.quantity_on_hand, ib.quantity_reserved
         FROM product_variants pv
         JOIN products p ON p.id = pv.product_id
         JOIN inventory_balances ib ON ib.variant_id = pv.id
         WHERE pv.id = $1 AND p.business_id = $2
         FOR UPDATE OF ib`,
        [line.variantId, req.user.businessId]
      );
      const row = item.rows[0];
      if (!row) throw Object.assign(new Error('A selected product variant is unavailable'), { status: 409 });
      const available = row.quantity_on_hand - row.quantity_reserved;
      if (available < line.quantity) throw Object.assign(new Error('Insufficient stock for one or more items'), { status: 409 });
      const price = Number(row.selling_price);
      subtotal += price * line.quantity;
      prepared.push({ ...line, price });
    }

    if (input.channel === 'physical_pos' && Math.abs(input.payment.amount - subtotal) > 0.009) {
      throw Object.assign(new Error('POS payment amount must equal the order total'), { status: 400 });
    }
    const orderStatus = input.channel === 'online' ? 'pending' : 'completed';
    const order = await client.query(
      `INSERT INTO sales_orders (business_id, customer_id, channel, status, subtotal, total, idempotency_key, idempotency_payload_hash)
       VALUES ($1,$2,$3,$4,$5,$5,$6,$7) RETURNING id, status, total, created_at`,
      [req.user.businessId, input.customerId || null, input.channel, orderStatus, subtotal, idempotencyKey || null, idempotencyKey ? createHash('sha256').update(JSON.stringify(input)).digest('hex') : null]
    );

    if (input.channel === 'physical_pos') {
      await client.query(
        `INSERT INTO payments(order_id,method,provider,reference,amount,status,verified_at,verified_by)
         VALUES($1,$2,$3,$4,$5,'verified',now(),$6)`,
        [order.rows[0].id,input.payment.method,input.payment.provider || null,input.payment.reference || null,input.payment.amount,req.user.sub]
      );
    }

    for (const line of prepared) {
      await client.query(
        `INSERT INTO sales_order_lines (order_id, variant_id, quantity, unit_price)
         VALUES ($1,$2,$3,$4)`,
        [order.rows[0].id, line.variantId, line.quantity, line.price]
      );
      if (input.channel === 'physical_pos') {
        await client.query(
          `UPDATE inventory_balances SET quantity_on_hand = quantity_on_hand - $2, updated_at = now()
           WHERE variant_id = $1`,
          [line.variantId, line.quantity]
        );
        await client.query(
          `INSERT INTO stock_movements (business_id, variant_id, movement_type, quantity_delta, reference_type, reference_id, created_by)
           VALUES ($1,$2,'pos_sale',$3,'sales_order',$4,$5)`,
          [req.user.businessId, line.variantId, -line.quantity, order.rows[0].id, req.user.sub]
        );
      } else {
        await client.query(
          `UPDATE inventory_balances SET quantity_reserved = quantity_reserved + $2, updated_at = now()
           WHERE variant_id = $1`,
          [line.variantId, line.quantity]
        );
      }
    }

    await client.query(
      `INSERT INTO audit_logs (business_id, actor_user_id, action, entity_type, entity_id, metadata)
       VALUES ($1,$2,'order_created','sales_order',$3,jsonb_build_object('channel',$4,'total',$5))`,
      [req.user.businessId, req.user.sub, order.rows[0].id, input.channel, subtotal]
    );
    await client.query(`INSERT INTO staff_notifications(business_id,user_id,notification_type,title,body,entity_type,entity_id)
      SELECT business_id,id,'pos_sale','New POS sale',concat('A POS sale of ', $2, ' TZS was recorded.'),'sales_order',$3 FROM app_users WHERE business_id=$1 AND is_active=true AND role IN ('owner','manager','accountant') AND id<>$4`, [req.user.businessId, subtotal, order.rows[0].id, req.user.sub]);
    await client.query('COMMIT');
    res.status(201).json({ order: order.rows[0] });
  } catch (err) {
    await client.query('ROLLBACK');
    next(err);
  } finally {
    client.release();
  }
});

router.get('/', requireAuth, allowRoles('owner','manager','sales_attendant','accountant'), async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT id, channel, status, subtotal, discount, total, created_at
       FROM sales_orders WHERE business_id = $1 ORDER BY created_at DESC LIMIT 200`,
      [req.user.businessId]
    );
    res.json({ orders: result.rows });
  } catch (err) { next(err); }
});

export default router;
