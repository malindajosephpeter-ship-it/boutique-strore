import { Router } from 'express';
import { randomUUID } from 'node:crypto';
import { cloudinarySignature } from '../lib/cloudinary.js';
import { z } from 'zod';
import { pool } from '../db.js';
import { requireAuth, allowRoles } from '../middleware/auth.js';
const router=Router();
const mediaRoles=allowRoles('owner','manager','stock_manager');

// Cloudinary direct-upload signing: API secrets remain on the server; browser receives only a short-lived signature.
router.post('/signature',requireAuth,mediaRoles,async(req,res)=>{
  const parsed=z.object({productId:z.string().uuid()}).safeParse(req.body);
  if(!parsed.success)return res.status(400).json({error:'A valid productId is required'});
  const {CLOUDINARY_CLOUD_NAME, CLOUDINARY_API_KEY, CLOUDINARY_API_SECRET}=process.env;
  if(!CLOUDINARY_CLOUD_NAME||!CLOUDINARY_API_KEY||!CLOUDINARY_API_SECRET)return res.status(503).json({error:'Product image storage is not configured. Set Cloudinary credentials on the server.'});
  try{
    const product=await pool.query('SELECT id FROM products WHERE id=$1 AND business_id=$2',[parsed.data.productId,req.user.businessId]);
    if(!product.rowCount)return res.status(404).json({error:'Product not found'});
    const timestamp=Math.floor(Date.now()/1000);
    const folder=`jm-house-of-fashion/${req.user.businessId}/${parsed.data.productId}`;
    const public_id=randomUUID();
    const allowed_formats='jpg,png,webp';
    const signature=cloudinarySignature({allowed_formats,folder,overwrite:false,public_id,timestamp},CLOUDINARY_API_SECRET);
    res.json({cloudName:CLOUDINARY_CLOUD_NAME,apiKey:CLOUDINARY_API_KEY,timestamp,folder,publicId:public_id,allowedFormats:allowed_formats,overwrite:false,signature,signatureAlgorithm:'sha1'});
  }catch(e){res.status(500).json({error:'Could not prepare image upload'});}
});

router.post('/attach',requireAuth,mediaRoles,async(req,res,next)=>{
  const parsed=z.object({productId:z.string().uuid(),secureUrl:z.string().url().max(2000),publicId:z.string().min(5).max(300),altText:z.string().trim().max(200).optional()}).safeParse(req.body);
  if(!parsed.success)return res.status(400).json({error:'Invalid uploaded image details',details:parsed.error.flatten()});
  const d=parsed.data;
  try{
    const product=await pool.query('SELECT id FROM products WHERE id=$1 AND business_id=$2',[d.productId,req.user.businessId]);
    if(!product.rowCount)return res.status(404).json({error:'Product not found'});
    const expectedPrefix=`jm-house-of-fashion/${req.user.businessId}/${d.productId}/`;
    const imageUrl=new URL(d.secureUrl);
    if(!d.publicId.startsWith(expectedPrefix)||imageUrl.protocol!=='https:'||imageUrl.hostname!=='res.cloudinary.com'||!imageUrl.pathname.includes(`/${process.env.CLOUDINARY_CLOUD_NAME}/image/upload/`))return res.status(400).json({error:'Image does not belong to the configured Cloudinary product folder'});
    const inserted=await pool.query('INSERT INTO product_images(product_id,storage_key,alt_text,sort_order,provider,public_id) VALUES($1,$2,$3,COALESCE((SELECT MAX(sort_order)+1 FROM product_images WHERE product_id=$1),0),\'cloudinary\',$4) RETURNING id,storage_key,alt_text,sort_order',[d.productId,d.secureUrl,d.altText||null,d.publicId]);
    await pool.query("INSERT INTO audit_logs(business_id,actor_user_id,action,entity_type,entity_id,metadata) VALUES($1,$2,'product_image_attached','product',$3,$4)",[req.user.businessId,req.user.sub,d.productId,JSON.stringify({imageId:inserted.rows[0].id,provider:'cloudinary'})]);
    res.status(201).json({image:inserted.rows[0]});
  }catch(e){next(e);}
});
export default router;
