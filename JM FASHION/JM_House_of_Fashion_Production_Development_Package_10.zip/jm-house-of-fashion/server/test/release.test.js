import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '../..');

test('database migrations are sequentially named and include release integrity migration', () => {
  const files = fs.readdirSync(path.join(root, 'server/migrations')).filter((name) => name.endsWith('.sql')).sort();
  assert.ok(files.length >= 11);
  assert.equal(files.at(-1), '011_customer_directory.sql');
  assert.deepEqual(files.map((name) => Number(name.slice(0, 3))), files.map((_, index) => index + 1));
});

test('production server refuses unsafe missing configuration', () => {
  const source = fs.readFileSync(path.join(root, 'server/src/index.js'), 'utf8');
  assert.match(source, /JWT_SECRET must be configured/);
  assert.match(source, /DATABASE_URL is required in production/);
  assert.match(source, /CORS_ORIGINS must contain the exact production frontend origin/);
});

test('health endpoints distinguish liveness and database readiness', () => {
  const source = fs.readFileSync(path.join(root, 'server/src/routes/health.js'), 'utf8');
  assert.match(source, /router\.get\('\/live'/);
  assert.match(source, /router\.get\('\/ready'/);
  assert.match(source, /status\(503\)/);
});

test('public legal pages are present but clearly marked for business review', () => {
  for (const file of ['privacy.html', 'terms.html']) {
    const html = fs.readFileSync(path.join(root, 'public', file), 'utf8');
    assert.match(html, /Draft for business review/);
    assert.match(html, /before launch/i);
  }
});
