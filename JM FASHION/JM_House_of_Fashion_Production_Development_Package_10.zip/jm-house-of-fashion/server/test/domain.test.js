import test from 'node:test';
import assert from 'node:assert/strict';
import { calculateRefundAmount, fromMinorUnits, toMinorUnits } from '../src/lib/finance.js';
import { cloudinarySignature } from '../src/lib/cloudinary.js';

test('currency conversion avoids common floating point addition errors', () => {
  assert.equal(toMinorUnits(0.1) + toMinorUnits(0.2), 30);
  assert.equal(fromMinorUnits(12345), 123.45);
});

test('refund amount sums quantities using integer minor units', () => {
  assert.equal(calculateRefundAmount([{unitPrice: 1250.50, quantity: 2}, {unitPrice: 99.99, quantity: 1}]), 2600.99);
});

test('refund amount rejects invalid quantities and negative values', () => {
  assert.throws(() => calculateRefundAmount([{unitPrice: 100, quantity: 0}]), /positive integer/);
  assert.throws(() => calculateRefundAmount([{unitPrice: -1, quantity: 1}]), /non-negative/);
});

test('Cloudinary signatures use sorted canonical parameters', () => {
  const first = cloudinarySignature({timestamp: 123, folder: 'jm/test', public_id: 'abc'}, 'secret');
  const second = cloudinarySignature({public_id: 'abc', timestamp: 123, folder: 'jm/test'}, 'secret');
  assert.equal(first, second);
  assert.match(first, /^[a-f0-9]{40}$/);
});
