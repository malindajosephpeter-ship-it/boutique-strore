-- Cloud image metadata. API credentials stay exclusively in server environment variables.
ALTER TABLE product_images ADD COLUMN IF NOT EXISTS provider text NOT NULL DEFAULT 'cloudinary';
ALTER TABLE product_images ADD COLUMN IF NOT EXISTS public_id text;
CREATE UNIQUE INDEX IF NOT EXISTS idx_product_images_public_id ON product_images(public_id) WHERE public_id IS NOT NULL;
