-- Release integrity and query support. Existing data is not silently rewritten.
CREATE INDEX IF NOT EXISTS idx_app_users_business_role_active
  ON app_users(business_id, role, is_active);
CREATE INDEX IF NOT EXISTS idx_security_events_business_type_date
  ON security_events(business_id, event_type, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_returns_business_status_date
  ON sales_returns(business_id, status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_refunds_business_status_date
  ON refunds(business_id, status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_staff_notifications_business_user_date
  ON staff_notifications(business_id, user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_customer_addresses_customer_default
  ON customer_addresses(customer_id, is_default DESC, created_at DESC);

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='inventory_reserved_not_above_on_hand') THEN
    ALTER TABLE inventory_balances
      ADD CONSTRAINT inventory_reserved_not_above_on_hand
      CHECK (quantity_reserved <= quantity_on_hand) NOT VALID;
  END IF;
END $$;
