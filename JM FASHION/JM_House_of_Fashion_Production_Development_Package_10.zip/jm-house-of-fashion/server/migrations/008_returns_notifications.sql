-- Returns, manual refund ledger, staff notifications and idempotent checkout keys.
CREATE TABLE IF NOT EXISTS sales_returns (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id uuid NOT NULL REFERENCES businesses(id),
  order_id uuid NOT NULL REFERENCES sales_orders(id),
  return_number text NOT NULL UNIQUE,
  reason text NOT NULL,
  status text NOT NULL DEFAULT 'requested' CHECK (status IN ('requested','approved','rejected','refunded')),
  refund_amount numeric(14,2) NOT NULL DEFAULT 0 CHECK (refund_amount >= 0),
  restock boolean NOT NULL DEFAULT true,
  requested_by uuid REFERENCES app_users(id),
  resolved_by uuid REFERENCES app_users(id),
  resolved_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS sales_return_lines (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  return_id uuid NOT NULL REFERENCES sales_returns(id) ON DELETE CASCADE,
  order_line_id uuid NOT NULL REFERENCES sales_order_lines(id),
  variant_id uuid NOT NULL REFERENCES product_variants(id),
  quantity integer NOT NULL CHECK (quantity > 0),
  unit_price numeric(14,2) NOT NULL CHECK (unit_price >= 0),
  UNIQUE(return_id, order_line_id)
);
CREATE TABLE IF NOT EXISTS refunds (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id uuid NOT NULL REFERENCES businesses(id),
  return_id uuid NOT NULL UNIQUE REFERENCES sales_returns(id),
  order_id uuid NOT NULL REFERENCES sales_orders(id),
  amount numeric(14,2) NOT NULL CHECK (amount > 0),
  method text NOT NULL CHECK (method IN ('cash','mobile_money','bank','card','manual')),
  reference text,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','completed','failed')),
  processed_by uuid REFERENCES app_users(id),
  processed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS staff_notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_id uuid NOT NULL REFERENCES businesses(id),
  user_id uuid NOT NULL REFERENCES app_users(id) ON DELETE CASCADE,
  notification_type text NOT NULL,
  title text NOT NULL,
  body text NOT NULL,
  entity_type text,
  entity_id uuid,
  read_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_returns_business_date ON sales_returns(business_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_returns_order ON sales_returns(order_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_refunds_business_date ON refunds(business_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_user_unread ON staff_notifications(user_id,created_at DESC) WHERE read_at IS NULL;
ALTER TABLE sales_orders ADD COLUMN IF NOT EXISTS idempotency_key text;
ALTER TABLE sales_orders ADD COLUMN IF NOT EXISTS idempotency_payload_hash text;
CREATE UNIQUE INDEX IF NOT EXISTS idx_sales_orders_idempotency
  ON sales_orders(business_id,idempotency_key) WHERE idempotency_key IS NOT NULL;
