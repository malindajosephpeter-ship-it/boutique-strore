-- Customer directory query support. Customer PII remains behind authenticated staff roles.
CREATE INDEX IF NOT EXISTS idx_sales_orders_customer_business_date
  ON sales_orders(customer_id, business_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_customers_business_created
  ON customers(business_id, created_at DESC);
