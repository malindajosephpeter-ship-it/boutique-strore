# JM House of Fashion — Development Starter

A premium UI foundation and initial PostgreSQL schema for the JM House of Fashion ecosystem.

## Current contents

- Responsive React/Vite frontend shell.
- Owner dashboard overview.
- Customer storefront catalogue with category filters and cart-count interaction.
- Smart TV public display mode.
- Initial PostgreSQL schema for products, variants, inventory, suppliers, purchases, customers, orders, payments, expenses, agency services and audit logs.
- Feminine premium brand palette: Royal Berry, Blush Rose, Champagne Gold and Soft Ivory.

## Run locally

Requirements: Node.js 20+ and npm.

```bash
npm install
npm run dev
```

Open the local URL printed by Vite.

Create a production build:

```bash
npm run build
```

## Important implementation status

This is the first development scaffold, not yet a deployed production system.

The dashboard currently uses demonstration data. The module pages are structural placeholders. The product catalogue uses remote demonstration photography. No real payment gateway, authentication provider, PostgreSQL connection, employee account system, or cloud synchronization is active yet.

Do not use this scaffold to process real customer payments or store confidential business data.

## Next engineering milestones

1. Provision managed PostgreSQL and backend hosting.
2. Implement authentication, session management, roles and server-side authorization.
3. Apply database migrations and implement row-level security policies.
4. Build API services and connect the interfaces to the shared database.
5. Implement inventory-safe purchasing, POS, online ordering and payment verification.
6. Implement mobile money and bank agency ledger/reconciliation.
7. Implement reports, audit logs, backups and monitoring.
8. Package Flutter applications and prepare store submissions.
9. Run security, integration and acceptance tests.

## Deployment architecture

Use Netlify for the web frontend. Host PostgreSQL and the secure API on a managed service compatible with the application. Keep all database credentials and privileged API keys server-side.


## Development increment 2: API foundation

Added a separate Express API service with:
- Helmet security headers, CORS allow-list, JSON size limit and rate limiting.
- JWT-based authentication middleware and role checks.
- Login and current-user endpoints.
- Public published-product catalogue endpoint.
- Protected product creation endpoint.
- Transactional order creation with row locking and stock checks.
- Audit logging for created orders.
- PostgreSQL authentication/security migration.

### Run the API

```bash
cd server
cp .env.example .env
# Configure DATABASE_URL, JWT_SECRET and CORS_ORIGINS
npm install
npm run dev
```

The API is not production-ready until the managed database is provisioned, migrations are applied, owner bootstrap is implemented, RLS/database privileges are configured and security tests pass.

## Development increment 3: purchasing, stock ledger and finance

Added:
- Supplier directory API (list, create, update).
- Purchase order API with supplier and variant ownership validation.
- Transactional purchase receiving: stock balances are increased and every received line is recorded in `stock_movements`; duplicate receiving is blocked.
- Physical POS sales decrease stock and create negative stock-ledger entries; online orders reserve stock pending fulfilment.
- Expense entry and listing with category, date and payment method.
- Monthly/year-to-date summary and monthly sales trend reporting endpoints.
- Public read-only Smart TV product feed that returns only published product details (no cost prices, stock quantities, customer data or internal records).
- Migration `003_inventory_finance.sql` for the stock movement ledger and supporting indexes/fields.

Apply migrations in order: `database/001_initial_schema.sql`, `server/migrations/002_auth_security.sql`, then `server/migrations/003_inventory_finance.sql`.

### New API endpoints
- `GET/POST/PATCH /api/suppliers`
- `GET/POST /api/purchases`
- `POST /api/purchases/:id/receive`
- `GET/POST /api/expenses`
- `GET /api/reports/summary?period=month|year`
- `GET /api/reports/sales-trend?year=2026`
- `GET /api/display/products?businessId=<business UUID>` (public, published products only)

These are API foundations and still require database provisioning, an initial owner bootstrap, role/identity reconciliation, integration tests, payment-provider integrations and deployment before live business use.
