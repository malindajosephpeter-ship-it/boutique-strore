# JM House of Fashion — Development Starter

A premium UI foundation and initial PostgreSQL schema for the JM House of Fashion ecosystem.

## Current contents

- Responsive React/Vite frontend shell.
- Owner dashboard overview.
- Customer storefront catalogue with category filters and cart-count interaction.
- Smart TV public display mode.
- Initial PostgreSQL schema for products, variants, inventory, suppliers, purchases, customers, orders, payments, expenses, agency services and audit logs.
- Feminine premium brand palette: Royal Berry, Blush Rose, Champagne Gold and Soft Ivory.

## Run locally

Requirements: Node.js 20+ and npm.

```bash
npm install
npm run dev
```

Open the local URL printed by Vite.

Create a production build:

```bash
npm run build
```

## Important implementation status

This is the first development scaffold, not yet a deployed production system.

The dashboard currently uses demonstration data. The module pages are structural placeholders. The product catalogue uses remote demonstration photography. No real payment gateway, authentication provider, PostgreSQL connection, employee account system, or cloud synchronization is active yet.

Do not use this scaffold to process real customer payments or store confidential business data.

## Next engineering milestones

1. Provision managed PostgreSQL and backend hosting.
2. Implement authentication, session management, roles and server-side authorization.
3. Apply database migrations and implement row-level security policies.
4. Build API services and connect the interfaces to the shared database.
5. Implement inventory-safe purchasing, POS, online ordering and payment verification.
6. Implement mobile money and bank agency ledger/reconciliation.
7. Implement reports, audit logs, backups and monitoring.
8. Package Flutter applications and prepare store submissions.
9. Run security, integration and acceptance tests.

## Deployment architecture

Use Netlify for the web frontend. Host PostgreSQL and the secure API on a managed service compatible with the application. Keep all database credentials and privileged API keys server-side.


## Development increment 2: API foundation

Added a separate Express API service with:
- Helmet security headers, CORS allow-list, JSON size limit and rate limiting.
- JWT-based authentication middleware and role checks.
- Login and current-user endpoints.
- Public published-product catalogue endpoint.
- Protected product creation endpoint.
- Transactional order creation with row locking and stock checks.
- Audit logging for created orders.
- PostgreSQL authentication/security migration.

### Run the API

```bash
cd server
cp .env.example .env
# Configure DATABASE_URL, JWT_SECRET and CORS_ORIGINS
npm install
npm run dev
```

The API is not production-ready until the managed database is provisioned, migrations are applied, owner bootstrap is implemented, RLS/database privileges are configured and security tests pass.

## Development increment 3: purchasing, stock ledger and finance

Added:
- Supplier directory API (list, create, update).
- Purchase order API with supplier and variant ownership validation.
- Transactional purchase receiving: stock balances are increased and every received line is recorded in `stock_movements`; duplicate receiving is blocked.
- Physical POS sales decrease stock and create negative stock-ledger entries; online orders reserve stock pending fulfilment.
- Expense entry and listing with category, date and payment method.
- Monthly/year-to-date summary and monthly sales trend reporting endpoints.
- Public read-only Smart TV product feed that returns only published product details (no cost prices, stock quantities, customer data or internal records).
- Migration `003_inventory_finance.sql` for the stock movement ledger and supporting indexes/fields.

Apply migrations in order with `cd server && npm run migrate`. The runner applies all numbered SQL migrations in `server/migrations/` (currently 001–007) exactly once using the `schema_migrations` ledger.

### New API endpoints
- `GET/POST/PATCH /api/suppliers`
- `GET/POST /api/purchases`
- `POST /api/purchases/:id/receive`
- `GET/POST /api/expenses`
- `GET /api/reports/summary?period=month|year`
- `GET /api/reports/sales-trend?year=2026`
- `GET /api/display/products?businessId=<business UUID>` (public, published products only)

These are API foundations and still require database provisioning, an initial owner bootstrap, role/identity reconciliation, integration tests, payment-provider integrations and deployment before live business use.

## Development increment 4 — customer checkout and fulfilment

Added:
- Guest online checkout with customer contact/delivery details, stock reservation, payment intent and one-time order tracking token.
- Customer order tracking by order number + 64-character tracking token. Store the token securely; it cannot be recovered from the database.
- Staff account creation/deactivation for owner/manager roles. Public employee signup is intentionally disabled.
- Staff order queue, controlled order-state transitions, payment verification, stock release on cancellation, and stock deduction on completed fulfilment.
- Ordered SQL migration runner and one-time owner bootstrap scripts.

### First-time setup (backend)
1. Create a private PostgreSQL database and configure `DATABASE_URL`, `DATABASE_SSL`, `JWT_SECRET` (at least 32 random characters), and `CORS_ORIGINS`.
2. From `server/`, run `npm install` then `npm run migrate`.
3. Set the `INITIAL_OWNER_*` values temporarily and run `npm run bootstrap:owner` once. Remove the bootstrap values immediately afterwards.
4. Start with `npm start` and verify `/api/health`.

Do not expose database credentials or the JWT secret in the browser/mobile app. The checkout endpoint is a foundation: connect a verified payment provider and its signed webhook before accepting prepaid mobile-money or bank payments. Never mark a payment verified based only on a customer-submitted reference. Add provider-specific reconciliation and idempotency before production payments.

### Important production status
This repository remains a development implementation, not a production-certified or deployed store. No cloud database, storage bucket, payment merchant credentials, Apple/Google developer accounts, TLS domain, backups, monitoring, or live provider webhooks have been provisioned from this workspace. Before public launch, complete integration, security review, load testing, backup/restore testing, privacy/terms pages, and device testing. Guest checkout currently accepts delivery details but does not yet calculate delivery fees or dispatch logistics.


### Additional inventory endpoints
- `GET /api/inventory` (authorized inventory view)
- `GET /api/inventory/movements` (stock movement ledger)
- `POST /api/inventory/adjust` (authorized reason-coded stock adjustment; cannot reduce below reserved stock)


## Development increment 05 — secure app shell and PWA

- Added an owner/staff sign-in screen connected to `POST /api/auth/login` and session validation via `GET /api/auth/me`.
- Access tokens are held in `sessionStorage` and cleared on sign-out; this is a pragmatic SPA baseline, not a substitute for a production BFF with Secure, HttpOnly, SameSite cookies.
- Added a PWA manifest and service worker for static app-shell caching. API requests are deliberately never cached; offline transaction submission is not enabled until an idempotent sync queue is implemented and tested.
- Added migration `005_production_hardening.sql` with query indexes and operational constraints. The migration runner applies it after migrations 001–004.

### Frontend environment
Copy `.env.example` to `.env` in the frontend root and set `VITE_API_BASE_URL` to the public API base (for example `https://api.example.com/api`). Never put database credentials or private payment-provider keys in `VITE_*` variables.

### Current release status
This is a development increment. The owner sign-in UI requires a provisioned database, completed migrations and one-time owner bootstrap. PWA installation requires HTTPS and valid hosting headers. No live payment gateway, production cloud database, domain, mobile store listing, or deployment is configured by this source package.
- Protected API requests now re-check the staff account and current role against PostgreSQL on every request, so a disabled employee loses access immediately rather than when the JWT expires.

## Production development package 06

This increment connects the owner product catalogue and customer storefront to the API, adds category and variant-aware product creation, opening stock ledger entries, a database-backed monthly dashboard, customer order/payment review and fulfilment actions, a public `?view=shop` route, a database-backed `?view=tv` display, migration 006, Netlify deployment configuration, backend Dockerfile and CI workflow.

See `docs/PRODUCTION_READINESS.md` for environment variables, deployment sequence and remaining production gates. Live payment provider credentials, managed cloud database, cloud image storage, hosting and app-store accounts are not provisioned by this source package.

## Production development package 07 — agency float, POS payments and reports

This increment adds a business-scoped agency ledger API and connects the Owner workspace's Agency Services, Sales & POS, and Reports pages to the backend.

### Agency services
- `GET /api/agency/accounts` and `GET /api/agency/summary` show agency accounts, opening float, computed current float, completed transaction volume and commissions.
- `POST /api/agency/accounts` creates a mobile-money or bank agency account.
- `PATCH /api/agency/accounts/:id/status` activates or deactivates an account.
- `GET /api/agency/transactions` lists recent transactions.
- `POST /api/agency/transactions` records a transaction with an explicit signed `floatDelta`: positive adds float; negative consumes float. A transaction that would make float negative is rejected. Duplicate references per account are rejected.
- Agency transactions are completed manual records only. This is not a live telco/bank integration; reconcile against provider statements and receipts.

### POS and reports
- Physical POS orders now require a payment record whose amount matches the order total. Payment and stock deduction are committed in the same database transaction.
- `GET /api/reports/summary?period=day|week|month|year` supports the main reporting periods.
- `GET /api/reports/range?from=YYYY-MM-DD&to=YYYY-MM-DD` returns completed sales, expenses, verified payment-method totals and top-selling products for the selected dates.
- Owner workspace pages for POS, Agency Services and Reports now call these API endpoints instead of displaying module placeholders.

### Migration 007
Run `cd server && npm run migrate` after configuring the private PostgreSQL connection. Migration `007_agency_reconciliation.sql` adds opening float, signed float movement, customer phone and transaction notes, removes the old `user_profiles` actor foreign key for agency records, and adds a duplicate-reference index.

### Verification status
`npm run check:server` and `cd server && npm run check` pass JavaScript syntax validation. The frontend build and database integration tests have not yet run in this workspace because frontend dependencies are not installed and no PostgreSQL instance is provisioned. Do not treat manual agency entries as bank/mobile-network API confirmations.

## Production development package 07 — operational pages

The owner interface now includes database-backed workspaces for:
- Inventory balances, reserved stock, reason-coded adjustments and stock movement history.
- Supplier registration, supplier directory, purchase-order entry and stock receiving.
- Expense entry and expense register.
- Point of Sale with mandatory tender entry; the server records the payment and deducts inventory atomically.
- Mobile-money/bank agency accounts, signed float movements, duplicate-reference protection and commission totals.
- Daily/weekly/monthly/yearly summaries, custom date-range reporting, payment method totals and top products.

### Additional production notes
- Purchase entry UI currently creates a one-variant purchase order per form submission. Multi-line purchase editing and partial receiving remain future work.
- Agency float movements are manually entered and must be reconciled against actual network/bank statements. No telco or bank transaction API is connected.
- The POS currently supports a single full payment per order; split tender, refunds, void approvals and receipt printing remain future work.
- Customer-facing checkout remains an order/payment-intent flow. It does not charge a mobile-money wallet until a verified provider integration and signed webhook are implemented.


## Package 08 — Returns, refunds, image storage and controls
- Return requests are limited to the unreturned quantity of completed/delivered order lines. Approval can restock items and creates a pending manual refund record.
- A refund is marked completed only after an authorized user confirms that the money was actually returned. No mobile-money/bank gateway is connected by this feature.
- Staff notifications and an owner/manager/accountant audit-log endpoint are available.
- POS order creation supports `Idempotency-Key` to protect against duplicate retries. The POS UI reuses the same key when retrying an unsuccessful request.
- Product image upload uses Cloudinary signed uploads. Set `CLOUDINARY_CLOUD_NAME`, `CLOUDINARY_API_KEY`, and `CLOUDINARY_API_SECRET` on the backend host only. The API secret must never be exposed in browser variables.
- Apply migrations `008_returns_notifications.sql` and `009_cloud_media.sql` with `cd server && npm run migrate`.
- Run `npm run check:server` and `npm run test:server` from the project root.

## Production development package 09 — release hardening and launch governance

This increment adds:
- Separate API liveness (`/api/health/live`) and database readiness (`/api/health/ready`) probes.
- Fail-fast production configuration checks for the private database URL, JWT secret and exact CORS origin allowlist.
- Optional single trusted reverse-proxy configuration through `TRUST_PROXY=true`.
- Per-request correlation IDs returned in `X-Request-ID` and API error payloads.
- Safer malformed-JSON handling and reduced production error disclosure.
- Graceful API shutdown on SIGTERM/SIGINT and PostgreSQL pool closure.
- Failed-login security events where the attempted account can be resolved, without storing submitted passwords.
- PWA service-worker registration on production builds.
- Migration `010_release_integrity.sql` with operational indexes and a reservation-versus-on-hand stock constraint.
- Starter privacy and terms pages. They are explicitly drafts and must be completed/reviewed before public launch.
- A production release runbook with go/no-go gates, deployment sequence, payment integration requirements, backups, health checks and rollback guidance.

### Package 09 verification

Run `npm run check:server` and `npm run test:server`. The release tests validate migration sequencing, fail-fast configuration guards, readiness endpoints and presence of draft legal pages. These are source-level tests, not a live PostgreSQL integration test or legal compliance certification.

### Production boundary

No hosting account, managed PostgreSQL database, Cloudinary account, mobile-money/bank merchant credentials, custom domain, TLS certificate, app-store account or production deployment has been provisioned by this repository update. The app must remain in staging until the release runbook gates are evidenced in the real target environment.


## Production development package 10 — customer directory and staff workspace

- Added a protected customer directory API (`GET /api/customers`) restricted to owner, manager and sales-attendant roles. It returns customer contact fields, order counts, completed spend and last-order date for the authenticated business only.
- Replaced the Customers & Team placeholder with a database-backed workspace for employee creation, activation/deactivation and customer purchase-history review.
- Employee creation remains owner/manager-only and requires a password of at least 12 characters. Employee deactivation is enforced by the API authentication middleware on subsequent requests.
- Added migration `011_customer_directory.sql` for customer/order lookup performance.
- Customer personal information is not exposed through the public storefront or Smart TV catalogue APIs.

Run `npm run check:server` and `npm run test:server` after applying the package. The customer directory requires migrations 001–011 and a configured PostgreSQL database. Frontend production compilation still requires installing the declared React/Vite dependencies in a network-enabled build environment.


## Production development package 10 — customer directory and staff workspace

- Added a protected customer directory API (`GET /api/customers`) restricted to owner, manager and sales-attendant roles. It returns customer contact fields, order counts, completed spend and last-order date for the authenticated business only.
- Replaced the Customers & Team placeholder with a database-backed workspace for employee creation, activation/deactivation and customer purchase-history review.
- Employee creation remains owner/manager-only and requires a password of at least 12 characters. Employee deactivation is enforced by the API authentication middleware on subsequent requests.
- Added migration `011_customer_directory.sql` for customer/order lookup performance.
- Customer personal information is not exposed through the public storefront or Smart TV catalogue APIs.

Run `npm run check:server` and `npm run test:server` after applying the package. The customer directory requires migrations 001–011 and a configured PostgreSQL database. Frontend production compilation still requires installing the declared React/Vite dependencies in a network-enabled build environment.

## Package 11 — single-server HTTPS deployment bundle

Adds a Docker Compose topology for a VPS: PostgreSQL on a private Docker network, the Express API, a production-built React/Vite frontend served by Nginx, and Caddy automatic HTTPS. Includes a production environment template, frontend Dockerfile, reverse-proxy configuration, repository secret exclusions, and an operator deployment guide.

See `deploy/DEPLOY_ON_VPS.md`. This is a ready-to-configure deployment bundle, not a live deployment. It requires the business owner's VPS, domain/DNS, secrets, and operational approval. PostgreSQL is not exposed publicly. The first-owner bootstrap is a one-time command; remove its environment values immediately afterwards.

### Package 11 verification
- Backend JavaScript syntax check: pass.
- Backend source/unit tests: 8/8 pass.
- Docker build and live PostgreSQL integration: not run in this workspace (Docker daemon/cloud credentials are not available here).
- Frontend dependency installation timed out in this workspace, so frontend production compilation remains unverified.
