# JM House of Fashion — single-server HTTPS deployment

This is a deployment recipe, not proof of a live deployment. It requires a Linux VPS with Docker Engine + Docker Compose v2, a domain name, and DNS control.

## 1. DNS and server prerequisites

1. Provision a VPS with a supported Linux distribution and a static public IPv4 address.
2. Create an `A` record for the chosen shop domain pointing to that IP. Wait for DNS propagation.
3. Allow inbound TCP 80 and 443 (and optionally UDP 443) in the VPS firewall. Keep PostgreSQL port 5432 private; do not open it to the internet.
4. Install Docker Engine and the Docker Compose plugin from the official Docker instructions.

## 2. Configure secrets

From the repository root:

```bash
cp .env.production.example .env.production
openssl rand -hex 32
```

Edit `.env.production`: set `DOMAIN`, a long random `POSTGRES_PASSWORD`, a 64-character random `JWT_SECRET`, and one-time owner details with a unique password of at least 14 characters. Leave `VITE_BUSINESS_ID` blank for the first migration/bootstrap. Never commit `.env.production`.

## 3. Build API and start database

```bash
docker compose --env-file .env.production -f compose.yaml build api
docker compose --env-file .env.production -f compose.yaml up -d db
docker compose --env-file .env.production -f compose.yaml run --rm api npm run migrate
docker compose --env-file .env.production -f compose.yaml run --rm api npm run bootstrap:owner
```

After the owner is created, immediately remove `INITIAL_OWNER_NAME`, `INITIAL_OWNER_EMAIL`, and `INITIAL_OWNER_PASSWORD` from `.env.production`. Do not run bootstrap again.

Retrieve the business UUID:

```bash
docker compose --env-file .env.production -f compose.yaml exec -T db \
  psql -U jm_app -d jm_house -c "SELECT id, name FROM businesses;"
```

Put that UUID in `VITE_BUSINESS_ID` in `.env.production`.

## 4. Build and launch HTTPS frontend + API

```bash
docker compose --env-file .env.production -f compose.yaml build web
docker compose --env-file .env.production -f compose.yaml up -d
docker compose --env-file .env.production -f compose.yaml ps
```

Caddy obtains and renews the TLS certificate automatically after the domain resolves to the server and ports 80/443 are reachable. Open `https://YOUR_DOMAIN`; the API is served through the same origin at `/api`.

## 5. Smoke tests before real trading

- `/api/health/live` returns healthy.
- `/api/health/ready` confirms PostgreSQL readiness.
- Owner can log in.
- Create and publish a test product; verify storefront and TV only show published public fields.
- Place a test order and track it using its private token.
- Test POS stock deduction, duplicate submission, returns, refunds, staff role restrictions and employee deactivation.
- Verify backup and restore before using real customer/payment data.

## 6. Backups

```bash
mkdir -p backups && chmod 700 backups
docker compose --env-file .env.production -f compose.yaml exec -T db \
  pg_dump -U jm_app -d jm_house -Fc > "backups/jm-house-$(date +%F-%H%M).dump"
```

Copy encrypted backups off the VPS. A backup on the same server is not disaster recovery. Test restore into a separate database before launch and periodically thereafter.

## 7. Production limitations

- Payment methods are manually recorded/verified. No live M-Pesa, Mixx by Yas, Airtel Money, HaloPesa or bank API credentials/webhooks are included.
- Agency transactions are manually recorded and require reconciliation with provider statements.
- This deployment does not create Android/iOS store binaries.
- Privacy/terms/returns/delivery policies are drafts and require business/legal review.
- Complete an independent security review and device/browser acceptance test before public advertising.
