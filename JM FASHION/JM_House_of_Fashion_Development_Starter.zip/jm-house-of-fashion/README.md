# JM House of Fashion — Development Starter

A premium UI foundation and initial PostgreSQL schema for the JM House of Fashion ecosystem.

## Current contents

- Responsive React/Vite frontend shell.
- Owner dashboard overview.
- Customer storefront catalogue with category filters and cart-count interaction.
- Smart TV public display mode.
- Initial PostgreSQL schema for products, variants, inventory, suppliers, purchases, customers, orders, payments, expenses, agency services and audit logs.
- Feminine premium brand palette: Royal Berry, Blush Rose, Champagne Gold and Soft Ivory.

## Run locally

Requirements: Node.js 20+ and npm.

```bash
npm install
npm run dev
```

Open the local URL printed by Vite.

Create a production build:

```bash
npm run build
```

## Important implementation status

This is the first development scaffold, not yet a deployed production system.

The dashboard currently uses demonstration data. The module pages are structural placeholders. The product catalogue uses remote demonstration photography. No real payment gateway, authentication provider, PostgreSQL connection, employee account system, or cloud synchronization is active yet.

Do not use this scaffold to process real customer payments or store confidential business data.

## Next engineering milestones

1. Provision managed PostgreSQL and backend hosting.
2. Implement authentication, session management, roles and server-side authorization.
3. Apply database migrations and implement row-level security policies.
4. Build API services and connect the interfaces to the shared database.
5. Implement inventory-safe purchasing, POS, online ordering and payment verification.
6. Implement mobile money and bank agency ledger/reconciliation.
7. Implement reports, audit logs, backups and monitoring.
8. Package Flutter applications and prepare store submissions.
9. Run security, integration and acceptance tests.

## Deployment architecture

Use Netlify for the web frontend. Host PostgreSQL and the secure API on a managed service compatible with the application. Keep all database credentials and privileged API keys server-side.
