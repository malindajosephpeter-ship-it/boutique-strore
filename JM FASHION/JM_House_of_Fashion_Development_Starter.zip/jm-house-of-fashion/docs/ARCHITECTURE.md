# Architecture

## Three interfaces, one business platform

- Customer interface: public catalogue, cart, customer identity, own orders and payment status.
- Owner/employee interface: authenticated operational workspace with role-scoped access.
- Smart TV interface: public read-only feed of owner-approved products and promotions.

All interfaces communicate with a shared backend API. The backend is the only component permitted to access privileged database credentials.

## Data ownership

PostgreSQL is the authoritative business record. Browser storage may be used only for non-sensitive preferences or temporary cart drafts. It must not be treated as the source of truth for inventory, payments, orders or financial balances.

## Transaction integrity

Stock reservations, completed sales, refunds and agency ledger postings must use database transactions and idempotency keys. Reconciliation must compare recorded transactions with provider/bank statements. Never infer a successful payment from a customer screenshot alone.

## Privacy boundaries

- Customer can read published products and their own customer/order records.
- TV can read only published display content.
- Employee permissions are role- and action-scoped.
- Owner has full business access.
- Audit records are append-only to ordinary users.

## Production readiness gates

No public launch until authentication, authorization, row-level security, backup/restore, payment verification, error monitoring, privacy notices and security tests are complete.
