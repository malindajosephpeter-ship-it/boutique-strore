import React, { useMemo, useState, useEffect } from 'react';
import Login from './Login.jsx';
import { api, clearSession, getSessionUser, getToken } from './api.js';
import {
  LayoutDashboard, ShoppingBag, Package, Users, ClipboardList, Wallet,
  BarChart3, Settings, Search, Bell, Plus, ArrowUpRight, ArrowDownRight,
  MoreHorizontal, Eye, Heart, ShoppingCart, Menu, X, Store, Monitor,
  ShieldCheck, Smartphone, Banknote, Truck, CalendarDays, ChevronDown,
  SlidersHorizontal, Sparkles, CircleHelp, LogOut, Check, Clock3, Image,
  ReceiptText, BadgePercent, ChartNoAxesCombined, ScanBarcode
} from 'lucide-react';

const products = [
  { id: 1, name: 'Satin Evening Dress', category: 'Nguo za kike', price: 85000, stock: 12, tag: 'New arrival', image: 'https://images.unsplash.com/photo-1566206091558-7f218b696731?w=900&q=85' },
  { id: 2, name: 'Classic Mini Handbag', category: 'Pochi za kike', price: 65000, stock: 8, tag: 'Bestseller', image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=900&q=85' },
  { id: 3, name: 'Elegant Everyday Set', category: 'Nguo za kike', price: 72000, stock: 15, tag: 'Popular', image: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?w=900&q=85' },
  { id: 4, name: 'Rose Gold Watch', category: 'Saa za kike', price: 95000, stock: 5, tag: 'Limited', image: 'https://images.unsplash.com/photo-1524592094714-0f0654e20314?w=900&q=85' },
  { id: 5, name: 'Modern Sunglasses', category: 'Miwani ya kike', price: 35000, stock: 21, tag: 'Trending', image: 'https://images.unsplash.com/photo-1511499767150-a48a237f0083?w=900&q=85' },
  { id: 6, name: 'Chic Shoulder Bag', category: 'Pochi za kike', price: 78000, stock: 9, tag: 'New arrival', image: 'https://images.unsplash.com/photo-159087 턀?'.replace(' 턀?','') }
];
products[5].image = 'https://images.unsplash.com/photo-1590874103328-eac38a683ce7?w=900&q=85';

const money = n => new Intl.NumberFormat('en-TZ', { style: 'currency', currency: 'TZS', maximumFractionDigits: 0 }).format(n).replace('TZS', 'TSh');

function Logo({ small = false }) {
  return <div className="brand-lockup">
    <div className="brand-mark">JM</div>
    {!small && <div><div className="brand-name">JM HOUSE</div><div className="brand-sub">OF FASHION</div></div>}
  </div>;
}

function Sidebar({ mode, setMode, page, setPage, mobileOpen, close }) {
  const adminItems = [
    ['Overview', LayoutDashboard], ['Products', Package], ['Inventory', ClipboardList],
    ['Sales & POS', ScanBarcode], ['Customer Orders', ShoppingBag], ['Suppliers', Truck],
    ['Agency Services', Wallet], ['Expenses', ReceiptText], ['Reports', BarChart3], ['Customers & Team', Users], ['Settings', Settings]
  ];
  return <aside className={`sidebar ${mobileOpen ? 'open' : ''}`}>
    <div className="sidebar-top"><Logo /><button className="icon-btn close-sidebar" onClick={close}><X size={18}/></button></div>
    <div className="workspace-label">WORKSPACE</div>
    <div className="mode-switch">
      <button className={mode === 'admin' ? 'selected' : ''} onClick={() => {setMode('admin'); setPage('Overview'); close();}}><LayoutDashboard size={16}/> Owner</button>
      <button className={mode === 'shop' ? 'selected' : ''} onClick={() => {setMode('shop'); setPage('Shop'); close();}}><ShoppingBag size={16}/> Storefront</button>
      <button className={mode === 'tv' ? 'selected' : ''} onClick={() => {setMode('tv'); setPage('Display'); close();}}><Monitor size={16}/> TV Display</button>
    </div>
    <div className="workspace-label">{mode === 'admin' ? 'MANAGEMENT' : mode === 'shop' ? 'DISCOVER' : 'DISPLAY'}</div>
    <nav className="nav-list">
      {(mode === 'admin' ? adminItems : mode === 'shop' ? [['Shop', ShoppingBag], ['My Orders', ClipboardList]] : [['Display', Monitor]]).map(([label, Icon]) =>
        <button key={label} className={`nav-item ${page === label ? 'active' : ''}`} onClick={() => {setPage(label); close();}}>
          <Icon size={18}/><span>{label}</span>{label === 'Customer Orders' && <i className="nav-count">4</i>}
        </button>
      )}
    </nav>
    <div className="sidebar-bottom">
      <div className="help-card"><div className="help-icon"><CircleHelp size={17}/></div><b>Need a hand?</b><p>Get help setting up your boutique.</p><button onClick={() => alert('Support contact will be configured during deployment.')}>Contact support <ArrowUpRight size={13}/></button></div>
      <div className="profile-row"><div className="avatar">JM</div><div className="profile-copy"><b>Store Owner</b><span>Administrator</span></div><MoreHorizontal size={19} className="muted"/></div>
    </div>
  </aside>;
}

function Header({ page, setMobileOpen, mode, user, onLogout }) {
  return <header className="topbar">
    <button className="icon-btn mobile-menu" onClick={() => setMobileOpen(true)}><Menu size={20}/></button>
    <div className="breadcrumb"><span>{mode === 'admin' ? 'Workspace' : mode === 'shop' ? 'JM Boutique' : 'Public display'}</span><b>/</b><strong>{page}</strong></div>
    <div className="top-actions">
      <div className="date-pill"><CalendarDays size={15}/> {new Intl.DateTimeFormat('en-GB',{dateStyle:'medium'}).format(new Date())}</div>
      <button className="icon-btn notification"><Bell size={18}/><i/></button>
      <button className="top-avatar logout-avatar" title="Sign out" onClick={onLogout}>{(user?.name || 'JM').slice(0,2).toUpperCase()}</button>
    </div>
  </header>;
}

function StatCard({ title, value, change, positive, icon: Icon, note }) {
  return <div className="stat-card">
    <div className="stat-top"><span>{title}</span><div className="stat-icon"><Icon size={18}/></div></div>
    <div className="stat-value">{value}</div>
    <div className="stat-bottom"><span className={positive ? 'trend up' : 'trend down'}>{positive ? <ArrowUpRight size={14}/> : <ArrowDownRight size={14}/>} {change}</span><span className="stat-note">{note}</span></div>
  </div>;
}

function SalesChart() {
  const bars = [38,52,45,68,56,75,62,83,69,92,73,88];
  return <div className="chart-wrap">
    <div className="chart-y"><span>1.2m</span><span>900k</span><span>600k</span><span>300k</span><span>0</span></div>
    <div className="chart-main">
      <div className="chart-grid"><i/><i/><i/><i/><i/></div>
      <div className="bars">{bars.map((h,i)=><div className="bar-column" key={i}><div className={`bar ${i===9?'highlight':''}`} style={{height:`${h}%`}}/></div>)}</div>
      <div className="chart-x"><span>01 Nov</span><span>05 Nov</span><span>10 Nov</span><span>15 Nov</span><span>20 Nov</span></div>
    </div>
  </div>;
}

function Dashboard({user}) {
  const [summary,setSummary]=useState(null); const [reportError,setReportError]=useState('');
  useEffect(()=>{api('/reports/summary?period=month').then(setSummary).catch(e=>setReportError(e.message));},[]);
  const sales=Number(summary?.sales?.completed_sales||0), expenses=Number(summary?.expenses?.expense_total||0), stock=Number(summary?.stock?.units_in_stock||0);
  return <div className="page-content">
    <div className="welcome-row"><div><div className="eyebrow"><Sparkles size={14}/> YOUR BUSINESS AT A GLANCE</div><h1>Good afternoon, <em>{user?.name||'Welcome back.'}</em></h1><p>Here’s what’s happening at JM House of Fashion today.</p></div><button className="primary-btn"><Plus size={17}/> New transaction</button></div>
    <div className="stats-grid">
      <StatCard title="Completed sales · month" value={money(sales)} change="Database" positive note="verified completed orders" icon={Banknote}/>
      <StatCard title="Orders received · month" value={String(summary?.sales?.order_count??'—')} change="Database" positive note="all order statuses" icon={ShoppingBag}/>
      <StatCard title="Units in stock" value={stock.toLocaleString('en-TZ')} change="Live inventory" positive note="current on-hand units" icon={Package}/>
      <StatCard title="Sales less recorded expenses" value={money(sales-expenses)} change="Before other costs" positive={sales>=expenses} note="month to date" icon={ChartNoAxesCombined}/>
    </div>
    {reportError&&<div className="login-error">Dashboard data unavailable: {reportError}</div>}<div className="dashboard-grid">
      <section className="panel sales-panel">
        <div className="panel-heading"><div><h3>Sales performance</h3><p>Track your boutique revenue over time</p></div><select defaultValue="7"><option value="7">Last 20 days</option><option>This month</option><option>This year</option></select></div>
        <div className="chart-legend"><span><i className="legend-dot"/></span> Sales revenue <b>TSh 8,450,000</b><small className="positive-text">+14.6%</small></div>
        <SalesChart/>
      </section>
      <section className="panel activity-panel">
        <div className="panel-heading"><div><h3>Recent activity</h3><p>Latest store updates</p></div><button className="text-btn">View all</button></div>
        <div className="activity-list">
          <Activity icon={ShoppingBag} title="New order received" detail="Order #JMF-1048 · Online" time="8 min ago" tone="rose"/>
          <Activity icon={Banknote} title="POS sale completed" detail="TSh 125,000 · Cash" time="32 min ago" tone="gold"/>
          <Activity icon={Package} title="Stock updated" detail="12 items · New arrivals" time="1 hr ago" tone="sage"/>
          <Activity icon={Users} title="New customer registered" detail="Customer account created" time="2 hrs ago" tone="lilac"/>
        </div>
      </section>
    </div>
    <section className="panel products-panel">
      <div className="panel-heading"><div><h3>Popular products</h3><p>Your most viewed boutique pieces</p></div><button className="text-btn">View inventory <ArrowUpRight size={14}/></button></div>
      <div className="popular-grid">{products.slice(0,4).map(p=><div className="popular-item" key={p.id}><img src={p.image} alt={p.name}/><div><b>{p.name}</b><span>{p.category}</span><strong>{money(p.price)}</strong></div><span className="sold-tag">{p.stock} in stock</span></div>)}</div>
    </section>
  </div>;
}
function Activity({icon:Icon,title,detail,time,tone}) {
  return <div className="activity-item"><div className={`activity-icon ${tone}`}><Icon size={16}/></div><div className="activity-copy"><b>{title}</b><span>{detail}</span></div><time>{time}</time></div>;
}

function ProductsPage({ addToCart, mode, user }) {
  const [filter,setFilter] = useState('All items');
  const [query,setQuery] = useState('');
  const [items,setItems] = useState([]);
  const [loading,setLoading] = useState(true);
  const [error,setError] = useState('');
  const [notice,setNotice] = useState('');
  const [showForm,setShowForm] = useState(false);
  const [form,setForm] = useState({name:'',sku:'',description:'',sellingPrice:'',category:'',size:'',colour:'',openingStock:'0',isPublished:true});
  const categories = ['All items',...new Set(items.map(p=>p.category).filter(Boolean))];
  async function load(){setLoading(true);setError('');try{const data=mode==='admin'?await api('/products/manage'):await api(`/products?businessId=${encodeURIComponent(user?.businessId||import.meta.env.VITE_BUSINESS_ID||'')}`);setItems(data.products||[]);}catch(e){setError(e.message);}finally{setLoading(false);}}
  useEffect(()=>{load();},[mode,user?.businessId]);
  const filtered = useMemo(() => items.filter(p => (filter==='All items'||p.category===filter) && p.name.toLowerCase().includes(query.toLowerCase())),[items,filter,query]);
  async function saveProduct(e){e.preventDefault();setError('');setNotice('');try{let categoryId=null;if(form.category.trim()){const c=await api('/products/categories',{method:'POST',body:JSON.stringify({name:form.category.trim()})});categoryId=c.category.id;}await api('/products',{method:'POST',body:JSON.stringify({name:form.name,sku:form.sku||undefined,description:form.description,sellingPrice:Number(form.sellingPrice),categoryId,isPublished:form.isPublished,variants:[{size:form.size||undefined,colour:form.colour||undefined,openingStock:Number(form.openingStock)}]})});setNotice('Bidhaa imehifadhiwa kwenye database.');setShowForm(false);setForm({name:'',sku:'',description:'',sellingPrice:'',category:'',size:'',colour:'',openingStock:'0',isPublished:true});await load();}catch(e){setError(e.message);}}
  return <div className="page-content">
    <div className="welcome-row"><div><div className="eyebrow"><Sparkles size={14}/> {mode==='admin'?'CATALOGUE MANAGEMENT':'THE BOUTIQUE COLLECTION'}</div><h1>{mode==='admin'?<>Manage your <em>collection.</em></>:<>Discover your <em>style.</em></>}</h1><p>{mode==='admin'?'Add products, manage prices, variants and publication status.':'Thoughtfully selected pieces to make every moment feel special.'}</p></div>{mode==='admin'?<button className="primary-btn" onClick={()=>setShowForm(v=>!v)}><Plus size={17}/> Add product</button>:<div className="secure-note"><ShieldCheck size={16}/> Official JM Boutique collection</div>}</div>
    {error&&<div className="login-error" role="alert">{error}</div>}{notice&&<div className="status-pill"><Check size={13}/>{notice}</div>}
    {showForm&&mode==='admin'&&<section className="panel" style={{marginBottom:18}}><div className="panel-heading"><div><h3>New product</h3><p>Record a product and its first size/colour variant.</p></div><button className="text-btn" onClick={()=>setShowForm(false)}>Close</button></div><form className="product-form" onSubmit={saveProduct}><div className="form-grid"><label>Product name<input required value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/></label><label>SKU (optional)<input value={form.sku} onChange={e=>setForm({...form,sku:e.target.value})}/></label><label>Category<input required placeholder="e.g. Nguo za kike" value={form.category} onChange={e=>setForm({...form,category:e.target.value})}/></label><label>Selling price (TZS)<input required type="number" min="0" step="1" value={form.sellingPrice} onChange={e=>setForm({...form,sellingPrice:e.target.value})}/></label><label>Size<input placeholder="e.g. M, L, XL" value={form.size} onChange={e=>setForm({...form,size:e.target.value})}/></label><label>Colour<input placeholder="e.g. Black" value={form.colour} onChange={e=>setForm({...form,colour:e.target.value})}/></label><label>Opening stock<input type="number" min="0" value={form.openingStock} onChange={e=>setForm({...form,openingStock:e.target.value})}/></label><label>Description<input value={form.description} onChange={e=>setForm({...form,description:e.target.value})}/></label></div><label className="publish-check"><input type="checkbox" checked={form.isPublished} onChange={e=>setForm({...form,isPublished:e.target.checked})}/> Publish in customer storefront and TV display</label><button className="primary-btn" type="submit"><Check size={16}/> Save product</button></form></section>}
    <div className="shop-toolbar"><div className="search-box"><Search size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search products..."/></div><button className="filter-btn" onClick={load}><SlidersHorizontal size={16}/> Refresh</button></div>
    <div className="category-chips">{categories.map(c=><button key={c} className={filter===c?'chosen':''} onClick={()=>setFilter(c)}>{c}</button>)}</div>
    {loading?<div className="coming-panel"><div className="coming-icon"><Clock3/></div><h2>Loading catalogue</h2><p>Connecting to JM House of Fashion database…</p></div>:filtered.length===0?<div className="coming-panel"><div className="coming-icon"><Package/></div><h2>No products found</h2><p>{mode==='admin'?'Add your first real product to populate the catalogue.':'The store catalogue will appear here when products are published.'}</p></div>:<div className="product-grid">{filtered.map(p=><article className="product-card" key={p.id}><div className="product-photo">{p.images?.[0]?.storageKey?<img src={p.images[0].storageKey} alt={p.name}/>:<div className="product-placeholder"><Image size={30}/><span>Product image</span></div>}{mode==='admin'&&<span className="product-tag">{p.is_published?'Published':'Draft'}</span>}</div><div className="product-info"><span>{p.category||'Uncategorised'} {mode==='admin'&&` · ${p.stock??0} in stock`}</span><h3>{p.name}</h3><div className="product-price-row"><b>{money(Number(p.selling_price))}</b>{mode==='shop'&&<button disabled={!p.variants?.some(v=>v.available)} onClick={()=>addToCart({...p,variantId:p.variants?.find(v=>v.available)?.id})} aria-label="Add to cart"><Plus size={17}/></button>}</div></div></article>)}</div>}
  </div>;
}

function OrdersPage(){
  const [orders,setOrders]=useState([]),[loading,setLoading]=useState(true),[error,setError]=useState(''),[refs,setRefs]=useState({}),[busy,setBusy]=useState('');
  async function load(){setLoading(true);setError('');try{const d=await api('/fulfilment');setOrders(d.orders||[]);}catch(e){setError(e.message);}finally{setLoading(false);}}
  useEffect(()=>{load();},[]);
  async function updateStatus(order,status){setBusy(order.id);setError('');try{await api(`/fulfilment/${order.id}/status`,{method:'PATCH',body:JSON.stringify({status})});await load();}catch(e){setError(e.message);}finally{setBusy('');}}
  async function verify(order,payment){const reference=refs[payment.id]?.trim();if(!reference){setError('Weka payment reference kabla ya kuthibitisha malipo.');return;}setBusy(payment.id);try{await api(`/fulfilment/${order.id}/verify-payment`,{method:'POST',body:JSON.stringify({paymentId:payment.id,reference})});await load();}catch(e){setError(e.message);}finally{setBusy('');}}
  const nextStatus={pending_payment:['confirmed','cancelled'],pending:['confirmed','cancelled'],confirmed:['processing','cancelled'],processing:['ready_for_pickup','out_for_delivery','cancelled'],ready_for_pickup:['completed','cancelled'],out_for_delivery:['completed','cancelled']};
  return <div className="page-content"><div className="welcome-row"><div><div className="eyebrow"><ShoppingBag size={14}/> ONLINE SALES</div><h1>Customer <em>orders.</em></h1><p>Review orders, verify payments and manage fulfilment.</p></div><button className="primary-btn" onClick={load}><ArrowUpRight size={16}/> Refresh orders</button></div>{error&&<div className="login-error">{error}</div>}{loading?<div className="coming-panel"><Clock3/><h2>Loading orders</h2></div>:orders.length===0?<div className="coming-panel"><ShoppingBag/><h2>No online orders yet</h2><p>Customer orders will appear here after checkout.</p></div>:<div className="order-list">{orders.map(o=><section className="panel order-card" key={o.id}><div className="order-top"><div><b>{o.order_number||o.id.slice(0,8)}</b><span>{o.customer_name} · {o.customer_phone}</span><small>{new Date(o.created_at).toLocaleString()}</small></div><strong>{money(Number(o.total))}</strong></div><div className="order-lines">{o.lines?.map((l,i)=><div key={i}>{l.product} {l.size||''} {l.colour||''} × {l.quantity}</div>)}</div><div className="payment-list">{o.payments?.map(p=><div className="payment-row" key={p.id}><span>{p.method}{p.provider?` · ${p.provider}`:''} · {money(Number(p.amount))}</span><b>{p.status}</b>{p.status==='pending'&&<><input aria-label="Payment reference" placeholder="Payment reference" value={refs[p.id]||''} onChange={e=>setRefs({...refs,[p.id]:e.target.value})}/><button className="text-btn" disabled={busy===p.id} onClick={()=>verify(o,p)}>Verify</button></>}</div>)}</div><div className="order-actions"><span className="status-pill">{o.status.replaceAll('_',' ')}</span>{(nextStatus[o.status]||[]).map(st=><button key={st} className="filter-btn" disabled={!!busy} onClick={()=>updateStatus(o,st)}>{st.replaceAll('_',' ')}</button>)}</div></section>)}</div>}</div>;
}

function AgencyPage(){
  const [accounts,setAccounts]=useState([]),[transactions,setTransactions]=useState([]),[loading,setLoading]=useState(true),[error,setError]=useState(''),[notice,setNotice]=useState('');
  const [account,setAccount]=useState({serviceType:'mobile_money',providerName:'M-Pesa',accountLabel:'M-Pesa Agency',openingFloat:'0'});
  const [tx,setTx]=useState({agencyAccountId:'',transactionType:'deposit',amount:'',commission:'0',floatDelta:'',reference:'',customerPhone:'',notes:''});
  const providers=['M-Pesa','Mixx by Yas','Airtel Money','HaloPesa','NMB','CRDB','NBC','Azania Bank','PBZ','Other'];
  async function load(){setLoading(true);setError('');try{const [a,t]=await Promise.all([api('/agency/summary'),api('/agency/transactions?limit=100')]);setAccounts(a.accounts||[]);setTransactions(t.transactions||[]);if(!tx.agencyAccountId&&a.accounts?.[0])setTx(v=>({...v,agencyAccountId:a.accounts[0].id}));}catch(e){setError(e.message);}finally{setLoading(false);}}
  useEffect(()=>{load();},[]);
  async function createAccount(e){e.preventDefault();setError('');setNotice('');try{await api('/agency/accounts',{method:'POST',body:JSON.stringify({...account,openingFloat:Number(account.openingFloat)})});setNotice('Agency account saved.');await load();}catch(e){setError(e.message);}}
  async function recordTransaction(e){e.preventDefault();setError('');setNotice('');try{await api('/agency/transactions',{method:'POST',body:JSON.stringify({...tx,amount:Number(tx.amount),commission:Number(tx.commission),floatDelta:Number(tx.floatDelta)})});setNotice('Agency transaction recorded and reconciled.');setTx(v=>({...v,amount:'',commission:'0',floatDelta:'',reference:'',customerPhone:'',notes:''}));await load();}catch(e){setError(e.message);}}
  return <div className="page-content"><div className="welcome-row"><div><div className="eyebrow"><Wallet size={14}/> AGENCY OPERATIONS</div><h1>Agency <em>services.</em></h1><p>Record mobile-money and bank agency transactions, commissions and float movements in TZS.</p></div><button className="primary-btn" onClick={load}><ArrowUpRight size={16}/> Refresh</button></div>
    {error&&<div className="login-error">{error}</div>}{notice&&<div className="status-pill"><Check size={13}/>{notice}</div>}
    <div className="stats-grid">{accounts.map(a=><StatCard key={a.account_label+a.provider_name} title={`${a.provider_name} · ${a.account_label}`} value={money(Number(a.current_float))} change={`${a.completed_count||0} transactions`} positive={Number(a.current_float)>=0} note={`Commission ${money(Number(a.commission_total||0))}`} icon={Wallet}/>)}</div>
    <div className="dashboard-grid"><section className="panel"><div className="panel-heading"><div><h3>Add agency account</h3><p>Register an active network or bank service.</p></div></div><form className="product-form" onSubmit={createAccount}><div className="form-grid"><label>Service type<select value={account.serviceType} onChange={e=>setAccount({...account,serviceType:e.target.value,providerName:e.target.value==='bank'?'NMB':'M-Pesa'})}><option value="mobile_money">Mobile money</option><option value="bank">Bank</option></select></label><label>Provider<select value={account.providerName} onChange={e=>setAccount({...account,providerName:e.target.value})}>{providers.filter(p=>account.serviceType==='bank'?['NMB','CRDB','NBC','Azania Bank','PBZ','Other'].includes(p):['M-Pesa','Mixx by Yas','Airtel Money','HaloPesa','Other'].includes(p)).map(p=><option key={p}>{p}</option>)}</select></label><label>Account label<input required value={account.accountLabel} onChange={e=>setAccount({...account,accountLabel:e.target.value})}/></label><label>Opening float (TZS)<input type="number" min="0" value={account.openingFloat} onChange={e=>setAccount({...account,openingFloat:e.target.value})}/></label></div><button className="primary-btn">Save account</button></form></section>
    <section className="panel"><div className="panel-heading"><div><h3>Record transaction</h3><p>Enter actual float movement. Positive adds float; negative consumes float.</p></div></div><form className="product-form" onSubmit={recordTransaction}><div className="form-grid"><label>Agency account<select required value={tx.agencyAccountId} onChange={e=>setTx({...tx,agencyAccountId:e.target.value})}>{accounts.map(a=><option key={a.id} value={a.id}>{a.provider_name} · {a.account_label}</option>)}</select></label><label>Transaction type<select value={tx.transactionType} onChange={e=>setTx({...tx,transactionType:e.target.value})}>{['deposit','withdrawal','transfer','reversal','float_replenishment','commission'].map(v=><option key={v} value={v}>{v.replaceAll('_',' ')}</option>)}</select></label><label>Amount (TZS)<input required type="number" min="1" value={tx.amount} onChange={e=>setTx({...tx,amount:e.target.value})}/></label><label>Float change (+/- TZS)<input required type="number" step="1" value={tx.floatDelta} onChange={e=>setTx({...tx,floatDelta:e.target.value})} placeholder="e.g. -50000 or 50000"/></label><label>Commission (TZS)<input type="number" min="0" value={tx.commission} onChange={e=>setTx({...tx,commission:e.target.value})}/></label><label>Reference<input value={tx.reference} onChange={e=>setTx({...tx,reference:e.target.value})}/></label><label>Customer phone<input value={tx.customerPhone} onChange={e=>setTx({...tx,customerPhone:e.target.value})}/></label><label>Notes<input value={tx.notes} onChange={e=>setTx({...tx,notes:e.target.value})}/></label></div><button className="primary-btn" disabled={!accounts.length}>Record transaction</button></form></section></div>
    <section className="panel"><div className="panel-heading"><div><h3>Recent agency transactions</h3><p>Duplicate references are rejected; transactions are audit logged.</p></div></div>{loading?<p>Loading agency ledger…</p>:transactions.length===0?<p>No agency transactions recorded yet.</p>:<div className="table-scroll"><table className="data-table"><thead><tr><th>Date</th><th>Provider</th><th>Type</th><th>Reference</th><th>Amount</th><th>Float change</th><th>Commission</th></tr></thead><tbody>{transactions.map(t=><tr key={t.id}><td>{new Date(t.occurred_at).toLocaleString()}</td><td>{t.provider_name}</td><td>{t.transaction_type.replaceAll('_',' ')}</td><td>{t.reference||'—'}</td><td>{money(Number(t.amount))}</td><td>{money(Number(t.float_delta))}</td><td>{money(Number(t.commission))}</td></tr>)}</tbody></table></div>}</section>
  </div>;
}

function POSPage(){
  const [products,setProducts]=useState([]),[cart,setCart]=useState([]),[method,setMethod]=useState('cash'),[provider,setProvider]=useState(''),[reference,setReference]=useState(''),[loading,setLoading]=useState(true),[error,setError]=useState(''),[notice,setNotice]=useState(''),[busy,setBusy]=useState(false);
  async function load(){setLoading(true);setError('');try{const d=await api('/products/manage');setProducts(d.products||[]);}catch(e){setError(e.message);}finally{setLoading(false);}}
  useEffect(()=>{load();},[]);
  const add=(p,v)=>setCart(old=>{const found=old.find(x=>x.variantId===v.id);return found?old.map(x=>x.variantId===v.id?{...x,quantity:x.quantity+1}:x):[...old,{variantId:v.id,product:p.name,price:Number(p.selling_price),quantity:1,stock:Number(v.stock)}]});
  const total=cart.reduce((sum,l)=>sum+l.price*l.quantity,0);
  async function checkout(){setError('');setNotice('');if(!cart.length)return;setBusy(true);try{const d=await api('/orders',{method:'POST',body:JSON.stringify({channel:'physical_pos',lines:cart.map(l=>({variantId:l.variantId,quantity:l.quantity,unitPrice:l.price})),payment:{method,provider:provider||undefined,reference:reference||undefined,amount:total}})});setNotice(`Sale ${d.order.id.slice(0,8)} completed. Total ${money(total)}.`);setCart([]);setReference('');await load();}catch(e){setError(e.message);}finally{setBusy(false);}}
  return <div className="page-content"><div className="welcome-row"><div><div className="eyebrow"><ScanBarcode size={14}/> IN-STORE CHECKOUT</div><h1>Point of <em>sale.</em></h1><p>Create a physical-shop sale, collect payment and deduct stock atomically.</p></div><button className="filter-btn" onClick={load}>Refresh products</button></div>{error&&<div className="login-error">{error}</div>}{notice&&<div className="status-pill"><Check size={13}/>{notice}</div>}
    <div className="dashboard-grid"><section className="panel"><div className="panel-heading"><div><h3>Available products</h3><p>Select a size or colour variant to add it to the sale.</p></div></div>{loading?<p>Loading products…</p>:<div className="pos-products">{products.map(p=><div className="pos-product" key={p.id}><div><b>{p.name}</b><span>{money(Number(p.selling_price))}</span></div><div className="pos-variants">{(p.variants||[]).filter(v=>Number(v.stock)>0).map(v=><button className="filter-btn" key={v.id} onClick={()=>add(p,v)}>{[v.size,v.colour].filter(Boolean).join(' / ')||'Default'} · {v.stock} left <Plus size={13}/></button>)}</div></div>)}</div>}</section>
    <section className="panel"><div className="panel-heading"><div><h3>Current sale</h3><p>{cart.reduce((n,l)=>n+l.quantity,0)} units selected</p></div></div>{cart.length===0?<p>Select products to begin a sale.</p>:<div className="pos-cart">{cart.map(l=><div className="pos-cart-line" key={l.variantId}><span>{l.product} × {l.quantity}</span><b>{money(l.price*l.quantity)}</b><button className="text-btn" onClick={()=>setCart(old=>old.filter(x=>x.variantId!==l.variantId))}>Remove</button></div>)}</div>}<div className="checkout-total"><span>Total</span><b>{money(total)}</b></div><div className="form-grid"><label>Payment method<select value={method} onChange={e=>setMethod(e.target.value)}><option value="cash">Cash</option><option value="mobile_money">Mobile money</option><option value="bank">Bank</option><option value="card">Card</option></select></label><label>Provider (optional)<input value={provider} onChange={e=>setProvider(e.target.value)} placeholder="M-Pesa, NMB…"/></label><label>Payment reference<input value={reference} onChange={e=>setReference(e.target.value)} placeholder="Optional receipt/reference"/></label></div><button className="primary-btn login-submit" disabled={!cart.length||busy} onClick={checkout}>{busy?'Processing sale…':'Complete sale'}</button></section></div>
  </div>;
}

function ReportsPage(){
  const [period,setPeriod]=useState('day'),[summary,setSummary]=useState(null),[year,setYear]=useState(String(new Date().getFullYear())),[trend,setTrend]=useState([]),[from,setFrom]=useState(new Date(new Date().getFullYear(),new Date().getMonth(),1).toISOString().slice(0,10)),[to,setTo]=useState(new Date().toISOString().slice(0,10)),[range,setRange]=useState(null),[error,setError]=useState('');
  async function load(){setError('');try{const d=await api(`/reports/summary?period=${period}`);setSummary(d);const t=await api(`/reports/sales-trend?year=${year}`);setTrend(t.months||[]);}catch(e){setError(e.message);}}
  useEffect(()=>{load();},[period,year]);
  async function loadRange(){setError('');try{setRange(await api(`/reports/range?from=${from}&to=${to}`));}catch(e){setError(e.message);}}
  return <div className="page-content"><div className="welcome-row"><div><div className="eyebrow"><BarChart3 size={14}/> BUSINESS INTELLIGENCE</div><h1>Business <em>reports.</em></h1><p>Daily, weekly, monthly and annual performance in Tanzanian shillings.</p></div><button className="filter-btn" onClick={load}>Refresh report</button></div>{error&&<div className="login-error">{error}</div>}<div className="shop-toolbar"><label>Reporting period<select value={period} onChange={e=>setPeriod(e.target.value)}><option value="day">Today</option><option value="week">This week</option><option value="month">This month</option><option value="year">This year</option></select></label><label>Trend year<input type="number" min="2000" max="2100" value={year} onChange={e=>setYear(e.target.value)}/></label></div>{summary&&<div className="stats-grid"><StatCard title={`${period} completed sales`} value={money(Number(summary.sales.completed_sales))} change={`${summary.sales.order_count} orders`} positive note="All order statuses counted separately" icon={Banknote}/><StatCard title="Recorded expenses" value={money(Number(summary.expenses.expense_total))} change="Database" positive={false} note="Expenses in selected period" icon={Wallet}/><StatCard title="Net before other costs" value={money(Number(summary.netBeforeOtherCosts))} change="Sales less expenses" positive={Number(summary.netBeforeOtherCosts)>=0} note="Not a statutory profit statement" icon={ChartNoAxesCombined}/><StatCard title="Units on hand" value={String(summary.stock.units_in_stock)} change={`${summary.stock.units_reserved} reserved`} positive note="Current inventory" icon={Package}/></div>}
    <section className="panel"><div className="panel-heading"><div><h3>Monthly sales trend · {year}</h3><p>Completed sales totals grouped by month.</p></div></div><div className="report-months">{trend.map(m=><div key={m.month}><span>{m.month}</span><b>{money(Number(m.total))}</b><small>{m.orders} orders</small></div>)}</div></section>
    <section className="panel"><div className="panel-heading"><div><h3>Custom date range</h3><p>Generate a period summary and payment-method breakdown.</p></div></div><div className="form-grid"><label>From<input type="date" value={from} onChange={e=>setFrom(e.target.value)}/></label><label>To<input type="date" value={to} onChange={e=>setTo(e.target.value)}/></label><button className="primary-btn" onClick={loadRange}>Generate report</button></div>{range&&<><div className="stats-grid"><StatCard title="Completed sales" value={money(Number(range.sales.completed_sales))} change={`${range.sales.order_count} orders`} positive note="Selected date range" icon={Banknote}/><StatCard title="Expenses" value={money(Number(range.expenses.expense_total))} change={`${range.expenses.expense_count} entries`} positive={false} note="Selected date range" icon={Wallet}/><StatCard title="Net before other costs" value={money(Number(range.netBeforeOtherCosts))} change="Sales less expenses" positive={Number(range.netBeforeOtherCosts)>=0} note="Selected date range" icon={ChartNoAxesCombined}/></div><h4>Payment methods</h4>{range.paymentMethods.map(p=><p key={p.method}>{p.method}: <b>{money(Number(p.amount))}</b> ({p.count})</p>)}<h4>Top products</h4>{range.topProducts.map(p=><p key={p.product_name}>{p.product_name}: {p.units_sold} units · {money(Number(p.sales_value))}</p>)}</>}</section>
  </div>;
}

function InventoryPage(){
  const [items,setItems]=useState([]),[moves,setMoves]=useState([]),[variantId,setVariantId]=useState(''),[delta,setDelta]=useState(''),[reason,setReason]=useState(''),[error,setError]=useState(''),[notice,setNotice]=useState(''),[loading,setLoading]=useState(true);
  async function load(){setLoading(true);setError('');try{const [i,m]=await Promise.all([api('/inventory'),api('/inventory/movements')]);setItems(i.inventory||[]);setMoves(m.movements||[]);if(!variantId&&i.inventory?.[0])setVariantId(i.inventory[0].variant_id);}catch(e){setError(e.message);}finally{setLoading(false);}}
  useEffect(()=>{load();},[]);
  async function adjust(e){e.preventDefault();setError('');setNotice('');try{await api('/inventory/adjust',{method:'POST',body:JSON.stringify({variantId,quantityDelta:Number(delta),reason})});setNotice('Stock adjustment saved to the permanent stock ledger.');setDelta('');setReason('');await load();}catch(e){setError(e.message);}}
  return <div className="page-content"><div className="welcome-row"><div><div className="eyebrow"><Package size={14}/> STOCK CONTROL</div><h1>Inventory <em>management.</em></h1><p>Live quantities, reserved stock, adjustments and full stock movement history.</p></div><button className="filter-btn" onClick={load}>Refresh</button></div>{error&&<div className="login-error">{error}</div>}{notice&&<div className="status-pill"><Check size={13}/>{notice}</div>}<section className="panel"><div className="panel-heading"><div><h3>Stock balances</h3><p>Available stock excludes quantities reserved for online orders.</p></div></div>{loading?<p>Loading stock…</p>:<div className="table-scroll"><table className="data-table"><thead><tr><th>Product</th><th>Variant</th><th>SKU / Barcode</th><th>On hand</th><th>Reserved</th><th>Available</th></tr></thead><tbody>{items.map(i=><tr key={i.variant_id}><td>{i.product_name}</td><td>{[i.size,i.colour].filter(Boolean).join(' / ')||'Default'}</td><td>{i.variant_sku||i.barcode||'—'}</td><td>{i.quantity_on_hand}</td><td>{i.quantity_reserved}</td><td><b>{i.available}</b></td></tr>)}</tbody></table></div>}</section><section className="panel"><div className="panel-heading"><div><h3>Manual stock adjustment</h3><p>Every adjustment requires a reason and is audit logged.</p></div></div><form className="product-form" onSubmit={adjust}><div className="form-grid"><label>Product variant<select required value={variantId} onChange={e=>setVariantId(e.target.value)}>{items.map(i=><option key={i.variant_id} value={i.variant_id}>{i.product_name} · {[i.size,i.colour].filter(Boolean).join(' / ')||'Default'} · current {i.quantity_on_hand}</option>)}</select></label><label>Quantity change (+/-)<input required type="number" step="1" value={delta} onChange={e=>setDelta(e.target.value)} placeholder="e.g. 5 or -2"/></label><label>Reason<input required minLength="3" value={reason} onChange={e=>setReason(e.target.value)}/></label></div><button className="primary-btn" disabled={!items.length}>Save adjustment</button></form></section><section className="panel"><div className="panel-heading"><div><h3>Stock movement ledger</h3><p>Latest 500 receipts, sales, fulfilments, returns and adjustments.</p></div></div>{moves.length===0?<p>No movements recorded.</p>:<div className="table-scroll"><table className="data-table"><thead><tr><th>Date</th><th>Product</th><th>Variant</th><th>Movement</th><th>Quantity</th><th>Notes</th></tr></thead><tbody>{moves.map(m=><tr key={m.id}><td>{new Date(m.created_at).toLocaleString()}</td><td>{m.product_name}</td><td>{[m.size,m.colour].filter(Boolean).join(' / ')||'Default'}</td><td>{m.movement_type.replaceAll('_',' ')}</td><td>{m.quantity_delta>0?`+${m.quantity_delta}`:m.quantity_delta}</td><td>{m.notes||'—'}</td></tr>)}</tbody></table></div>}</section></div>;
}

function SuppliersPage(){
  const [suppliers,setSuppliers]=useState([]),[purchases,setPurchases]=useState([]),[variants,setVariants]=useState([]),[form,setForm]=useState({name:'',phone:'',email:'',address:''}),[purchase,setPurchase]=useState({supplierId:'',variantId:'',quantity:'1',unitCost:'',invoiceNumber:'',amountPaid:'0'}),[error,setError]=useState(''),[notice,setNotice]=useState(''),[loading,setLoading]=useState(true);
  async function load(){setLoading(true);setError('');try{const [s,p,v]=await Promise.all([api('/suppliers'),api('/purchases'),api('/products/manage')]);setSuppliers(s.suppliers||[]);setPurchases(p.purchases||[]);setVariants((v.products||[]).flatMap(x=>(x.variants||[]).map(y=>({...y,productName:x.name}))));if(!purchase.supplierId&&s.suppliers?.[0])setPurchase(x=>({...x,supplierId:s.suppliers[0].id}));if(!purchase.variantId&&v.products?.[0]?.variants?.[0])setPurchase(x=>({...x,variantId:v.products[0].variants[0].id}));}catch(e){setError(e.message);}finally{setLoading(false);}}
  useEffect(()=>{load();},[]);
  async function addSupplier(e){e.preventDefault();setError('');try{await api('/suppliers',{method:'POST',body:JSON.stringify(form)});setForm({name:'',phone:'',email:'',address:''});setNotice('Supplier saved.');await load();}catch(e){setError(e.message);}}
  async function createPurchase(e){e.preventDefault();setError('');try{const d=await api('/purchases',{method:'POST',body:JSON.stringify({supplierId:purchase.supplierId,invoiceNumber:purchase.invoiceNumber||undefined,amountPaid:Number(purchase.amountPaid),lines:[{variantId:purchase.variantId,quantity:Number(purchase.quantity),unitCost:Number(purchase.unitCost)}]})});setNotice(`Purchase ${d.purchase.id.slice(0,8)} created. Receive it when goods arrive.`);await load();}catch(e){setError(e.message);}}
  async function receive(id){setError('');try{await api(`/purchases/${id}/receive`,{method:'POST'});setNotice('Purchase received; stock balances and movement ledger updated.');await load();}catch(e){setError(e.message);}}
  return <div className="page-content"><div className="welcome-row"><div><div className="eyebrow"><Truck size={14}/> SUPPLY CHAIN</div><h1>Suppliers & <em>purchases.</em></h1><p>Manage wholesale suppliers, purchase invoices, supplier payments and stock receiving.</p></div><button className="filter-btn" onClick={load}>Refresh</button></div>{error&&<div className="login-error">{error}</div>}{notice&&<div className="status-pill"><Check size={13}/>{notice}</div>}<div className="dashboard-grid"><section className="panel"><div className="panel-heading"><div><h3>Register supplier</h3><p>Wholesale supplier details.</p></div></div><form className="product-form" onSubmit={addSupplier}><div className="form-grid"><label>Supplier name<input required value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/></label><label>Phone<input value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})}/></label><label>Email<input type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})}/></label><label>Address<input value={form.address} onChange={e=>setForm({...form,address:e.target.value})}/></label></div><button className="primary-btn">Save supplier</button></form><h4>Supplier directory</h4>{suppliers.map(s=><p key={s.id}><b>{s.name}</b> · {s.phone||'No phone'} · {s.email||'No email'}</p>)}</section><section className="panel"><div className="panel-heading"><div><h3>Create purchase order</h3><p>Record one product variant per purchase order in this entry form.</p></div></div><form className="product-form" onSubmit={createPurchase}><div className="form-grid"><label>Supplier<select required value={purchase.supplierId} onChange={e=>setPurchase({...purchase,supplierId:e.target.value})}>{suppliers.map(s=><option key={s.id} value={s.id}>{s.name}</option>)}</select></label><label>Product variant<select required value={purchase.variantId} onChange={e=>setPurchase({...purchase,variantId:e.target.value})}>{variants.map(v=><option key={v.id} value={v.id}>{v.productName} · {[v.size,v.colour].filter(Boolean).join(' / ')||'Default'}</option>)}</select></label><label>Invoice number<input value={purchase.invoiceNumber} onChange={e=>setPurchase({...purchase,invoiceNumber:e.target.value})}/></label><label>Quantity<input required type="number" min="1" value={purchase.quantity} onChange={e=>setPurchase({...purchase,quantity:e.target.value})}/></label><label>Unit cost (TZS)<input required type="number" min="0" value={purchase.unitCost} onChange={e=>setPurchase({...purchase,unitCost:e.target.value})}/></label><label>Amount paid (TZS)<input type="number" min="0" value={purchase.amountPaid} onChange={e=>setPurchase({...purchase,amountPaid:e.target.value})}/></label></div><button className="primary-btn" disabled={!suppliers.length||!variants.length}>Create purchase</button></form></section></div><section className="panel"><div className="panel-heading"><div><h3>Purchase register</h3><p>Receive stock only after physically checking the delivery.</p></div></div>{loading?<p>Loading purchases…</p>:<div className="table-scroll"><table className="data-table"><thead><tr><th>Date</th><th>Supplier</th><th>Invoice</th><th>Status</th><th>Subtotal</th><th>Paid</th><th>Action</th></tr></thead><tbody>{purchases.map(p=><tr key={p.id}><td>{new Date(p.purchase_date).toLocaleDateString()}</td><td>{p.supplier_name}</td><td>{p.invoice_number||'—'}</td><td>{p.status}</td><td>{money(Number(p.subtotal)+Number(p.additional_costs))}</td><td>{money(Number(p.amount_paid))}</td><td>{p.status!=='received'&&p.status!=='cancelled'?<button className="text-btn" onClick={()=>receive(p.id)}>Receive stock</button>:'—'}</td></tr>)}</tbody></table></div>}</section></div>;
}

function ExpensesPage(){
  const [items,setItems]=useState([]),[form,setForm]=useState({category:'Rent',description:'',amount:'',expenseDate:new Date().toISOString().slice(0,10),paymentMethod:'cash'}),[error,setError]=useState(''),[notice,setNotice]=useState('');
  async function load(){try{const d=await api('/expenses');setItems(d.expenses||[]);}catch(e){setError(e.message);}}
  useEffect(()=>{load();},[]);
  async function save(e){e.preventDefault();setError('');setNotice('');try{await api('/expenses',{method:'POST',body:JSON.stringify({...form,amount:Number(form.amount)})});setNotice('Expense saved.');setForm(v=>({...v,description:'',amount:''}));await load();}catch(e){setError(e.message);}}
  return <div className="page-content"><div className="welcome-row"><div><div className="eyebrow"><ReceiptText size={14}/> BUSINESS COST CONTROL</div><h1>Expenses & <em>payments.</em></h1><p>Record operating costs with date, category and payment method.</p></div><button className="filter-btn" onClick={load}>Refresh</button></div>{error&&<div className="login-error">{error}</div>}{notice&&<div className="status-pill"><Check size={13}/>{notice}</div>}<section className="panel"><div className="panel-heading"><div><h3>Record expense</h3><p>Only record actual business expenditure supported by a receipt or approval.</p></div></div><form className="product-form" onSubmit={save}><div className="form-grid"><label>Category<select value={form.category} onChange={e=>setForm({...form,category:e.target.value})}>{['Rent','Salaries','Transport','Utilities','Internet','Packaging','Marketing','Repairs','Bank charges','Other'].map(x=><option key={x}>{x}</option>)}</select></label><label>Description<input value={form.description} onChange={e=>setForm({...form,description:e.target.value})}/></label><label>Amount (TZS)<input required type="number" min="1" value={form.amount} onChange={e=>setForm({...form,amount:e.target.value})}/></label><label>Expense date<input type="date" value={form.expenseDate} onChange={e=>setForm({...form,expenseDate:e.target.value})}/></label><label>Payment method<select value={form.paymentMethod} onChange={e=>setForm({...form,paymentMethod:e.target.value})}><option value="cash">Cash</option><option value="mobile_money">Mobile money</option><option value="bank">Bank</option><option value="card">Card</option></select></label></div><button className="primary-btn">Save expense</button></form></section><section className="panel"><div className="panel-heading"><div><h3>Expense register</h3><p>Latest recorded expenses.</p></div></div><div className="table-scroll"><table className="data-table"><thead><tr><th>Date</th><th>Category</th><th>Description</th><th>Method</th><th>Amount</th></tr></thead><tbody>{items.map(x=><tr key={x.id}><td>{new Date(x.expense_date).toLocaleDateString()}</td><td>{x.category}</td><td>{x.description||'—'}</td><td>{x.payment_method}</td><td>{money(Number(x.amount))}</td></tr>)}</tbody></table></div></section></div>;
}

function SimplePage({page}) {
  const descriptions = {
    Products:'Manage your fashion catalogue, product images, pricing and variations.',
    Inventory:'Monitor stock levels, product movements and stock adjustments.',
    'Sales & POS':'Record in-store sales and issue customer receipts.',
    'Customer Orders':'Review online orders, confirm payments and manage fulfilment.',
    Suppliers:'Manage wholesale suppliers, purchase invoices and outstanding balances.',
    'Agency Services':'Manage mobile money and bank agency transactions and reconciliation.',
    Reports:'Review daily, weekly, monthly and annual business performance.',
    'Customers & Team':'Manage customer records, employee accounts and access permissions.',
    Settings:'Configure your boutique, payment channels, security and application preferences.',
    'My Orders':'Review your purchases and order delivery status.',
    Display:'Public product slideshow for your in-store Smart TV.'
  };
  return <div className="page-content"><div className="welcome-row"><div><div className="eyebrow"><Sparkles size={14}/> JM HOUSE OF FASHION</div><h1>{page}</h1><p>{descriptions[page] || 'Manage your boutique operations from one place.'}</p></div></div><div className="coming-panel"><div className="coming-icon"><Sparkles size={25}/></div><h2>{page} workspace</h2><p>This module is included in the project architecture. Its database-backed workflows will be implemented in the next development phase.</p><span className="status-pill"><Clock3 size={13}/> Module scaffold created</span></div></div>;
}

function TVDisplay({businessId}) {
  const [items,setItems]=useState([]); const [error,setError]=useState('');
  useEffect(()=>{if(!businessId){setError('Configure VITE_BUSINESS_ID before opening public display.');return;}api(`/display/products?businessId=${encodeURIComponent(businessId)}`).then(d=>setItems(d.products||[])).catch(e=>setError(e.message));},[businessId]);
  const hero=items[0];
  return <div className="tv-screen"><div className="tv-head"><Logo/><span>THE NEW COLLECTION</span><span>SHINYANGA · TANZANIA</span></div><div className="tv-hero"><div><div className="eyebrow">JM HOUSE OF FASHION PRESENTS</div><h1>Style is a way<br/>to <em>express yourself.</em></h1><p>Discover pieces made to celebrate your individuality.</p><div className="tv-cta">EXPLORE OUR COLLECTION</div></div>{hero?.images?.[0]?.storageKey?<img src={hero.images[0].storageKey} alt={hero.name}/>:<div className="product-placeholder"><Image size={34}/><span>{error||'Publish products to show your collection'}</span></div>}</div><div className="tv-products">{items.slice(1,5).map(p=><div key={p.id}>{p.images?.[0]?.storageKey?<img src={p.images[0].storageKey} alt={p.name}/>:<div className="product-placeholder"><Image/></div>}<b>{p.name}</b><span>{money(Number(p.selling_price))}</span></div>)}</div><div className="tv-foot">JM HOUSE OF FASHION <span>MOLEKA STREET, SHINYANGA</span><span>WELCOME IN</span></div></div>;
}

function CheckoutDialog({cart,onClose,onSuccess}){
  const [form,setForm]=useState({customerName:'',phone:'',email:'',deliveryAddress:'',region:'Shinyanga',paymentMethod:'mobile_money',provider:'M-Pesa'});
  const [busy,setBusy]=useState(false),[error,setError]=useState(''),[result,setResult]=useState(null);
  const total=cart.reduce((n,p)=>n+Number(p.selling_price)*p.quantity,0);
  async function submit(e){e.preventDefault();setBusy(true);setError('');try{const businessId=import.meta.env.VITE_BUSINESS_ID;if(!businessId)throw new Error('Store checkout is not configured yet.');const d=await api('/checkout',{method:'POST',body:JSON.stringify({...form,businessId,lines:cart.map(p=>({variantId:p.variantId,quantity:p.quantity}))})});setResult(d);onSuccess();}catch(e){setError(e.message);}finally{setBusy(false);}}
  return <div className="checkout-backdrop"><section className="checkout-modal"><button className="checkout-close" onClick={onClose}>×</button>{result?<><div className="coming-icon"><Check/></div><h2>Oda limepokelewa</h2><p>Hifadhi taarifa hizi ili kufuatilia oda yako.</p><div className="tracking-details"><b>{result.order.order_number}</b><span>Tracking token</span><code>{result.trackingToken}</code></div><button className="primary-btn" onClick={onClose}>Maliza</button></>:<><div className="eyebrow">JM HOUSE OF FASHION · CHECKOUT</div><h2>Complete your <em>order.</em></h2><div className="checkout-total">Jumla ya oda <b>{money(total)}</b></div><form onSubmit={submit} className="checkout-form"><label>Jina kamili<input required value={form.customerName} onChange={e=>setForm({...form,customerName:e.target.value})}/></label><label>Namba ya simu<input required value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})} placeholder="07XXXXXXXX"/></label><label>Barua pepe (hiari)<input type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})}/></label><label>Anuani ya kufikishiwa<input required value={form.deliveryAddress} onChange={e=>setForm({...form,deliveryAddress:e.target.value})}/></label><label>Mkoa<input value={form.region} onChange={e=>setForm({...form,region:e.target.value})}/></label><label>Njia ya malipo<select value={form.paymentMethod} onChange={e=>setForm({...form,paymentMethod:e.target.value})}><option value="mobile_money">Mobile money</option><option value="bank_transfer">Bank transfer</option><option value="cash_on_delivery">Cash on delivery</option></select></label>{form.paymentMethod==='mobile_money'&&<label>Mtandao<select value={form.provider} onChange={e=>setForm({...form,provider:e.target.value})}><option>M-Pesa</option><option>Tigo Pesa</option><option>Airtel Money</option><option>HaloPesa</option></select></label>}{error&&<div className="login-error">{error}</div>}<button className="primary-btn login-submit" disabled={busy}>{busy?'Inatuma oda…':'Place order'}</button></form></>}</section></div>;
}

export default function App() {
  const [user,setUser] = useState(getSessionUser());
  const [authChecked,setAuthChecked] = useState(!getToken());
  useEffect(()=>{ if(!getToken()) return; api('/auth/me').then(({user:u})=>setUser({id:u.id,name:u.display_name,role:u.role,businessId:u.business_id})).catch(()=>{clearSession();setUser(null);}).finally(()=>setAuthChecked(true)); },[]);
  const publicView = new URLSearchParams(window.location.search).get('view');
  const [mode,setMode] = useState(publicView==='shop'?'shop':publicView==='tv'?'tv':'admin');
  const [page,setPage] = useState(publicView==='shop'?'Shop':publicView==='tv'?'Display':'Overview');
  const [mobileOpen,setMobileOpen] = useState(false);
  const [cart,setCart] = useState([]);
  const [checkoutOpen,setCheckoutOpen] = useState(false);
  const addToCart = p => {if(!p.variantId){alert('Bidhaa hii haina variant/stock inayopatikana kwa sasa.');return;}setCart(old=>{const i=old.findIndex(x=>x.variantId===p.variantId);if(i<0)return [...old,{...p,quantity:1}];return old.map((x,n)=>n===i?{...x,quantity:x.quantity+1}:x);});};
  const close = () => setMobileOpen(false);
  if (!authChecked) return <main className="login-screen"><div className="login-loading">Securing your workspace…</div></main>;
  if (!user && mode==='admin') return <Login onLogin={setUser}/>;
  if (mode === 'tv') return <TVDisplay businessId={user?.businessId||import.meta.env.VITE_BUSINESS_ID}/>;
  return <div className="app-shell">
    <Sidebar mode={mode} setMode={setMode} page={page} setPage={setPage} mobileOpen={mobileOpen} close={close}/>
    {mobileOpen && <div className="scrim" onClick={close}/>}
    <main className="main-area">
      <Header page={page} setMobileOpen={setMobileOpen} mode={mode} user={user} onLogout={()=>{clearSession();setUser(null);setMode('admin');setPage('Overview');}}/>
      {mode === 'admin' ? page === 'Overview' ? <Dashboard user={user}/> : page === 'Products' ? <ProductsPage addToCart={addToCart} mode={mode} user={user}/> : page === 'Customer Orders' ? <OrdersPage/> : page === 'Inventory' ? <InventoryPage/> : page === 'Suppliers' ? <SuppliersPage/> : page === 'Expenses' ? <ExpensesPage/> : page === 'Sales & POS' ? <POSPage/> : page === 'Agency Services' ? <AgencyPage/> : page === 'Reports' ? <ReportsPage/> : <SimplePage page={page}/> : page === 'Shop' ? <ProductsPage addToCart={addToCart} mode={mode} user={user}/> : <SimplePage page={page}/> }
    </main>
    {mode === 'shop' && <button className="cart-fab" onClick={()=>setCheckoutOpen(true)}><ShoppingCart size={19}/><span>{cart.reduce((n,p)=>n+p.quantity,0)}</span></button>}
    {checkoutOpen&&<CheckoutDialog cart={cart} onClose={()=>setCheckoutOpen(false)} onSuccess={()=>setCart([])}/>}
  </div>;
}
