import { Router } from 'express';
import { z } from 'zod';
import { pool } from '../db.js';
import { requireAuth, allowRoles } from '../middleware/auth.js';

const router = Router();
router.use(requireAuth);
const manage = allowRoles('owner', 'manager', 'agency_operator', 'accountant');
const accountSchema = z.object({
  serviceType: z.enum(['mobile_money', 'bank']),
  providerName: z.string().trim().min(2).max(100),
  accountLabel: z.string().trim().min(2).max(120),
  openingFloat: z.number().nonnegative().max(1_000_000_000).default(0)
});
const transactionSchema = z.object({
  agencyAccountId: z.string().uuid(),
  transactionType: z.enum(['deposit', 'withdrawal', 'transfer', 'reversal', 'float_replenishment', 'commission']),
  amount: z.number().positive().max(1_000_000_000),
  commission: z.number().nonnegative().default(0),
  // Positive adds float; negative consumes float. The operator must select the real operational direction.
  floatDelta: z.number().max(1_000_000_000).min(-1_000_000_000),
  reference: z.string().trim().max(120).optional(),
  customerPhone: z.string().trim().max(30).optional(),
  occurredAt: z.string().datetime().optional(),
  notes: z.string().trim().max(500).optional()
});

router.get('/accounts', manage, async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT a.id,a.service_type,a.provider_name,a.account_label,a.is_active,a.opening_float,a.currency,
        a.opening_float + COALESCE(SUM(CASE WHEN t.status='completed' THEN t.float_delta ELSE 0 END),0) AS current_float,
        COUNT(t.id)::int AS transaction_count
       FROM agency_accounts a LEFT JOIN agency_transactions t ON t.agency_account_id=a.id
       WHERE a.business_id=$1 GROUP BY a.id ORDER BY a.service_type,a.provider_name`,
      [req.user.businessId]
    );
    res.json({ accounts: result.rows });
  } catch (error) { next(error); }
});

router.post('/accounts', manage, async (req, res, next) => {
  const parsed = accountSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Invalid agency account', details: parsed.error.flatten() });
  try {
    const d = parsed.data;
    const result = await pool.query(
      `INSERT INTO agency_accounts(business_id,service_type,provider_name,account_label,opening_float)
       VALUES($1,$2,$3,$4,$5) RETURNING id,service_type,provider_name,account_label,is_active,opening_float,currency`,
      [req.user.businessId, d.serviceType, d.providerName, d.accountLabel, d.openingFloat]
    );
    await pool.query(
      `INSERT INTO audit_logs(business_id,actor_user_id,action,entity_type,entity_id,metadata)
       VALUES($1,$2,'agency_account_created','agency_account',$3,$4)`,
      [req.user.businessId, req.user.sub, result.rows[0].id, JSON.stringify({ serviceType: d.serviceType, provider: d.providerName })]
    );
    res.status(201).json({ account: result.rows[0] });
  } catch (error) { next(error); }
});

router.patch('/accounts/:id/status', manage, async (req, res, next) => {
  const parsed = z.object({ isActive: z.boolean() }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'isActive must be boolean' });
  try {
    const result = await pool.query(
      'UPDATE agency_accounts SET is_active=$3,updated_at=now() WHERE id=$1 AND business_id=$2 RETURNING id,is_active',
      [req.params.id, req.user.businessId, parsed.data.isActive]
    );
    if (!result.rowCount) return res.status(404).json({ error: 'Agency account not found' });
    res.json({ account: result.rows[0] });
  } catch (error) { next(error); }
});

router.get('/transactions', manage, async (req, res, next) => {
  try {
    const limit = Math.min(Math.max(Number(req.query.limit) || 100, 1), 500);
    const result = await pool.query(
      `SELECT t.id,t.agency_account_id,t.transaction_type,t.reference,t.amount,t.commission,t.float_delta,
        t.status,t.customer_phone,t.notes,t.occurred_at,a.provider_name,a.account_label,a.service_type
       FROM agency_transactions t JOIN agency_accounts a ON a.id=t.agency_account_id
       WHERE a.business_id=$1 ORDER BY t.occurred_at DESC LIMIT $2`,
      [req.user.businessId, limit]
    );
    res.json({ transactions: result.rows });
  } catch (error) { next(error); }
});

router.post('/transactions', manage, async (req, res, next) => {
  const parsed = transactionSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Invalid agency transaction', details: parsed.error.flatten() });
  const d = parsed.data;
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const account = await client.query(
      'SELECT id FROM agency_accounts WHERE id=$1 AND business_id=$2 AND is_active=true FOR UPDATE',
      [d.agencyAccountId, req.user.businessId]
    );
    if (!account.rowCount) throw Object.assign(new Error('Active agency account not found'), { status: 404 });
    const balance = await client.query(
      `SELECT a.opening_float + COALESCE(SUM(t.float_delta) FILTER(WHERE t.status='completed'),0) AS current_float
       FROM agency_accounts a LEFT JOIN agency_transactions t ON t.agency_account_id=a.id
       WHERE a.id=$1 GROUP BY a.id`, [d.agencyAccountId]
    );
    const projectedFloat = Number(balance.rows[0].current_float) + d.floatDelta;
    if (projectedFloat < 0) throw Object.assign(new Error('This transaction would make agency float negative. Check the float direction and available balance.'), { status: 409 });
    const result = await client.query(
      `INSERT INTO agency_transactions(agency_account_id,transaction_type,reference,amount,commission,status,occurred_at,created_by,float_delta,customer_phone,notes)
       VALUES($1,$2,$3,$4,$5,'completed',COALESCE($6::timestamptz,now()),$7,$8,$9,$10)
       RETURNING id,agency_account_id,transaction_type,reference,amount,commission,float_delta,status,occurred_at`,
      [d.agencyAccountId,d.transactionType,d.reference || null,d.amount,d.commission,d.occurredAt || null,req.user.sub,d.floatDelta,d.customerPhone || null,d.notes || null]
    );
    await client.query(
      `INSERT INTO audit_logs(business_id,actor_user_id,action,entity_type,entity_id,metadata)
       VALUES($1,$2,'agency_transaction_recorded','agency_transaction',$3,$4)`,
      [req.user.businessId,req.user.sub,result.rows[0].id,JSON.stringify({ amount:d.amount, commission:d.commission, floatDelta:d.floatDelta, type:d.transactionType })]
    );
    await client.query('COMMIT');
    res.status(201).json({ transaction: result.rows[0] });
  } catch (error) {
    await client.query('ROLLBACK');
    if (error.code === '23505') return res.status(409).json({ error: 'This reference has already been recorded for this agency account' });
    next(error);
  } finally { client.release(); }
});

router.get('/summary', manage, async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT a.id,a.service_type,a.provider_name,a.account_label,a.currency,a.opening_float,
        a.opening_float+COALESCE(SUM(t.float_delta) FILTER(WHERE t.status='completed'),0) AS current_float,
        COALESCE(SUM(t.amount) FILTER(WHERE t.status='completed'),0) AS transaction_volume,
        COALESCE(SUM(t.commission) FILTER(WHERE t.status='completed'),0) AS commission_total,
        COUNT(t.id) FILTER(WHERE t.status='completed')::int AS completed_count
       FROM agency_accounts a LEFT JOIN agency_transactions t ON t.agency_account_id=a.id
       WHERE a.business_id=$1 AND a.is_active=true GROUP BY a.id ORDER BY a.service_type,a.provider_name`,
      [req.user.businessId]
    );
    res.json({ currency: 'TZS', accounts: result.rows });
  } catch (error) { next(error); }
});

export default router;
