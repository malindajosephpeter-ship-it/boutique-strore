import { Router } from 'express';
import { z } from 'zod';
import { pool } from '../db.js';
import { requireAuth, allowRoles } from '../middleware/auth.js';

const router = Router();
router.use(requireAuth, allowRoles('owner', 'manager', 'accountant'));

router.get('/summary', async (req, res, next) => {
  try {
    const period = ['day', 'week', 'month', 'year'].includes(req.query.period) ? req.query.period : 'month';
    const sales = await pool.query(
      `SELECT COUNT(*)::int order_count,
        COALESCE(SUM(total),0)::numeric(14,2) sales_total,
        COALESCE(SUM(CASE WHEN status='completed' THEN total ELSE 0 END),0)::numeric(14,2) completed_sales
       FROM sales_orders WHERE business_id=$1 AND created_at >= date_trunc($2,now())`,
      [req.user.businessId, period]
    );
    const expenses = await pool.query(
      `SELECT COALESCE(SUM(amount),0)::numeric(14,2) expense_total
       FROM expenses WHERE business_id=$1 AND date_trunc($2,expense_date::timestamp)=date_trunc($2,now())`,
      [req.user.businessId, period]
    );
    const stock = await pool.query(
      `SELECT COALESCE(SUM(ib.quantity_on_hand),0)::int units_in_stock,
        COALESCE(SUM(ib.quantity_reserved),0)::int units_reserved,
        COUNT(DISTINCT pv.product_id)::int variant_products
       FROM inventory_balances ib JOIN product_variants pv ON pv.id=ib.variant_id
       JOIN products p ON p.id=pv.product_id WHERE p.business_id=$1`,
      [req.user.businessId]
    );
    res.json({ period, currency: 'TZS', sales: sales.rows[0], expenses: expenses.rows[0], stock: stock.rows[0], netBeforeOtherCosts: (Number(sales.rows[0].completed_sales) - Number(expenses.rows[0].expense_total)).toFixed(2) });
  } catch (error) { next(error); }
});

router.get('/sales-trend', async (req, res, next) => {
  try {
    const year = Number(req.query.year) || new Date().getFullYear();
    if (!Number.isInteger(year) || year < 2000 || year > 2100) return res.status(400).json({ error: 'Invalid year' });
    const result = await pool.query(
      `SELECT to_char(date_trunc('month',created_at),'YYYY-MM') month,COUNT(*)::int orders,
        COALESCE(SUM(total) FILTER(WHERE status='completed'),0)::numeric(14,2) total
       FROM sales_orders WHERE business_id=$1 AND created_at >= make_date($2,1,1)
       AND created_at < make_date($2+1,1,1) GROUP BY 1 ORDER BY 1`,
      [req.user.businessId, year]
    );
    res.json({ year, currency: 'TZS', months: result.rows });
  } catch (error) { next(error); }
});

router.get('/range', async (req, res, next) => {
  const parsed = z.object({ from: z.string().date(), to: z.string().date() }).safeParse({ from: req.query.from, to: req.query.to });
  if (!parsed.success) return res.status(400).json({ error: 'Provide valid from and to dates in YYYY-MM-DD format' });
  if (parsed.data.from > parsed.data.to) return res.status(400).json({ error: 'from must be on or before to' });
  try {
    const [sales, expenses, payments, topProducts] = await Promise.all([
      pool.query(`SELECT COUNT(*)::int order_count,COALESCE(SUM(total) FILTER(WHERE status='completed'),0)::numeric(14,2) completed_sales,COALESCE(SUM(total),0)::numeric(14,2) orders_value FROM sales_orders WHERE business_id=$1 AND created_at >= $2::date AND created_at < ($3::date + interval '1 day')`, [req.user.businessId, parsed.data.from, parsed.data.to]),
      pool.query(`SELECT COALESCE(SUM(amount),0)::numeric(14,2) expense_total,COUNT(*)::int expense_count FROM expenses WHERE business_id=$1 AND expense_date BETWEEN $2::date AND $3::date`, [req.user.businessId, parsed.data.from, parsed.data.to]),
      pool.query(`SELECT method,COALESCE(SUM(amount),0)::numeric(14,2) amount,COUNT(*)::int count FROM payments p JOIN sales_orders o ON o.id=p.order_id WHERE o.business_id=$1 AND p.status='verified' AND p.created_at >= $2::date AND p.created_at < ($3::date + interval '1 day') GROUP BY method ORDER BY amount DESC`, [req.user.businessId, parsed.data.from, parsed.data.to]),
      pool.query(`SELECT p.name product_name,SUM(l.quantity)::int units_sold,SUM(l.quantity*l.unit_price)::numeric(14,2) sales_value FROM sales_order_lines l JOIN sales_orders o ON o.id=l.order_id JOIN product_variants v ON v.id=l.variant_id JOIN products p ON p.id=v.product_id WHERE p.business_id=$1 AND o.status='completed' AND o.created_at >= $2::date AND o.created_at < ($3::date + interval '1 day') GROUP BY p.id,p.name ORDER BY units_sold DESC LIMIT 10`, [req.user.businessId, parsed.data.from, parsed.data.to])
    ]);
    res.json({ currency: 'TZS', range: parsed.data, sales: sales.rows[0], expenses: expenses.rows[0], paymentMethods: payments.rows, topProducts: topProducts.rows, netBeforeOtherCosts: (Number(sales.rows[0].completed_sales) - Number(expenses.rows[0].expense_total)).toFixed(2) });
  } catch (error) { next(error); }
});

export default router;
