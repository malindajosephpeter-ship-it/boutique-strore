import { Router } from 'express';
import { z } from 'zod';
import { pool } from '../db.js';
import { requireAuth, allowRoles } from '../middleware/auth.js';

const router = Router();
const roles = allowRoles('owner','manager','stock_manager');
const productSchema = z.object({
  name: z.string().trim().min(2).max(160),
  categoryId: z.string().uuid().nullable().optional(),
  description: z.string().max(4000).optional(),
  sellingPrice: z.number().nonnegative(),
  sku: z.string().max(80).optional(),
  isPublished: z.boolean().optional(),
  variants: z.array(z.object({ size:z.string().max(30).optional(), colour:z.string().max(50).optional(), sku:z.string().max(80).optional(), barcode:z.string().max(80).optional(), openingStock:z.number().int().min(0).max(100000).default(0) })).min(1).max(100).optional()
});

// Public catalogue is intentionally restricted to published products and public fields.
router.get('/', async (req, res, next) => {
  try {
    const businessId = req.query.businessId;
    if (!businessId) return res.status(400).json({ error: 'businessId is required' });
    const result = await pool.query(
      `SELECT p.id, p.name, p.description, p.selling_price, p.is_published,
              c.name AS category,
              COALESCE((SELECT json_agg(json_build_object('storageKey', pi.storage_key, 'alt', pi.alt_text) ORDER BY pi.sort_order) FROM product_images pi WHERE pi.product_id = p.id), '[]') AS images,
              COALESCE((SELECT json_agg(json_build_object('id',v.id,'size',v.size,'colour',v.colour,'available',COALESCE(ib.quantity_on_hand,0)-COALESCE(ib.quantity_reserved,0)>0)) FROM product_variants v LEFT JOIN inventory_balances ib ON ib.variant_id=v.id WHERE v.product_id=p.id),'[]') AS variants
       FROM products p LEFT JOIN categories c ON c.id = p.category_id
       WHERE p.business_id = $1 AND p.is_published = true ORDER BY p.created_at DESC`, [businessId]);
    res.json({ products: result.rows });
  } catch (err) { next(err); }
});

// Private catalogue includes unpublished products and stock summaries for authorised staff only.
router.get('/manage', requireAuth, allowRoles('owner','manager','stock_manager','sales_attendant'), async (req,res,next) => {
  try {
    const result = await pool.query(`SELECT p.id,p.name,p.sku,p.description,p.selling_price,p.is_published,p.created_at,c.name category,
      COALESCE((SELECT SUM(ib.quantity_on_hand) FROM product_variants v JOIN inventory_balances ib ON ib.variant_id=v.id WHERE v.product_id=p.id),0)::int stock,
      COALESCE((SELECT json_agg(json_build_object('id',v.id,'sku',v.sku,'size',v.size,'colour',v.colour,'barcode',v.barcode,'stock',COALESCE(ib.quantity_on_hand,0))) FROM product_variants v LEFT JOIN inventory_balances ib ON ib.variant_id=v.id WHERE v.product_id=p.id),'[]') variants
      FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE p.business_id=$1 ORDER BY p.created_at DESC`,[req.user.businessId]);
    res.json({products:result.rows});
  } catch(e){next(e);}
});

router.get('/categories', requireAuth, async(req,res,next)=>{
  try { const r=await pool.query('SELECT id,name FROM categories WHERE business_id=$1 AND is_active=true ORDER BY name',[req.user.businessId]); res.json({categories:r.rows}); }
  catch(e){next(e);}
});
router.post('/categories', requireAuth, roles, async(req,res,next)=>{
  const p=z.object({name:z.string().trim().min(2).max(80)}).safeParse(req.body);
  if(!p.success)return res.status(400).json({error:'Invalid category'});
  try { const r=await pool.query('INSERT INTO categories(business_id,name) VALUES($1,$2) ON CONFLICT(business_id,name) DO UPDATE SET is_active=true RETURNING id,name',[req.user.businessId,p.data.name]);res.status(201).json({category:r.rows[0]}); }
  catch(e){next(e);}
});

router.post('/', requireAuth, roles, async (req, res, next) => {
  const parsed = productSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'Invalid product details', details: parsed.error.flatten() });
  const p=parsed.data, client=await pool.connect();
  try {
    await client.query('BEGIN');
    if(p.categoryId){const c=await client.query('SELECT id FROM categories WHERE id=$1 AND business_id=$2',[p.categoryId,req.user.businessId]);if(!c.rowCount)throw Object.assign(new Error('Category not found'),{status:400});}
    const created=await client.query(`INSERT INTO products(business_id,category_id,sku,name,description,selling_price,is_published) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING id,name,sku,selling_price,is_published`,[req.user.businessId,p.categoryId||null,p.sku||null,p.name,p.description||null,p.sellingPrice,p.isPublished||false]);
    const product=created.rows[0];
    for(const v of (p.variants?.length?p.variants:[{openingStock:0}])){
      const vr=await client.query('INSERT INTO product_variants(product_id,sku,size,colour,barcode) VALUES($1,$2,$3,$4,$5) RETURNING id',[product.id,v.sku||null,v.size||null,v.colour||null,v.barcode||null]);
      await client.query('INSERT INTO inventory_balances(variant_id,quantity_on_hand) VALUES($1,$2)',[vr.rows[0].id,v.openingStock||0]);
      if(v.openingStock>0)await client.query(`INSERT INTO stock_movements(business_id,variant_id,movement_type,quantity_delta,notes,created_by) VALUES($1,$2,'adjustment_in',$3,'Opening stock',$4)`,[req.user.businessId,vr.rows[0].id,v.openingStock,req.user.sub]);
    }
    await client.query(`INSERT INTO audit_logs(business_id,actor_user_id,action,entity_type,entity_id,metadata) VALUES($1,$2,'product_created','product',$3,$4)`,[req.user.businessId,req.user.sub,product.id,JSON.stringify({name:p.name,variants:p.variants?.length||1})]);
    await client.query('COMMIT');res.status(201).json({product});
  } catch(e){await client.query('ROLLBACK');next(e);} finally{client.release();}
});

router.patch('/:id', requireAuth, roles, async(req,res,next)=>{
  const p=z.object({name:z.string().trim().min(2).max(160).optional(),description:z.string().max(4000).nullable().optional(),sellingPrice:z.number().nonnegative().optional(),isPublished:z.boolean().optional(),sku:z.string().max(80).nullable().optional()}).strict().safeParse(req.body);
  if(!p.success)return res.status(400).json({error:'Invalid product update',details:p.error.flatten()});
  const d=p.data; if(!Object.keys(d).length)return res.status(400).json({error:'No changes supplied'});
  try{const r=await pool.query(`UPDATE products SET name=COALESCE($3,name),description=CASE WHEN $4 THEN $5 ELSE description END,selling_price=COALESCE($6,selling_price),is_published=COALESCE($7,is_published),sku=CASE WHEN $8 THEN $9 ELSE sku END,updated_at=now() WHERE id=$1 AND business_id=$2 RETURNING id,name,sku,description,selling_price,is_published`,[req.params.id,req.user.businessId,d.name??null,Object.hasOwn(d,'description'),d.description??null,d.sellingPrice??null,d.isPublished??null,Object.hasOwn(d,'sku'),d.sku??null]);if(!r.rowCount)return res.status(404).json({error:'Product not found'});res.json({product:r.rows[0]});}catch(e){next(e);}
});

export default router;
