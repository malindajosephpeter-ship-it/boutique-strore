-- Agency float accounting and transaction reconciliation.
-- Float movement is explicit because the effect differs by provider/service direction.
ALTER TABLE agency_accounts
  ADD COLUMN IF NOT EXISTS opening_float numeric(14,2) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS currency char(3) NOT NULL DEFAULT 'TZS',
  ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

ALTER TABLE agency_transactions
  ADD COLUMN IF NOT EXISTS float_delta numeric(14,2) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS customer_phone text,
  ADD COLUMN IF NOT EXISTS notes text,
  ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

ALTER TABLE agency_transactions DROP CONSTRAINT IF EXISTS agency_transactions_created_by_fkey;
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='agency_transactions_amount_positive') THEN
    ALTER TABLE agency_transactions ADD CONSTRAINT agency_transactions_amount_positive CHECK (amount > 0) NOT VALID;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='agency_transactions_commission_nonnegative') THEN
    ALTER TABLE agency_transactions ADD CONSTRAINT agency_transactions_commission_nonnegative CHECK (commission >= 0) NOT VALID;
  END IF;
END $$;
CREATE INDEX IF NOT EXISTS idx_agency_tx_status_date ON agency_transactions(status, occurred_at DESC);

-- A reference is unique per agency account when supplied, preventing accidental duplicate entry.
CREATE UNIQUE INDEX IF NOT EXISTS idx_agency_tx_account_reference
  ON agency_transactions(agency_account_id, reference)
  WHERE reference IS NOT NULL AND reference <> '';
