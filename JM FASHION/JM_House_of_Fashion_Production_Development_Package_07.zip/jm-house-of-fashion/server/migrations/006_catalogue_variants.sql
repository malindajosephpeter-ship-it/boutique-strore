-- Catalogue lifecycle and variant integrity for the connected management UI.
CREATE INDEX IF NOT EXISTS idx_variants_product ON product_variants(product_id);
CREATE INDEX IF NOT EXISTS idx_categories_business_active ON categories(business_id,is_active,name);
CREATE INDEX IF NOT EXISTS idx_product_images_product_sort ON product_images(product_id,sort_order);
ALTER TABLE product_variants ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now();
ALTER TABLE product_images ADD COLUMN IF NOT EXISTS created_at timestamptz NOT NULL DEFAULT now();
